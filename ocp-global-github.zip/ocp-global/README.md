**OCP GLOBAL**

Configuration to deploy to Dev, QA, and Production Environments  

**KUBERNETES URLS**

Cluster addresses for api access

ehmdev   server=https://10.165.20.163:6443

ehmqa    server=https://10.165.54.36:6443

ehmprod  server=https://10.165.50.131:6443

Cluster addresses for UI access

ehmdev   https://dashboard.dev-ehm.prattwhitney.com

ehmqa    https://dashboard.qa-ehm.prattwhitney.com

ehmprod  https://dashboard.ehm.prattwhitney.com
