import React from 'react'
import { BoundDecimalEntryField } from '../../controls/NumberField'

const forecastFieldemplate = {
  fieldKey: 'value',
  baseFieldKey: 'iceValue',
}

const tdata = [
  { value: null, iceValue: 1 },
  { value: null, iceValue: 2 },
  { value: 2, iceValue: 3 }
]

const Dashboard = () => {
  return (
    <div style={{ width: '200px' }}>
      <BoundDecimalEntryField
        srcObject={tdata[0]}
        fieldTemplate={forecastFieldemplate}
        numFractionalDigits={5}
        tabIndex={0}
      />
      <BoundDecimalEntryField
        srcObject={tdata[1]}
        fieldTemplate={forecastFieldemplate}
        numFractionalDigits={5}
        tabIndex={1}
      />
      <BoundDecimalEntryField
        srcObject={tdata[2]}
        fieldTemplate={forecastFieldemplate}
        numFractionalDigits={5}
        tabIndex={2}
      />
    </div>
  )
}


export default Dashboard
