/* eslint-disable react/prop-types */
import React, { useRef, useImperativeHandle, forwardRef } from 'react'
import PropTypes from 'prop-types'
import styled from 'styled-components'
import { XDivider, ExpandingContainer } from 'pwlib/styles'
import { FastInputTable } from 'pwlib/components/controls'
import { LocalToast } from 'pwlib/containers'
import { BoundTextField, BoundSelect, BoundDateTime, BoundSwitch, SaveButton, ResetButton } from 'pwlib/components/formcontrols'
import { useFormHandler } from 'pwlib/hooks'

import { PageContainer, PageButtonsContainer, PageTopContainer } from '../common'

const numbersWidth = 40

const selectItems = [
  { value: '10', label: 'Select 1' },
  { value: '20', label: 'Select 2' },
  { value: '30', label: 'Select 3' },
  { value: '40', label: 'Select 4' },
  { value: '50', label: 'Select 5' }
]

// Describes the table column headers. Also describes sorting and filtering.
const columns = [
  {
    // Header column label.
    label: 'Name', 
    // Column min width.
    minWidth: 170,
    // Used to define the kind of sort and filtering
    columnType: 'string',
    hasSort: true,
    hasFilter: true,
    // Used to align the column. Do not use for an input column type.
    // align: 'right'
    // Column header style override.
    // style: {}
    // Styles to apply to the cells of a column but not the header column.
    // cellStyle: {}
    // filterProps: { items: selectItems },
    // Clickable row
    // isClick: true,
    // isDelete: bool
    // onDelete: function, must have isDelete true
  },
  { 
    label: 'Date', 
    minWidth: 120,
    columnType: 'date',
    hasSort: true,
    hasFilter: true,
    filterProps: { type: 'date' }
  },
  {
    label: 'Select',
    minWidth: 120,
    columnType: 'select',
    hasSort: true,
    hasFilter: true,
    filterProps: { items: selectItems },
  },
  {
    label: 'Data 1',
    minWidth: 120,
    columnType: 'number',
    hasSort: true,
    hasFilter: true
  },
  {
    label: 'Bool',
    minWidth: 110,
    columnType: 'bool',
    hasSort: true,
    hasFilter: true
  },
  {
    label: 'Data 3',
    minWidth: 110,
    columnType: 'select',
    hasSort: true,
    hasFilter: true
  },
  {
    label: 'Data 4',
    minWidth: numbersWidth,
  },
  {
    label: 'Data 5',
    minWidth: numbersWidth,
  },
  {
    label: 'Data 6',
    minWidth: numbersWidth,
  },
  {
    label: 'Data 7',
    minWidth: numbersWidth,
  },
  {
    label: 'Data 8',
    minWidth: numbersWidth,
  },
  {
    label: 'Data 9',
    minWidth: numbersWidth,
  },
]

const TopPart = styled(PageTopContainer)`
  font-size: 26px;
  display: flex;
  align-items: center;
  justify-content: center;
`

const Buttons = forwardRef((props, ref) => {
  const refSaveButton = useRef()
  const refResetButton = useRef()

  const disableButtons = disabled => {
    refSaveButton.current.setDisabled(disabled)
    refResetButton.current.setDisabled(disabled)
  }

  const onPostComplete = () => {
    props.formResetOnPostComplete && props.formResetOnPostComplete()
    disableButtons(true)
  }
  
  const formReset = () => {
    props.formReset()
    disableButtons(true)
  }

  useImperativeHandle(ref, () => ({
    setDisabled: disabled => disableButtons(disabled)
  }))

  return (
    <>
      <ResetButton ref={refResetButton} disabled onClick={formReset} />
      <XDivider width='10px' />
      <SaveButton ref={refSaveButton} disabled feedBack boundControls onPostComplete={onPostComplete} formTemplate={props.formTemplate} arrRefs={props.arrRefs} postService={props.postService} data={props.data} />
    </>
  )
})

Buttons.propTypes = {
  arrRefs: PropTypes.array,
  postService: PropTypes.func,
  formTemplate: PropTypes.array,
}

// Use the function basehttp.get for the get in your service.
const getService = () => {
  const arr = []
  let dataValue = 1
  for (let i = 0; i < 16; ++i) {
    const obj = {
      name: `Name ${i}`,
      date: '2021-12-01',
      select: '10',
      data1: dataValue++,
      data2: false,
      data3: dataValue++,
      data4: dataValue++,
      data5: dataValue++,
      data6: dataValue++,
      data7: dataValue++,
      data8: dataValue++,
      data9: dataValue++,
    }
    arr.push(obj)
  }
  // This simulates a basehttp.get.
  const mockGetObject = arr
  return new Promise(resolve => {
    setTimeout(() => {
      resolve(mockGetObject)
    }, 2000)
  })
}

// This describes the table row columns in terms of the form controls.
const rowComponents = [
  { component: BoundTextField },
  { component: BoundDateTime, props: { type: 'date' } },
  { component: BoundSelect, props: { items: selectItems, style: { zIndex: 1 } } },
  { component: BoundTextField },
  { component: BoundSwitch },
  { component: BoundTextField },
  { component: BoundTextField },
  { component: BoundTextField },
  { component: BoundTextField },
  { component: BoundTextField },
  { component: BoundTextField },
  { component: BoundTextField },
]

// This describes the table row columns in terms of form templates.
const rowFieldTemplates = [
  {
    fieldKey: 'name',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'date',
    defaultValue: '',
    isRequired: true,
  },
  {
    fieldKey: 'select',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'data1',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'data2',
    defaultValue: false,
  },
  {
    fieldKey: 'data3',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'data4',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'data5',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'data6',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'data7',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'data8',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'data9',
    defaultValue: '',
    isRequired: true
  },
]

const TableEditDemo = () => {
  const refLocalToast = useRef(null)
  const tableRef = useRef(null)
  const refSaveButton = useRef()

  const onChangeTableValue = () => {
    refSaveButton.current.setDisabled(false)
  }

  const { arrRefs, isLoaded, data, formReset, formResetOnPostComplete, rows } = useFormHandler({ 
    service: getService,
    rowFieldTemplates, 
    rowComponents, 
    boundControls: true,
    isFormReset: true
  })

  // Define the below in services
  // Use the function uiPost for the post.
  const postService = postObject => {
    const doPost = changedEntries => {
      refLocalToast.current?.successToastOn({ message: 'Form Saved Successfully', title: 'Form Saved' })
    }
    return new Promise(resolve => {
      const changedEntries = postObject.filter(e => e.modified)
      // eslint-disable-next-line no-console 
      console.log(JSON.stringify(changedEntries, undefined, 2))
      resolve(doPost(changedEntries))
      // setTimeout(() => resolve(doPost(postObject)), 2000)
    })
  }

  if (!isLoaded) {
    return <></>
  }

  return (
    <PageContainer>
      <TopPart>
        Fast Edit Table Demo
      </TopPart>
      <ExpandingContainer>
        <LocalToast ref={refLocalToast} />
        <FastInputTable onChangeTableValue={onChangeTableValue} showHover ref={tableRef} arrRefs={arrRefs} rows={rows} columns={columns} />
      </ExpandingContainer>
      <PageButtonsContainer>
        <Buttons 
          arrRefs={arrRefs} 
          ref={refSaveButton} 
          postService={postService} 
          formTemplate={rowFieldTemplates} 
          data={data} 
          rowComponents={rowComponents} 
          formReset={formReset} 
          formResetOnPostComplete={formResetOnPostComplete} 
        />
      </PageButtonsContainer>
    </PageContainer>
  )
}

export default TableEditDemo
