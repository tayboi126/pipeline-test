import React, { useRef } from 'react'
import styled from 'styled-components'
import { ContainedButton } from 'pwlib/components/controls'
import { BoundLabel, BoundUrl } from 'pwlib/components/formcontrols'
import { TableHeaderTitle } from 'pwlib/components/controls/fastinputtable/Support'
import { useTheme } from 'pwlib/styles'
import PropTypes from 'prop-types'
import { sortColumnTypes } from 'pwlib/common'

import { PageTopContainer } from '../../common'
import GeneralListDisplayPage from '../../controls/GeneralListDisplay'
import { ceg } from '../../../navigation/routePaths'
import { getCegList } from '../../../services/contracts'
import { pageTitleFontSize } from '../../../common/constants'

// Describes the table column headers. Also describes sorting and filtering.
const columns = [
  {
    // Header column label.
    label: 'Customer Name', 
    columnType: sortColumnTypes.builtSelect,
    hasSort: true,
    hasFilter: true,
    align: 'center',
    cellStyle: { whiteSpace: 'nowrap' },
    title: 'The customer associated with the Contract Engine Group.'
  },
  { 
    label: () => <TableHeaderTitle label='Contract Type' width={'50px'} />, 
    columnType: sortColumnTypes.builtSelect,
    hasSort: true,
    hasFilter: true,
    align: 'left',
    title: 'The type of contract. i.e. FMP or MMP.'
  },
  { 
    label: () => <TableHeaderTitle label='Engine Family' width={'40px'} />, 
    columnType: sortColumnTypes.builtSelect,
    hasSort: true,
    hasFilter: true,
    align: 'left',
    cellStyle: { whiteSpace: 'nowrap' },
    title: 'The engine family associated with the Contract Engine Group.'
  },
  { 
    label: () => <TableHeaderTitle label='Report Region' width={'40px'} />, 
    columnType: sortColumnTypes.builtSelect,
    hasSort: true,
    hasFilter: true,
    cellStyle: { whiteSpace: 'nowrap' },
    title: 'The report region associated with the Contract Engine Group.  A report region is user defined and is used to group contracts for reporting purposes.'
  },
  { 
    label: 'Contract Engine Group', 
    align: 'left',
    cellStyle: { whiteSpace: 'nowrap' },
    title: 'The Contract Engine Group description. The Contract Engine Group equates to an engine family group where costs are tied to and it is the level where cost sheet data is defined.',
  },
  { 
    label: () => <TableHeaderTitle label='CEG Details Verified?' width={'50px'} />, 
    cellStyle: { textAlign: 'center' },
    style: { textAlign: 'center' },
    hasSort: true,
    hasFilter: true,
    columnType: sortColumnTypes.builtSelect,
    title: 'Indicates whether the details from AMCIS and the manual selections have been verified.  Marking this selection as "Yes" will freeze the manual selected dropdowns and send the CEG data to all the applicable Aftermarket programs. This selection cannot be undone while a there exists a WIP EAC instance for this CEG, or if there has been an EAC instance marked as "Final".'
  },
  { 
    label: () => <TableHeaderTitle label='EAC Required for this CEG?' width={'70px'} />,
    cellStyle: { textAlign: 'center' },
    style: { textAlign: 'center' },
    hasSort: true,
    hasFilter: true,
    columnType: sortColumnTypes.builtSelect,
    title: 'Indicates whether the discount and other financial factors in the EAC are calculated at this level.'
  },
  { 
    label: () => <TableHeaderTitle label='Cost Sheet' width={'44px'} />,
    cellStyle: { textAlign: 'center' },
    style: { textAlign: 'center' },
    title: 'Click the link to open Contract Cost Sheet Data page for Contract Engine Group.'
  },
  { 
    label: () => <TableHeaderTitle label='CEG Details Verified On?' width={'70px'} />, 
    style: { textAlign: 'left' },
    title: 'Date the CEG details were verified.'
  },
  { 
    label: () => <TableHeaderTitle label='Last Updated in AMCIS On?' width={'66px'} />, 
    style: { textAlign: 'center' },
    title: 'The date of the last time the CEG Detail screen has been updated from AMCIS.'
  },
  { 
    label: () => <TableHeaderTitle label='CEG Inception Date' width={'54px'} />, 
    style: { textAlign: 'center' },
    title: 'The inception date for this Contract Engine Group. The inception date is the date the contract starts. The start date of the contract (a.k.a effective date) where all FMP flight hour billings and coverages begin on eligible engines. This date is used for the spares CLP escalation discount transfer calculation.'
  },
  { 
    label: () => <TableHeaderTitle label='CEG End Date' width={'40px'} />, 
    style: { textAlign: 'center' },
    title: 'The end date for this Contract Engine Group. The end date is the date the contract ends.'
  },
  { 
    label: () => <TableHeaderTitle label='CEG Closed Out Date' width={'52px'} />, 
    style: { textAlign: 'center' },
    title: 'The date the Contract Engine Group is closed-out. A Contract Engine Group is closed-out when all obligations under the contract have been fulfilled.'
  },
  { 
    label: () => <TableHeaderTitle label='Is Used In SPIDRS?' width={'50px'} />,
    cellStyle: { textAlign: 'center' },
    style: { textAlign: 'center' },
    title: 'Indicates whether the Contract Engine Group is used in SPIDRS.'
  },
  { 
    label: () => <TableHeaderTitle label='Used in SPIRIT Actuals?' width={'50px'} />,
    cellStyle: { textAlign: 'center' },
    style: { textAlign: 'center' },
    title: 'Indicates whether the actuals from SPANAS are stored in the SPIRIT database at this level.'
  },
  { 
    label: () => <TableHeaderTitle label='Used in SPIRIT Forecast?' width={'56px'} />,
    cellStyle: { textAlign: 'center' },
    style: { textAlign: 'center' },
    title: 'Indicates whether the forecast data is stored in the SPIRIT database at this level.'
  },
]

const TopPartContainer = styled(PageTopContainer)`
  font-size: ${pageTitleFontSize};
  display: flex;
  align-items: center;
  justify-content: flex-start;
  padding-left: 10px;
`

const ButtonContainer = styled.div`
  position: absolute;
  bottom: 10px;
  right: 10px;
`

const TopPart = props => {
  return (
    <TopPartContainer>
      Contract Engine Group List
      <ButtonContainer>
        <ContainedButton onClick={props.clearFilters}>
          Clear Filters
        </ContainedButton>
      </ButtonContainer>
    </TopPartContainer>
  )
}

TopPart.propTypes = {
  clearFilters: PropTypes.func,
}

// This describes the table row columns in terms of form templates.
const rowFieldTemplates = [
  {
    fieldKey: 'customerName',
    defaultValue: '',
  },
  {
    fieldKey: 'contractTypeShortDesc',
    defaultValue: '',
  },
  {
    fieldKey: 'engineFamilyDesc',
    defaultValue: '',
  },
  {
    fieldKey: 'regionName',
    defaultValue: '',
  },
  {
    fieldKey: 'engineGrpDesc',
    defaultValue: '',
    route: ceg,
    routeValueFieldKey2: 'customerName'
  },
  {
    fieldKey: 'cegVerified',
    defaultValue: false,
  },
  {
    fieldKey: 'isEacDiscCalcLevel',
    defaultValue: false,
  },
  {
    fieldKey: 'costSheet',
    defaultValue: '',
  },
  {
    fieldKey: 'cegVerifiedDate',
    defaultValue: '',
  },
  {
    fieldKey: 'updateTm',
    defaultValue: '',
  },
  {
    fieldKey: 'inceptionDate',
    defaultValue: '',
  },
  {
    fieldKey: 'endDate',
    defaultValue: '',
  },
  {
    fieldKey: 'closedOutDate',
    defaultValue: '',
  },
  {
    fieldKey: 'isUsedInSpidrs',
    defaultValue: false,
  },
  {
    fieldKey: 'isUsedInSpiritActuals',
    defaultValue: false,
  },
  {
    fieldKey: 'isUsedInSpiritForecast',
    defaultValue: false,
  },
]

const Contracts = () => {
  const theme = useTheme()
  // This describes the table row columns in terms of the form controls.
  const rowComponents = [
    { component: BoundLabel }, // customerName
    { component: BoundLabel }, // contractTypeShortDesc
    { component: BoundLabel }, // engineFamilyDesc
    { component: BoundLabel }, // regionName
    { component: BoundUrl, props: { linkColor: theme.palette.linkColor } }, // engineGrpDesc
    { component: BoundLabel }, // cegVerified
    { component: BoundLabel }, // isEacDiscCalcLevel
    { component: BoundUrl, props: { linkColor: theme.palette.linkColor } }, // costSheet
    { component: BoundLabel }, // cegVerifiedDate
    { component: BoundLabel }, // updateTm
    { component: BoundLabel }, // inceptionDate
    { component: BoundLabel }, // endDate
    { component: BoundLabel }, // closedOutDate
    { component: BoundLabel }, // isUsedInSpidrs
    { component: BoundLabel }, // isUsedInSpiritActuals
    { component: BoundLabel }, // isUsedInSpiritForecast
  ]

  const refGeneralListDisplayPage = useRef()

  const clearFilters = () => {
    refGeneralListDisplayPage.current.clearFilters()
  }

  return (
    <GeneralListDisplayPage
      ref={refGeneralListDisplayPage}
      rowFieldTemplates={rowFieldTemplates}
      rowComponents={rowComponents}
      columns={columns}
      getService={getCegList}
      topPart={<TopPart clearFilters={clearFilters} />}
      defaultSortIndex={0}
      isStriped
    />
  )
}

export default Contracts
