import React, { useRef, forwardRef, useImperativeHandle, useEffect } from 'react'
import { useSearchParams, useConstructor } from 'pwlib/hooks'
import { urlTarget, urlTarget2, todayLocal } from 'pwlib/common'
import PropTypes from 'prop-types'
import { BoundCheckBox, BoundTextField, setFieldDisabled, getFieldValue, setFieldValue } from 'pwlib/components/formcontrols'
import { YDivider, XDivider, FlexByRow, FlexByRowCenteredVertical } from 'pwlib/styles'
import { useNavigate, useLocation } from 'react-router-dom'
import { openConfirmationDialog, openInformationDialog } from 'pwlib/containers'

import { contracts } from '../../../navigation/routePaths'
import GeneralEditForm from '../../controls/GeneralEditForm'
import { PageTopContainer, FormHalfScreenLeft, FormHalfScreenRight, TableFormDescriptionAndField, FormBodyContainer, FormButtonsWithCancel, FormTable } from '../../common'
import { saveCeg, deleteCeg, getCeg, getAmcisCeg } from '../../../services/contracts'
import { getEac } from '../../../services/eac'
import { eacWipStatus } from '../../../common/conversions'
import Panel, { PanelDivider } from '../../controls/Panel'

const deleteCegMessage = 'The ceg is not connected to an EAC. So, this operation will delete the ceg from NGF permanently. Are you sure you want to do this?'

const formTemplate = [
  {
    fieldKey: 'customerName',
    defaultValue: '',
    disabled: true,
    isRequired: true
  },
  {
    fieldKey: 'contractTypeShortDesc',
    defaultValue: '',
    disabled: true
  },
  {
    fieldKey: 'engineFamilyDesc',
    defaultValue: '',
    disabled: true
  },
  {
    fieldKey: 'engineGrpDesc',
    defaultValue: '',
    disabled: true
  },
  {
    fieldKey: 'inceptionMonth',
    defaultValue: '',
    disabled: true
  },
  {
    fieldKey: 'inceptionYear',
    defaultValue: '',
    disabled: true
  },
  {
    fieldKey: 'excelRptWorksheetName ',
    defaultValue: '',
    disabled: true
  },
  {
    fieldKey: 'endMonth',
    defaultValue: '',
    disabled: true
  },
  {
    fieldKey: 'endYear',
    defaultValue: '',
    disabled: true
  },
  {
    fieldKey: 'regionName',
    defaultValue: '',
    disabled: true
  },
  {
    fieldKey: 'closedOutMonth',
    defaultValue: '',
    disabled: true
  },
  {
    fieldKey: 'closedOutYear',
    defaultValue: '',
    disabled: true
  },
  {
    fieldKey: 'doesPartnerShareInDiscount',
    defaultValue: false,
    disabled: true
  },
  {
    fieldKey: 'doesPartnerShareInServiceSales',
    defaultValue: false,
    disabled: true
  },
  {
    fieldKey: 'isUsedInSpidrs',
    defaultValue: false,
    disabled: true
  },
  {
    fieldKey: 'isUsedInSpiritForecast',
    defaultValue: false,
    disabled: true
  },
  {
    fieldKey: 'isUsedInSpiritActuals',
    defaultValue: false,
    disabled: true
  },
  {
    fieldKey: 'isLlpCovered',
    defaultValue: false,
    disabled: true
  },
  {
    fieldKey: 'comments',
    defaultValue: '',
    disabled: true
  },
  {
    fieldKey: 'isEacDiscCalcLevel',
    defaultValue: false,
  },
  {
    fieldKey: 'isRetroFitKitCovered',
    defaultValue: false,
  },
  {
    fieldKey: 'isEligibleForNearWingSv',
    defaultValue: false,
  },
  {
    fieldKey: 'cegVerified',
    defaultValue: false,
  },
  {
    fieldKey: 'cegVerifiedDate',
    defaultValue: '',
    disabled: true
  },
  {
    fieldKey: 'cegComments',
    defaultValue: '',
  },
  {
    fieldKey: 'llpExclusivity',
    defaultValue: false,
    disabled: true
  },
  {
    fieldKey: 'isUsedInBacklog',
    defaultValue: false,
    disabled: true
  },
]

const CUSTOMER_FIELD = 0
const CONTRACT_TYPE_FIELD = 1
const ENGINE_FAMILY_FIELD = 2
const ENGINE_GROUP_DESC_FIELD = 3
const INCEPTION_MONTH_FIELD = 4
const INCEPTION_YEAR_FIELD = 5
const EXCEL_RPT_FIELD = 6
const END_MONTH_FIELD = 7
const END_YEAR_FIELD = 8
const REGION_FIELD = 9
const CLOSED_OUT_MONTH_FIELD = 10
const CLOSED_OUT_YEAR_FIELD = 11
const PARTNER_SHARE_IN_DISCOUNT_FIELD = 12
const PARTNER_SHARE_IN_SERVICE_SALES_FIELD = 13
const USED_IN_SPIDRS_FIELD = 14
const USED_IN_SPIRIT_FORECAST_FIELD = 15
const USED_IN_SPIRIT_ACTUALS_FIELD = 16
const LLP_COVERED_FIELD = 17
const COMMENTS_FIELD = 18
const EAC_REQUIRED_FIELD = 19
const RETROFIT_COVERED_FIELD = 20
const NEAR_WING_FIELD = 21
const CEG_VERIFIED_FIELD = 22
const CEG_VERIFIED_DATE_FIELD = 23
const CEG_COMMENTS_FIELD = 24
const LLP_EXCLUSIVITY_FIELD = 25
const IS_USED_IN_BACKLOG_FIELD = 26

const MonthYear = props => {
  const style = { paddingRight: '8px', marginTop: '4px' }
  const textStyle = { width: '50px' }

  return (
    <FlexByRowCenteredVertical>
      <div style={style}>Month:</div>
      <BoundTextField {...props.formProps(props.monthField)} style={textStyle} />
      <XDivider width='10px' />
      <div style={style}>Year:</div>
      <BoundTextField {...props.formProps(props.yearField)} style={textStyle} />
    </FlexByRowCenteredVertical>
  )
}

MonthYear.propTypes = {
  formProps: PropTypes.func,
  monthField: PropTypes.number,
  yearField: PropTypes.number,
}

const FormBody = props => {
  const { formProps } = props
  const boldStyle = { fontWeight: 900 }
  const checkboxStyle = { padding: '2px', marginLeft: '-2px' }
  const initialCegVerified = useRef(false)
  const refHandleChangeCegVerified = useRef(false)
  const refMultiTextFieldStyle = useRef({ padding: '6px 0px' })

  useEffect(() => {
    initialCegVerified.current = getFieldValue(formProps(CEG_VERIFIED_FIELD))
  }, [])

  const handleChangeCegVerified = value => {
    if (refHandleChangeCegVerified.current) {
      return
    }
    refHandleChangeCegVerified.current = true
    // If the cegVerified flag was on in NGF and it is being turned off, proceed with additional logic.
    if (!value && initialCegVerified.current) {
      if (props.isWipEacs) {
        setFieldValue(formProps(CEG_VERIFIED_FIELD), true, true)
        openInformationDialog('Please delete WIP EACs connected to this CEG before unchecking CEG Details Verified flag.')
        refHandleChangeCegVerified.current = false
        return
      } else {
        // This means there are no eacs connected to this ceg.
        props.handleChangeCegVerified(value)
      }
    } else if (value && initialCegVerified.current) {
      props.handleChangeCegVerified(value)
    }
    setFieldDisabled(formProps(EAC_REQUIRED_FIELD), value)
    setFieldDisabled(formProps(RETROFIT_COVERED_FIELD), value)
    setFieldDisabled(formProps(NEAR_WING_FIELD), value)
    setFieldDisabled(formProps(RETROFIT_COVERED_FIELD), value)
    setFieldValue(formProps(CEG_VERIFIED_DATE_FIELD), value ? todayLocal() : '')
    formProps(CEG_VERIFIED_FIELD).onChange(value, 'cegVerified', CEG_VERIFIED_FIELD)
    refHandleChangeCegVerified.current = false
  }

  useEffect(() => {
    // If the ceg verified field is checked in the NGF database then disable the fields below.
    if (getFieldValue(formProps(CEG_VERIFIED_FIELD))) {
      setFieldDisabled(formProps(EAC_REQUIRED_FIELD), true)
      setFieldDisabled(formProps(RETROFIT_COVERED_FIELD), true)
      setFieldDisabled(formProps(NEAR_WING_FIELD), true)
    }
  }, [])
  
  return (
    <FormBodyContainer >
      <Panel title='AMCIS Details'>
        <FlexByRow>
          <FormHalfScreenLeft>
            <FormTable>
              <TableFormDescriptionAndField
                fieldDescription='Customer'
                field={<BoundTextField {...formProps(CUSTOMER_FIELD)} />}
                title='The customer associated with the contract.'
              />
              <TableFormDescriptionAndField
                fieldDescription='Engine Family'
                field={<BoundTextField {...formProps(ENGINE_FAMILY_FIELD)} />}
                title='The engine family associated with the Contract Engine Group.'
              />
              <TableFormDescriptionAndField
                fieldDescription='CEG Inception Date'
                field={<MonthYear formProps={formProps} monthField={INCEPTION_MONTH_FIELD} yearField={INCEPTION_YEAR_FIELD} />}
                title='The inception date for this Contract Engine Group. The inception date is the date the contract starts.  The start date of the contract (a.k.a effective date) where all FMP flight hour billings and coverages begin on eligible engines. This date is used for the spares CLP escalation discount transfer calculation.'
              />
              <TableFormDescriptionAndField
                fieldDescription='CEG End Date'
                field={<MonthYear formProps={formProps} monthField={END_MONTH_FIELD} yearField={END_YEAR_FIELD} />}
                title='The end date for this Contract Engine Group.  The end date is the date that the contract ends.'
              />
              <TableFormDescriptionAndField
                fieldDescription='CEG Closed Out Date'
                field={<MonthYear formProps={formProps} monthField={CLOSED_OUT_MONTH_FIELD} yearField={CLOSED_OUT_YEAR_FIELD} />}
                title='The date the Contract Engine Group is closed-out.  A Contract Engine Group is closed-out when all obligations under the contract have been fulfilled.'
              />
            </FormTable>
          </FormHalfScreenLeft>
          <FormHalfScreenRight>
            <FormTable>
              <TableFormDescriptionAndField
                fieldDescription='Contract Type'
                field={<BoundTextField {...formProps(CONTRACT_TYPE_FIELD)} />}
                title='The type of contract. i.e. FMP or MMP.'
              />
              <TableFormDescriptionAndField
                fieldDescription='Engine Group Description'
                field={<BoundTextField {...formProps(ENGINE_GROUP_DESC_FIELD)} />}
                title='The Contract Engine Group description. The Contract Engine Group (CEG) equates to an engine family group where costs are tied to and it is the level where cost sheet data is defined.'
              />
              <TableFormDescriptionAndField
                fieldDescription='Excel Report Name'
                field={<BoundTextField {...formProps(EXCEL_RPT_FIELD)} />}
                title='The name that should be used for the Excel worksheet for this Contract Engine Group when  reporting in Excel.'
              />
              <TableFormDescriptionAndField
                fieldDescription='Report Region'
                field={<BoundTextField {...formProps(REGION_FIELD)} />}
                title='The report region associated with the Contract Engine Group. A report region is user defined and is used to group contracts for reporting purposes.'
              />
            </FormTable>
          </FormHalfScreenRight>
        </FlexByRow>
        <YDivider height='4px' />
        <FlexByRow>
          <FormHalfScreenLeft>
            <FormTable>
              <TableFormDescriptionAndField
                padding='0px'
                fieldDescription='Partner Share In Discount?'
                field={<BoundCheckBox style={checkboxStyle} {...formProps(PARTNER_SHARE_IN_DISCOUNT_FIELD)} />}
                title='Checked if Partner Share of Service Sales should be calculated in the forecast of this Contract Engine Group.'
              />
              <TableFormDescriptionAndField
                padding='0px'
                fieldDescription='Partner Share In Service Sales?'
                field={<BoundCheckBox style={checkboxStyle} {...formProps(PARTNER_SHARE_IN_SERVICE_SALES_FIELD)} />}
                title='Checked if Partner Share of Service Sales should be calculated in the forecast of this Contract Engine Group.'
              />
              <TableFormDescriptionAndField
                padding='0px'
                fieldDescription='Used in Spirit Forecast?'
                field={<BoundCheckBox style={checkboxStyle} {...formProps(USED_IN_SPIRIT_FORECAST_FIELD)} />}
                title='Checked if the forecast data is stored in the SPIRIT database at this level.'
              />
              <TableFormDescriptionAndField
                padding='0px'
                fieldDescription='Used in Spirit Actuals?'
                field={<BoundCheckBox style={checkboxStyle} {...formProps(USED_IN_SPIRIT_ACTUALS_FIELD)} />}
                title='Checked if the actuals from SPANAS are stored in the SPIRIT database at this level.'
              />
            </FormTable>
          </FormHalfScreenLeft>
          <FormHalfScreenRight>
            <FormTable>
              <TableFormDescriptionAndField
                padding='0px'
                fieldDescription='Used in SPIDRS?'
                field={<BoundCheckBox style={checkboxStyle} {...formProps(USED_IN_SPIDRS_FIELD)} />}
                title='Indicates if the Contract Engine Group is used in SPIDRS.'
              />
              <TableFormDescriptionAndField
                padding='0px'
                fieldDescription='Is LLP Covered?'
                field={<BoundCheckBox style={checkboxStyle} {...formProps(LLP_COVERED_FIELD)} />}
                title='Indicates if all or a portion of the LLPs are covered for the Contract Engine Group via an LLP Rate.'
              />
              <TableFormDescriptionAndField
                padding='0px'
                fieldDescription='LLP Exclusivity?'
                field={<BoundCheckBox style={checkboxStyle} {...formProps(LLP_EXCLUSIVITY_FIELD)} />}
                title='Indicates if all or a portion of the LLPs are covered for the Contract Engine Group via T&M calcuations.'
              />
              <TableFormDescriptionAndField
                padding='0px'
                fieldDescription='Used in Backlog?'
                field={<BoundCheckBox style={checkboxStyle} {...formProps(IS_USED_IN_BACKLOG_FIELD)} />}
                title='Indicated is the Contract Engine Group is used in the Backlog in Next Gen Finance.  The revenue backlog refers to the estimated remaining sales (i.e. "Total P&W Sales Net of Discount") that will be recognized on all contracts where sales need to be recorded.'
              />
            </FormTable>
          </FormHalfScreenRight>
        </FlexByRow>
        <FormTable>
          <tr>
            <td style={{ width: '100px' }}><div title='Any comments associated with the Contract Engine Group.'>Comments:</div></td>
            <td><BoundTextField style={refMultiTextFieldStyle.current} {...formProps(COMMENTS_FIELD)} multiline rows={2} variant='outlined' /></td>
          </tr>
        </FormTable>
      </Panel>
      <PanelDivider />
      <Panel title='Editable Details'>
        <FlexByRow>
          <FormHalfScreenLeft>
            <FormTable>
              <TableFormDescriptionAndField
                fieldDescription='EAC required for this CEG?'
                field={<BoundCheckBox style={checkboxStyle} {...formProps(EAC_REQUIRED_FIELD)} />}
                title='Check if the discount and other financial factors in the EAC are calculated at this level.'
              />
              <TableFormDescriptionAndField
                fieldDescription='Is Retrofit Kit Covered?'
                field={<BoundCheckBox style={checkboxStyle} {...formProps(RETROFIT_COVERED_FIELD)} />}
                title='Indicates if retrofit kit is covered by the Contract Engine Group. Used when loading shop visit related data from ICE.'
              />
              <TableFormDescriptionAndField
                fieldDescription='Eligible For Near Wing Shop Visits?'
                field={<BoundCheckBox style={checkboxStyle} {...formProps(NEAR_WING_FIELD)} />}
                title='Indicates if the Contract Engine Group is eligible for near wing shop visits. Near wing refers to a shop visit where the engine is not actually inducted into the shop. Used when loading shop visit related data from ICE. When performing the load of shop visit related data from ICE, if "Eligible For Near Wing Shop Visits?" = false, the "NEAR WING" shop visits will not be loaded as separate shop visit categories and any shop visit forecast for "NEAR WING" will be moved to "NON FOD".'
              />
            </FormTable>
          </FormHalfScreenLeft>
          <FormHalfScreenRight>
            <FormTable>
              <TableFormDescriptionAndField
                style={boldStyle}
                fieldDescription='CEG Details Verified?'
                field={<BoundCheckBox disabled={props.hasNonWipEacs} {...formProps(CEG_VERIFIED_FIELD)} onChange={handleChangeCegVerified} />}
                title='Indicates if the details from AMCIS and the manual selections have been verified.  Marking this selection as "Yes" will freeze the manual selected dropdowns and send the CEG data to all the applicable Aftermarket programs. This selection cannot be undone while a there exists a WIP EAC instance for this CEG, or if there has been an EAC instance marked as "Final".'
              />
              <TableFormDescriptionAndField
                fieldDescription='CEG Details Verified On?'
                field={<BoundTextField {...formProps(CEG_VERIFIED_DATE_FIELD)} />}
                title='Date the CEG details were verified.'
              />
            </FormTable>
          </FormHalfScreenRight>
        </FlexByRow>
        <FormTable>
          <tr>
            <td style={{ width: '100px' }}><div title='Comments to be entered by finance analysts specific to this CEG.'>Comments:</div></td>
            <td><BoundTextField style={refMultiTextFieldStyle.current} {...formProps(CEG_COMMENTS_FIELD)} multiline rows={2} variant='outlined' /></td>
          </tr>
        </FormTable>
      </Panel>
    </FormBodyContainer>
  )
}

FormBody.propTypes = {
  formProps: PropTypes.func,
  hasNonWipEacs: PropTypes.bool,
  isWipEacs: PropTypes.bool,
  handleChangeCegVerified: PropTypes.func,
}

const Ceg = () => {
  const location = useLocation()
  const navState = location.state
  const searchParams = useSearchParams()
  const engineFamilyDesc = searchParams.get(urlTarget)
  const customer = searchParams.get(urlTarget2)
  const refGetService = useRef()
  const refEacs = useRef([])
  const refInternalButtons = useRef()
  const navigate = useNavigate()
  const isDeleteCeg = useRef(false)

  useConstructor(() => {
    refGetService.current = async () => {
      let result
      // The ceg is in the NGF database.
      if (!navState.isAmcis) {
        // Run in parallel.
        result = await Promise.all([
          getCeg(customer, engineFamilyDesc),
          getEac(customer, engineFamilyDesc)
        ])
        // Eac information is used for additional business logic.
        refEacs.current = result[1]
        result = result[0]
      // The ceg is not in the NGF database so get it from amcis. 
      } else {
        result = await getAmcisCeg(customer, engineFamilyDesc)
        result.isRetroFitKitCovered = true
        result.isEligibleForNearWingSv = true
        result.isEacDiscCalcLevel = true
      }
      return result
    }
  })

  const internalDeleteCeg = async engineGrpDesc => {
    openConfirmationDialog({ 
      onOk: async () => {
        // Delete the ceg from NGF.
        await deleteCeg(engineGrpDesc)
        // The ceg is now gone so navigate back to the ceg list.
        navigate(contracts)
      },
      message: deleteCegMessage,
      title: 'Delete CEG'
    })
  }

  const postService = async postObject => {
    const finalPostObject = {
      isRetroFitKitCovered: postObject.isRetroFitKitCovered,
      isEligibleForNearWingSv: postObject.isEligibleForNearWingSv,
      isEacDiscCalcLevel: postObject.isEacDiscCalcLevel,
      cegVerified: postObject.cegVerified,
      cegVerifiedDate: postObject.cegVerifiedDate,
      cegComments: postObject.cegComments,
      engineFamilyDesc
    }

    if (isDeleteCeg.current) {
      internalDeleteCeg(postObject.engineGrpDesc)
      return false
    } else {
      await saveCeg(finalPostObject)
      return true
    }
  }

  const handleChangeCegVerified = value => {
    if (!value) {
      isDeleteCeg.current = true
      refInternalButtons.current.setSaveButtonText('Delete CEG')
    } else {
      isDeleteCeg.current = false
      refInternalButtons.current.setSaveButtonText(undefined)
    }
  }

  const isWipEacs = () => {
    if (refEacs.current.length === 0) {
      return false
    }
    let result = true
    for (let i = 0; i < refEacs.current.length; ++i) {
      result = result && refEacs.current[i].status === eacWipStatus
    }
    return result
  }

  const hasNonWipEacs = () => {
    if (refEacs.current.length === 0) {
      return false
    }
    let result = false
    for (let i = 0; i < refEacs.current.length; ++i) {
      result = result || refEacs.current[i].status !== eacWipStatus
    }
    return result
  }

  const InternalButtons = forwardRef((props, ref) => {
    useImperativeHandle(ref, () => ({
      ...refInternalButtons.current,
      setSaveButtonText: text => refInternalButtons.current.setSaveButtonText(text)
    }), [])

    const handleCancel = () => {
      navigate(contracts)
    }

    return (
      <FormButtonsWithCancel {...props} ref={refInternalButtons} onCancel={handleCancel} />
    )
  })

  return (
    <GeneralEditForm
      topPart={<PageTopContainer>Contract Engine Group</PageTopContainer>}
      formTemplate={formTemplate}
      getService={refGetService.current}
      postService={postService}
      saveMessageTitle='Ceg Form Saved'
      saveMessage='Ceg Form Saved Successfully'
      formBody={props => <FormBody {...props} handleChangeCegVerified={handleChangeCegVerified} isWipEacs={isWipEacs()} hasNonWipEacs={hasNonWipEacs()} />}
      buttons={InternalButtons}
    />
  )
}

export default Ceg