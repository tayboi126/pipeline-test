import React from 'react'
import { act } from '@testing-library/react'
import { BasicTestWrapper } from '../../../../test/support'
import { mockFetch, mockFetchRestore } from 'pwlib/test/support/mockfetch'
import assert from 'assert'
import { mount } from 'enzyme'
import Contracts from '../'
import { getAmcisCegListUrl, getCegsListUrl } from '../../../../services/contracts'
import { getCegsListMock, getAmcisCegListMock } from '../../../../services/mockData/contracts'
import { findBySelector, findNodeByType } from '../../../../pwlib/src/test/support'

const columnData = [
  'Air Canada',
  'FMP'
]

const TestComponent = () => {
  return (
    <BasicTestWrapper>
      <Contracts />
    </BasicTestWrapper>
  )
}

describe('Test', () => {
  let wrapper
  let tableNode
  beforeAll(() => {
    // Mock the api calls. If you have more than one url to mock, use arrays for both arguments.
    mockFetch(
      // Urls
      [
        getCegsListUrl,
        getAmcisCegListUrl
      ], 
      // Correpsonding Mocks
      [
        getCegsListMock,
        getAmcisCegListMock
      ]
    )
  })

  it('Should mount', async () => {
    await act(async () => {
      wrapper = mount(<TestComponent />)
      assert(wrapper)
    })
  })

  it('Fast Input table should be initialized with values in table data', async () => {
    tableNode = await findBySelector('#FastInputTable', wrapper)
  })

  for (let i = 0; i < columnData.length; ++i) {
    it(`Verify ceg list column ${i + 1}`, async () => {
      const column = await findNodeByType(`#tableEntry-0-${i}`, 'div', tableNode)
      assert(columnData[i] === column.text())
    })
  }

  afterAll(() => {
    wrapper.unmount()
    mockFetchRestore()
  })
})