import React from 'react'
import { act } from '@testing-library/react'
import { BasicTestWrapper, setUseLocationObject } from '../../../../test/support'
import { mockFetch, mockFetchRestore } from 'pwlib/test/support/mockfetch'
import assert from 'assert'
import { mount } from 'enzyme'
import Ceg from '../ceg'
import { getAmcisCegListUrl, getCegsListUrl } from '../../../../services/contracts'
import { getCegsListMock, getAmcisCegListMock } from '../../../../services/mockData/contracts'

const TestComponent = () => {
  return (
    <BasicTestWrapper>
      <Ceg />
    </BasicTestWrapper>
  )
}

describe('Test', () => {
  let wrapper
  beforeAll(() => {
    setUseLocationObject({
      search: "target=AEE_FMPN_2019&target2=Aegean%20Airlines'",
      state: { isAmcis: true },
    })
    // Mock the api calls. If you have more than one url to mock, use arrays for both arguments.
    mockFetch(
      // Urls
      [
        getCegsListUrl,
        getAmcisCegListUrl
      ], 
      // Correpsonding Mocks
      [
        getCegsListMock,
        getAmcisCegListMock
      ]
    )
  })

  it('Should mount', async () => {
    await act(async () => {
      wrapper = mount(<TestComponent />)
      assert(wrapper)
    })
  })

  afterAll(() => {
    wrapper.unmount()
    mockFetchRestore()
  })
})