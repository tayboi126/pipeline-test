import React, { useRef, forwardRef, useImperativeHandle } from 'react'
import PropTypes from 'prop-types'
import styled from 'styled-components'

import { FlexByRow, XDivider, YDivider, HalfScreen } from 'pwlib/styles'
import { MainRoutePage } from '../appcontrol/RoutePage'
import { BoundTextField, BoundDateTime, BoundSelect, BoundCheckBox, ClearButton, SaveButton, ResetButton, BoundMultiSelectWithCheckboxes, BoundLabel } from 'pwlib/components/formcontrols'
import { useFormHandler } from 'pwlib/hooks'
import * as regx from 'pwlib/components/formcontrols/'
import { today } from 'pwlib/common'
import { LocalToast } from 'pwlib/containers'

const selectItems = [
  { value: '10', label: 'select1' },
  { value: '20', label: 'select2' },
  { value: '30', label: 'select3' },
  { value: '40', label: 'select4' },
  { value: '50', label: 'select5' }
]

const mockGetObject = {
  name: 'John Doe',
  address: '1137 6th Street',
  select: '10',
  multiSelect: ['10'],
  date: '2021-12-31',
  autocomplete: 'UG',
  labelField: 'Label Field Test' 
}

const formTemplate = [
  {
    label: 'Name',
    fieldKey: 'name',
    defaultValue: '',
    isRequired: true,
    startString: 'anyPretext',
    validator: value => {
      if (value.length > 20) {
        return 'Textfield must be less than 20 characters.'
      }
      return ''
    },
    regx: regx.alphanumericRegex,
    regxError: regx.alphanumericRegexError
  },
  {
    label: 'Address',
    fieldKey: 'address',
    defaultValue: '',
    isRequired: true,
    maxLength: 25
  },
  {
    label: 'Select Demo',
    fieldKey: 'select',
    defaultValue: '',
    isRequired: true
  },
  {
    label: 'Date 1',
    fieldKey: 'date',
    defaultValue: '',
    isRequired: true
  },
  {
    label: 'Date 2',
    fieldKey: 'date2',
    defaultValue: today,
    isRequired: true
  },
  {
    label: 'Date 3',
    fieldKey: 'date3',
    defaultValue: '',
    onAfterGet: value => !value ? today() : value,
    isRequired: true
  },
  {
    label: 'Multi Select Demo',
    fieldKey: 'multiSelect',
    defaultValue: [],
    isRequired: true,
    onBeforePost: value => {
      return value.join()
    }
  },
  {
    label: 'Checkbox',
    fieldKey: 'checkbox',
    defaultValue: true,
  },
  {
    label: 'Label Field',
    fieldKey: 'labelField',
    defaultValue: '',
  },
]


const VerticalDivider = () =>
  <YDivider height='50px' />

const Buttons = forwardRef((props, ref) => {
  const refSaveButton = useRef()
  const refResetButton = useRef()

  const disableButtons = disabled => {
    refSaveButton.current.setDisabled(disabled)
    refResetButton.current && refResetButton.current.setDisabled(disabled)
  }

  const onPostComplete = () => {
    props.formResetOnPostComplete && props.formResetOnPostComplete()
    disableButtons(true)
  }
  
  const formReset = () => {
    props.formReset()
    disableButtons(true)
  }

  useImperativeHandle(ref, () => ({
    setDisabled: disabled => disableButtons(disabled)
  }))

  return (
    <div style={{ paddingRight: '20px' }}>
      {props.formReset && 
        <>
          <ResetButton ref={refResetButton} disabled onClick={formReset} />
          <XDivider width='10px' />
        </>
      }
      <ClearButton arrRefs={props.arrRefs} />
      <XDivider width='10px' />
      <SaveButton ref={refSaveButton} disabled feedBack onPostComplete={onPostComplete} arrRefs={props.arrRefs} formTemplate={props.formTemplate} postService={props.postService} boundControls={props.boundControls} data={props.data} />
    </div>
  )
})

Buttons.propTypes = {
  arrRefs: PropTypes.array,
  postService: PropTypes.func,
  boundControls: PropTypes.bool,
  data: PropTypes.object,
  formTemplate: PropTypes.array,
  formReset: PropTypes.func, 
  formResetOnPostComplete: PropTypes.func,
}

const PageContainer = styled.div`
  width: 100%;
  padding: 20px 20px 0px 20px;
`

// Use the function basehttp.get for the get in your service.
const getService = () => {
  // This simulates a basehttp.get.
  return new Promise(resolve => {
    setTimeout(() => {
      resolve(mockGetObject)
    }, 2000)
  })
}

const NAME_FIELD = 0
const ADDRESS_FIELD = 1
const SELECT_FIELD = 2
const DATE_FIELD = 3
const DATE_FIELD2 = 4
const DATE_FIELD3 = 5
const MULTI_SELECT_FIELD = 6
const CHECKBOX_FIELD = 7
const LABEL_FIELD = 8

// This has an edit feature. So, a getService must be defined to retrieve the data from the server.
const FormEditDemo = () => {
  const refLocalToast = useRef(null)
  const refSaveButton = useRef()

  const onChange = () => {
    refSaveButton.current.setDisabled(false)
  }

  const { arrRefs, formProps, data, isLoaded, formReset, formResetOnPostComplete } = useFormHandler({ 
    formTemplate, 
    service: getService,
    onChange,
    boundControls: true,
    isFormReset: true
  })

  // Defined the below in services
  // Use the function uiPost for the post.
  const postService = postObject => {
    const doPost = postObject => {
      // eslint-disable-next-line no-console
      console.log(JSON.stringify(postObject, undefined, 2))
      refLocalToast.current?.successToastOn({ message: 'Form Saved Successfully', title: 'Form Saved' })
    }
    return new Promise(resolve => {
      setTimeout(() => resolve(doPost(postObject)), 2000)
    })
  }

  if (!isLoaded) {
    return <></>
  }

  return (
    <MainRoutePage 
      mainTitle='Form Demo' 
      buttons={<Buttons ref={refSaveButton} formTemplate={formTemplate} arrRefs={arrRefs} postService={postService} boundControls data={data} formReset={formReset} formResetOnPostComplete={formResetOnPostComplete} />}
      rightButtons
      style={{ paddingTop: '20px' }}
    >
      <PageContainer>
        <LocalToast ref={refLocalToast} />
        <FlexByRow>
          <HalfScreen>
            <BoundTextField
              {...formProps(NAME_FIELD)}
            />
            <VerticalDivider />
            <BoundTextField
              {...formProps(ADDRESS_FIELD)}
            />
            <VerticalDivider />  
            <BoundSelect
              {...formProps(SELECT_FIELD)}
              items={selectItems}
            />
            <VerticalDivider />  
            <BoundMultiSelectWithCheckboxes
              items={selectItems}
              {...formProps(MULTI_SELECT_FIELD)}
            />
          </HalfScreen>
          <XDivider width='50px' />
          <HalfScreen>
            <BoundDateTime
              {...formProps(DATE_FIELD)}
              type='date'
            />
            <VerticalDivider />  
            <BoundDateTime
              {...formProps(DATE_FIELD2)}
              type='date'
            />
            <VerticalDivider />  
            <BoundDateTime
              {...formProps(DATE_FIELD3)}
              type='date'
            />
            <VerticalDivider /> 
            <BoundCheckBox
              {...formProps(CHECKBOX_FIELD)}
            />
            <BoundLabel
              {...formProps(LABEL_FIELD)}
            />
          </HalfScreen>
        </FlexByRow>
      </PageContainer>
    </MainRoutePage>
  )
}

export default FormEditDemo