import React, { useRef, forwardRef, useImperativeHandle } from 'react'
import PropTypes from 'prop-types'
import styled from 'styled-components'
import { FlexByRow, XDivider, YDivider, HalfScreen, FlexByRowCentered } from 'pwlib/styles'
import { BoundTextField, BoundDateTime, BoundSelect, BoundCheckBox, ClearButton, SaveButton, ResetButton, CancelButton, BoundMultiSelectWithCheckboxes, BoundLabel } from 'pwlib/components/formcontrols'
import * as regx from 'pwlib/components/formcontrols/'
import { today } from 'pwlib/common'

import { PageTopContainer } from '../common'
import GeneralEditForm from '../controls/GeneralEditForm'

const selectItems = [
  { value: '10', label: 'select1' },
  { value: '20', label: 'select2' },
  { value: '30', label: 'select3' },
  { value: '40', label: 'select4' },
  { value: '50', label: 'select5' }
]

const mockGetObject = {
  name: 'John Doe',
  address: '1137 6th Street',
  select: '10',
  multiSelect: ['10'],
  date: '2021-12-31',
  autocomplete: 'UG',
  labelField: 'Label Field Test' 
}

const formTemplate = [
  {
    label: 'Name',
    fieldKey: 'name',
    defaultValue: '',
    isRequired: true,
    startString: 'anyPretext',
    validator: value => {
      if (value.length > 20) {
        return 'Textfield must be less than 20 characters.'
      }
      return ''
    },
    regx: regx.alphanumericRegex,
    regxError: regx.alphanumericRegexError,
    // Route to go to for the BoundUrl component
    // route: ''
    // For the BoundUrl component, given the route above as '/test' for example,
    // then BoundUrl gets the value in the srcObject at routeValueFieldKey or value = srcObject[routeValueFieldKey].
    // Then the route and parameter is `/test?target=${value}`. Otherwise, the default  `/test?target=${srcObject[fieldKey]}` is used
    // routeValueFieldKey
  },
  {
    label: 'Address',
    fieldKey: 'address',
    defaultValue: '',
    isRequired: true,
    maxLength: 25
  },
  {
    label: 'Select Demo',
    fieldKey: 'select',
    defaultValue: '',
    isRequired: true
  },
  {
    label: 'Date 1',
    fieldKey: 'date',
    defaultValue: '',
    isRequired: true
  },
  {
    label: 'Date 2',
    fieldKey: 'date2',
    defaultValue: today,
    isRequired: true
  },
  {
    label: 'Date 3',
    fieldKey: 'date3',
    defaultValue: '',
    onAfterGet: value => !value ? today() : value,
    isRequired: true
  },
  {
    label: 'Multi Select Demo',
    fieldKey: 'multiSelect',
    defaultValue: [],
    isRequired: true,
    onBeforePost: value => {
      return value.join()
    }
  },
  {
    label: 'Checkbox',
    fieldKey: 'checkbox',
    defaultValue: true,
  },
  {
    label: 'Label Field',
    fieldKey: 'labelField',
    defaultValue: '',
  },
]

const TopPart = styled(PageTopContainer)`
`

const FormBodyContainer = styled(FlexByRow)`
  padding: 20px 20px 0px 20px;
`

const ButtonsContainer = styled(FlexByRowCentered)`
  height: 60px;
`

const VerticalDivider = () =>
  <YDivider height='50px' />

const Buttons = forwardRef((props, ref) => {
  const refSaveButton = useRef()
  const refResetButton = useRef()
  const refCancelButton = useRef()
  
  const disableButtons = disabled => {
    refSaveButton.current.setDisabled(disabled)
    refResetButton.current && refResetButton.current.setDisabled(disabled)
    refCancelButton.current && refCancelButton.current.setModified(!disabled)
  }

  const onPostComplete = () => {
    props.formResetOnPostComplete && props.formResetOnPostComplete()
    disableButtons(true)
  }
  
  const formReset = () => {
    props.formReset()
    disableButtons(true)
  }

  useImperativeHandle(ref, () => ({
    setDisabled: disabled => disableButtons(disabled)
  }))

  const handleCancel = () => {

  }

  return (
    <ButtonsContainer>
      <CancelButton ref={refCancelButton} onClick={handleCancel} />
      <XDivider width='10px' />
      {props.formReset && 
        <>
          <ResetButton ref={refResetButton} disabled onClick={formReset} />
          <XDivider width='10px' />
        </>
      }
      <ClearButton arrRefs={props.arrRefs} />
      <XDivider width='10px' />
      <SaveButton ref={refSaveButton} disabled feedBack onPostComplete={onPostComplete} arrRefs={props.arrRefs} formTemplate={props.formTemplate} postService={props.postService} boundControls={props.boundControls} data={props.data} />
    </ButtonsContainer>
  )
})

Buttons.propTypes = {
  arrRefs: PropTypes.array,
  postService: PropTypes.func,
  boundControls: PropTypes.bool,
  data: PropTypes.object,
  formTemplate: PropTypes.array,
  formReset: PropTypes.func, 
  formResetOnPostComplete: PropTypes.func,
}

// Use the function basehttp.get for the get in your service.
const getService = () => {
  // This simulates a basehttp.get.
  return new Promise(resolve => {
    setTimeout(() => {
      resolve(mockGetObject)
    }, 2000)
  })
}

const NAME_FIELD = 0
const ADDRESS_FIELD = 1
const SELECT_FIELD = 2
const DATE_FIELD = 3
const DATE_FIELD2 = 4
const DATE_FIELD3 = 5
const MULTI_SELECT_FIELD = 6
const CHECKBOX_FIELD = 7
const LABEL_FIELD = 8

const FormBody = props => {
  const { formProps } = props

  return (
    <FormBodyContainer >
      <HalfScreen>
        <BoundTextField
          {...formProps(NAME_FIELD)}
        />
        <VerticalDivider />
        <BoundTextField
          {...formProps(ADDRESS_FIELD)}
        />
        <VerticalDivider />  
        <BoundSelect
          {...formProps(SELECT_FIELD)}
          items={selectItems}
        />
        <VerticalDivider />  
        <BoundMultiSelectWithCheckboxes
          items={selectItems}
          {...formProps(MULTI_SELECT_FIELD)}
        />
      </HalfScreen>
      <XDivider width='50px' />
      <HalfScreen>
        <BoundDateTime
          {...formProps(DATE_FIELD)}
          type='date'
        />
        <VerticalDivider />  
        <BoundDateTime
          {...formProps(DATE_FIELD2)}
          type='date'
        />
        <VerticalDivider />  
        <BoundDateTime
          {...formProps(DATE_FIELD3)}
          type='date'
        />
        <VerticalDivider /> 
        <BoundCheckBox
          {...formProps(CHECKBOX_FIELD)}
        />
        <BoundLabel
          {...formProps(LABEL_FIELD)}
        />
      </HalfScreen>
    </FormBodyContainer>
  )
}

FormBody.propTypes = {
  formProps: PropTypes.func
}

// Defined the below in services
// Use the function uiPost for the post.
const postService = postObject => {
  const doPost = postObject => {
    // eslint-disable-next-line no-console
    console.log(JSON.stringify(postObject, undefined, 2))
  }
  return new Promise(resolve => {
    setTimeout(() => resolve(doPost(postObject)), 2000)
  })
}

// This has an edit feature. So, a getService must be defined to retrieve the data from the server.
const FormEditDemo = () => {
  return (
    <GeneralEditForm
      topPart={<TopPart> Form Edit Demo</TopPart>}
      isFormReset
      formTemplate={formTemplate}
      getService={getService}
      postService={postService}
      saveMessageTitle='Form Saved'
      saveMessage='Form Saved Successfully'
      formBody={FormBody}
      buttons={Buttons}
    />
  )
}

export default FormEditDemo