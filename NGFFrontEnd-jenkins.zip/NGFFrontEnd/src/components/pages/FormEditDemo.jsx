import React, { useRef } from 'react'
import PropTypes from 'prop-types'
import styled from 'styled-components'

import { FlexByRow, XDivider, YDivider, HalfScreen } from 'pwlib/styles'
import { MainRoutePage } from '../appcontrol/RoutePage'
import { TextField, DateTime, Select, ClearButton, SaveButton, MultiSelectWithCheckboxes, Autocomplete } from 'pwlib/components/formcontrols'
import { useFormHandler } from 'pwlib/hooks'
import * as regx from 'pwlib/components/formcontrols/'
import { today } from 'pwlib/common'
import { LocalToast } from 'pwlib/containers'

const countries = [
  { label: 'TUVALU', value: 'TV' },
  { label: 'UGANDA', value: 'UG' },
  { label: 'UKRAINE', value: 'UA' },
  { label: 'UNITED ARAB EMIRATES', value: 'AE' },
  { label: 'UNITED KINGDOM', value: 'GB' },
  { label: 'UNITED STATES', value: 'US' },
]

const selectItems = [
  { value: '10', label: 'select1' },
  { value: '20', label: 'select2' },
  { value: '30', label: 'select3' },
  { value: '40', label: 'select4' },
  { value: '50', label: 'select5' }
]

const mockGetObject = {
  obj: {
    obj1: {
      name: 'John Doe',
      address: '1137 6th Street',
      select: '10',
      multiSelect: ['10'],
      date: '2021-12-31',
      autocomplete: 'UG'
    }
  }
}

const formTemplate = [
  {
    label: 'Name',
    fieldKey: 'obj.obj1.name',
    defaultValue: '',
    isRequired: true,
    startString: 'anyPretext',
    validator: value => {
      if (value.length > 20) {
        return 'Textfield must be less than 20 characters.'
      }
      return ''
    },
    regx: regx.alphanumericRegex,
    regxError: regx.alphanumericRegexError
  },
  {
    label: 'Address',
    fieldKey: 'obj.obj1.address',
    defaultValue: '',
    isRequired: true,
    maxLength: 25
  },
  {
    label: 'Select Demo',
    fieldKey: 'obj.obj1.select',
    defaultValue: '',
    isRequired: true
  },
  {
    label: 'Date 1',
    fieldKey: 'obj.obj1.date',
    defaultValue: '',
    isRequired: true
  },
  {
    label: 'Date 2',
    fieldKey: 'obj.obj1.date2',
    defaultValue: () => {
      return today()
    },
    isRequired: true
  },
  {
    label: 'Date 3',
    fieldKey: 'obj.obj1.date3',
    defaultValue: '',
    isRequired: true
  },
  {
    label: 'Multi Select Demo',
    fieldKey: 'obj.obj1.multiSelect',
    defaultValue: [],
    isRequired: true,
    onBeforePost: arrValue => {
      return arrValue.join()
    }
  },
  {
    label: 'Autocomplete Demo',
    fieldKey: 'obj.obj1.autocomplete',
    defaultValue: null,
    isRequired: true
  },
]


const VerticalDivider = () =>
  <YDivider height='50px' />

const Buttons = props =>
  <>
    <ClearButton arrRefs={props.arrRefs} />
    <XDivider width='10px' />
    <SaveButton feedBack arrRefs={props.arrRefs} postService={props.postService} />
  </>

Buttons.propTypes = {
  arrRefs: PropTypes.array,
  postService: PropTypes.func
}

const PageContainer = styled.div`
  width: 100%;
  padding: 20px 20px 0px 20px;
`

// Use the function basehttp.get for the get in your service.
const getService = () => {
  // This simulates a basehttp.get.
  return new Promise(resolve => {
    setTimeout(() => {
      resolve(mockGetObject)
    }, 2000)
  })
}

const NAME_FIELD = 0
const ADDRESS_FIELD = 1
const SELECT_FIELD = 2
const DATE_FIELD = 3
const DATE_FIELD2 = 4
const DATE_FIELD3 = 5
const MULTI_SELECT_FIELD = 6
const AUTOCOMPLETE_FIELD = 7

// This has an edit feature. So, a getService must be defined to retrieve the data from the server.
const FormEditDemo = () => {
  const refLocalToast = useRef(null)
  const { arrRefs, formProps } = useFormHandler({ 
    formTemplate, 
    service: getService
  })

  // Defined the below in services
  // Use the function uiPost for the post.
  const postService = postObject => {
    const doPost = postObject => {
      // eslint-disable-next-line no-console
      console.log(JSON.stringify(postObject, undefined, 2))
      refLocalToast.current?.successToastOn({ message: 'Form Saved Successfully', title: 'Form Saved' })
    }
    return new Promise(resolve => {
      setTimeout(() => resolve(doPost(postObject)), 2000)
    })
  }

  return (
    <MainRoutePage 
      mainTitle='Form Demo' 
      buttons={<Buttons formTemplate={formTemplate} arrRefs={arrRefs} postService={postService} />}
      rightButtons
      style={{ paddingTop: '20px' }}
    >
      <PageContainer>
        <LocalToast ref={refLocalToast} />
        <FlexByRow>
          <HalfScreen>
            <TextField
              {...formProps(NAME_FIELD)}
            />
            <VerticalDivider />
            <TextField
              {...formProps(ADDRESS_FIELD)}
            />
            <VerticalDivider />  
            <Select
              {...formProps(SELECT_FIELD)}
              items={selectItems}
            />
            <VerticalDivider />  
            <MultiSelectWithCheckboxes
              items={selectItems}
              {...formProps(MULTI_SELECT_FIELD)}
            />
          </HalfScreen>
          <XDivider width='50px' />
          <HalfScreen>
            <DateTime
              {...formProps(DATE_FIELD)}
              type='date'
            />
            <VerticalDivider />  
            <DateTime
              {...formProps(DATE_FIELD2)}
              type='date'
            />
            <VerticalDivider />  
            <DateTime
              {...formProps(DATE_FIELD3)}
              type='date'
            />
            <VerticalDivider />  
            <Autocomplete
              {...formProps(AUTOCOMPLETE_FIELD)}
              options={countries}
            />
            <VerticalDivider /> 
          </HalfScreen>
        </FlexByRow>
      </PageContainer>
    </MainRoutePage>
  )
}

export default FormEditDemo