import React, { createRef } from 'react'
import { BoundDecimalEntryField } from '../../controls/NumberField'
import { modifiedKey } from 'pwlib/common'
import cloneDeep from 'clone-deep'
import { iceStatusInverseConversion } from '../../../common/conversions'
import { arrayFillObj } from '../../../common/functions'

const strTotal = 'Total'
const strIceStatus = 'Status'
export const forecastCellWidth = '100px'
export const cellPadding = '0px 8px'

const forecastHeaderContainerStyle = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  flexDirection: 'column',
  width: forecastCellWidth,
  padding: cellPadding
}
  
const forecastCellContainerStyle = {
  width: forecastCellWidth,
  padding: cellPadding
}

const forecastFieldemplate = {
  fieldKey: 'value',
  baseFieldKey: 'iceValue',
}

export const buildForecastSums = data => {
  const rowSums = []
  for (let i = 0; i < data.length; ++i) {
    let rowSum = 0
    rowSum = data[i].forecast.reduce(
      (accumulator, e) => e.value === null ? accumulator : accumulator + e.value,
      0
    )
    rowSums.push({ value: rowSum })
  }
  
  const columnSums = [] 
  for (let j = 0; j < data[0].forecast.length; ++j) {
    let columnSum = 0
    for (let i = 0; i < data.length; ++i) {
      if (!data[i].doNotIncludeSvCount) {
        columnSum += data[i].forecast[j].value
      }
    }
    columnSums.push({ value: columnSum })
  }

  let grandTotal = columnSums.reduce(
    (accumulator, e) => e.value === null ? accumulator : accumulator + e.value,
    0
  )
  grandTotal = { value: grandTotal }

  return {
    rowSums,
    columnSums,
    grandTotal
  }
}
  
export const buildTableForecastColumns = (data, rowIndex, columnComponents, numFractionalDigits, disabled, handleBlur, handleForecastFocus, onChange, tabIndex) => {
  // Forecast Columns
  const forecast = data[rowIndex].forecast
  for (let j = 0; j < forecast.length; ++j) {
    columnComponents.push(
      <div style={forecastCellContainerStyle}>
        <BoundDecimalEntryField
          id={`forecast-${rowIndex}-${j}`}
          noEdit={disabled}
          srcObject={forecast[j]}
          fieldTemplate={forecastFieldemplate}
          numFractionalDigits={numFractionalDigits}
          onBlur={() => handleBlur(data, rowIndex, j)}
          onFocus={handleForecastFocus}
          onChange={onChange}
          tabIndex={tabIndex++}
          // ???? remove
          noNegative
        />
      </div>
    )
  }
  return tabIndex
}
  
export const buildTableForecastColumnHeaders = (data, headerComponents) => {
  for (let j = 0; j < data[0].forecast.length; ++j) {
    const forecastItem = data[0].forecast[j]
    headerComponents.push(
      <div style={forecastHeaderContainerStyle}>
        <div>{forecastItem.periodYear}</div>
        <div>{forecastItem.periodMonth}</div>
      </div>
    )
  }
}
  
export const buildRowTotalColumn = (rowSumObj, columnComponents, numFractionalDigits) => {
  const ref = createRef()
  columnComponents.push(
    <div style={forecastCellContainerStyle}>
      <BoundDecimalEntryField
        noEdit
        srcObject={rowSumObj}
        fieldTemplate={forecastFieldemplate}
        numFractionalDigits={numFractionalDigits}
        ref={ref}
        noUnderline
      />
    </div>
  )
  return ref
}
  
export const buildTableForecastFooterColumns = (footerRow, sumObj, numFractionalDigits, refsColumns) => {
  for (let i = 0; i < sumObj.columnSums.length; ++i) {
    const ref = createRef()
    footerRow.push(
      <div style={forecastCellContainerStyle}>
        <BoundDecimalEntryField
          noEdit
          srcObject={sumObj.columnSums[i]}
          fieldTemplate={forecastFieldemplate}
          numFractionalDigits={numFractionalDigits}
          ref={ref}
          noUnderline
        />
      </div>
    )
    refsColumns.push(ref)
  }
}
  
export const buildTableFooterTotalColumnHeader = headerComponents => {
  headerComponents.push(
    <div style={forecastHeaderContainerStyle}>{strTotal}</div>
  )
}

export const buildTableIceStatusColumnHeader = headerComponents => {
  headerComponents.push(
    <div style={forecastHeaderContainerStyle}>{strIceStatus}</div>
  )
}
  
export const buildTableFooterGrandTotalColumn = (footerRow, sumObj, numFractionalDigits, refGrandTotal) => {
  footerRow.push(
    <div style={forecastCellContainerStyle}>
      <BoundDecimalEntryField
        noEdit
        srcObject={sumObj.grandTotal}
        fieldTemplate={forecastFieldemplate}
        numFractionalDigits={numFractionalDigits}
        ref={refGrandTotal}
        noUnderline
      />
    </div>
  )
}

export const buildTableFooterIceStatusColumn = footerRow => {
  footerRow.push(
    <div style={forecastCellContainerStyle} />
  )
}

export const standardThStyles = (theme, refColumnHeaderComponents) => {
  // return new Array(refColumnHeaderComponents.current.length).fill({ backgroundColor: 'red', padding: '0px' })
  const arr = new Array(refColumnHeaderComponents.current.length)
  arrayFillObj(arr, { backgroundColor: theme.palette.formSectionTitleBackground, padding: '0px' })
  return arr
}

export const getModifiedData = data => {
  let finalData = cloneDeep(data)
  // Filter only those rows that have changed.
  finalData = finalData.filter(e => {
    // The user modified something in the object.
    if (e[modifiedKey]) {
      return true
    // The user changed the ice status by changing and ice forecast entry.
    } else if (e.originalIceStatus !== iceStatusInverseConversion(e.iceStatus)) {
      e[modifiedKey] = true
      return true
    }
    let b = false
    // The user changed changed a forecast entry.
    for (let j = 0; !b && j < e.forecast.length; ++j) {
      b = b || e.forecast[j][modifiedKey]
    }
    return b
  })
  // Filter only forecast entries that have changed.
  for (let i = 0; i < finalData.length; ++i) {
    finalData[i].forecast = finalData[i].forecast.filter(e => e[modifiedKey])
  }
  return finalData
}

export const unsetModifiedData = data => {
  for (let i = 0; i < data.length; ++i) {
    data[modifiedKey] = false
    data[i].originalIceStatus = iceStatusInverseConversion(data[i].iceStatus)
    const forecast = data[i].forecast
    for (let j = 0; j < forecast.length; ++j) {
      forecast[j][modifiedKey] = false
    }
  }
}
