import React, { useRef, forwardRef } from 'react'
import { useConstructor } from 'pwlib/hooks'

import StepCompletedButton from '../../controls/StepCompletedButton'
import { FormButtons } from '../../common'


export const StepButtons = forwardRef((props, ref) => {
  const refBeforeButtons = useRef(props.beforeButtons || [])

  useConstructor(() => {
    refBeforeButtons.current.push(StepCompletedButton)
  })

  return (
    <FormButtons ref={ref} {...props} beforeButtons={refBeforeButtons.current} />
  )
})

StepButtons.propTypes = {
  ...FormButtons.propTypes,
}
