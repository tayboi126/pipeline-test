import React, { useCallback, useRef, createRef, useImperativeHandle, forwardRef } from 'react'
import { useConstructor } from 'pwlib/hooks'
import { useTheme } from 'pwlib/styles'
import { BoundLabel, BoundCheckBox } from 'pwlib/components/formcontrols'
import PropTypes from 'prop-types'

import GeneralInputTable from '../../../controls/GeneralInputTable'
import { forecastCellWidth, buildTableFooterIceStatusColumn, buildTableIceStatusColumnHeader, cellPadding, buildForecastSums, buildTableForecastColumns, buildRowTotalColumn, buildTableForecastColumnHeaders, buildTableFooterTotalColumnHeader, buildTableForecastFooterColumns, buildTableFooterGrandTotalColumn, standardThStyles } from '../forecastcommon'
import { manualStatus, iceStatusConversion, iceStatus, iceAdjStatus } from '../../../../common/conversions'
import { arrayFillObj } from '../../../../common/functions'

/*
  ???? Not keeping track of the mocified fields.
*/

const numFractionalDigits = 5

const numInitialColumns = 2
const formTemplate = [
  {
    fieldKey: 'svCategoryDescription',
  },
  {
    fieldKey: 'doNotIncludeSvCount',
  },
  {
    fieldKey: 'iceStatus',
  }
]

// One for each entry in formTemplate.
const tableHeaderStyles = [
  { padding: cellPadding, width: '250px' },
  { padding: cellPadding, width: '100px' },
  { padding: cellPadding, width: '100px' }
]

// One for each entry in formTemplate.
const tableHeaders = ['Category', 'Do not Include in SV Count?']

const CATEGORY_FIELD = 0
const DO_NOT_INCLUDE_IN_SV_COUNT_FIELD = 1
const ICE_STATUS_FIELD = 2

const Step7InputTable = forwardRef((props, ref) => {
  const theme = useTheme()
  const tableBackgroundColor = props.tableBackgroundColor
  const refTableRows = useRef([])
  const refColumnHeaderComponents = useRef([])
  const refFooterRow = useRef([])
  const tableCellStyles = useRef([])
  const refGrandTotal = useRef()
  const refRowTotalsRefs = useRef([])
  const refRowStatusRefs = useRef([])
  const refColumnTotalsRefs = useRef([])
  const refThStyles = useRef([])
  const refTable = useRef()
  const refRowCheckRefs = useRef([])
    
  const handleForecastBlur = useCallback((data, row, column) => {
    const rowSums = [] 
    for (let i = 0; i < data.length; ++i) {
      let rowSum = 0
      rowSum = data[i].forecast.reduce(
        (accumulator, e) => e.value === null ? accumulator : accumulator + e.value,
        0
      )
      rowSums.push(rowSum)
    }
    if (row !== undefined) {
      if (data[row].iceStatus !== iceStatusConversion(manualStatus)) {
        const rowdata = data[row].forecast
        let isIceStatus = true
        for (let i = 0; isIceStatus && i < rowdata.length; ++i) {
          isIceStatus = isIceStatus && rowdata[i].value === rowdata[i].iceValue
        }
        data[row].iceStatus = isIceStatus ? iceStatusConversion(iceStatus) : iceStatusConversion(iceAdjStatus)
        refRowStatusRefs.current[row].current.render()
      }
    }
    if (column === undefined) {
      for (let column = 0; column < data[0].forecast.length; ++column) {
        let columnSum = 0
        for (let i = 0; i < data.length; ++i) {
          if (!data[i].doNotIncludeSvCount) {
            columnSum += data[i].forecast[column].value
          }
        }
        refColumnTotalsRefs.current[column].current.setValue(columnSum)
      }
    } else {
      let columnSum = 0
      for (let i = 0; i < data.length; ++i) {
        if (!data[i].doNotIncludeSvCount) {
          columnSum += data[i].forecast[column].value
        }
      }
      refColumnTotalsRefs.current[column].current.setValue(columnSum)
    }
    let grandTotal = 0
    for (let column = 0; column < data[0].forecast.length; ++column) {
      grandTotal += refColumnTotalsRefs.current[column].current.getValue()
    }

    refRowTotalsRefs.current[row].current.setValue(rowSums[row])
    refGrandTotal.current.setValue(grandTotal)
  })

  // Scroll the control into view if needed. This is caused by the sticky right columns.
  const handleForecastFocus = element => {
    try {
      const parent = refTable.current
      const obj1 = element.getBoundingClientRect()
      const obj2 = parent.getBoundingClientRect()
      const horzAmount = 3 * parseInt(forecastCellWidth)
      if (obj1.x > obj2.width - horzAmount) {
        parent.scrollLeft += (obj2.width - horzAmount) / 2
      }
    } catch {}
  }

  const handleChange = useCallback(() => {
    props.onChange()
  })

  const handleChangeCheck = useCallback(row => {
    handleForecastBlur(props.data, row) 
    props.onChange(true)
  })

  const handleData = useCallback(data => {
    if (data.length > 0) {
      let tabIndex = 0
      const sumObj = buildForecastSums(data)

      //
      // Build the bound row components
      //
      for (let i = 0; i < data.length; ++i) {
        const columnComponents = []

        // Initial columns
        columnComponents.push(
          <div style={tableHeaderStyles[CATEGORY_FIELD]}>
            <BoundLabel
              ellipsis
              title={data[i][formTemplate[CATEGORY_FIELD].fieldKey]}
              srcObject={data[i]}
              fieldTemplate={formTemplate[CATEGORY_FIELD]}
            />
          </div>
        )

        let ref = createRef()
        columnComponents.push(
          <div style={{ ...tableHeaderStyles[DO_NOT_INCLUDE_IN_SV_COUNT_FIELD], textAlign: 'center' }}>
            <BoundCheckBox
              srcObject={data[i]}
              fieldTemplate={formTemplate[DO_NOT_INCLUDE_IN_SV_COUNT_FIELD]}
              disabled={props.disabled}
              tabIndex={tabIndex++}
              onChange={() => handleChangeCheck(i)}
              ref={ref}
            />
          </div>
        )
        refRowCheckRefs.current.push(ref)

        // Forecast Columns
        tabIndex = buildTableForecastColumns(data, i, columnComponents, numFractionalDigits, props.disabled, handleForecastBlur, handleForecastFocus, handleChange, tabIndex)

        // Row total column
        refRowTotalsRefs.current.push(buildRowTotalColumn(sumObj.rowSums[i], columnComponents, numFractionalDigits))

        // Ice status Column
        ref = createRef()
        columnComponents.push(
          <div style={tableHeaderStyles[ICE_STATUS_FIELD]}>
            <BoundLabel
              srcObject={data[i]}
              fieldTemplate={formTemplate[ICE_STATUS_FIELD]}
              ref={ref}
            />
          </div>
        )
        refRowStatusRefs.current.push(ref)

        refTableRows.current.push(columnComponents) 
      }


      //
      // Table headers
      //

      // Initial headers
      const headerComponents = tableHeaders.map((e, index) => {
        return (
          <div style={tableHeaderStyles[index]}>
            {e}
          </div>
        )
      })

      // forecast data headers
      buildTableForecastColumnHeaders(data, headerComponents)

      // Total header column
      buildTableFooterTotalColumnHeader(headerComponents)

      // Ice status header
      buildTableIceStatusColumnHeader(headerComponents)

      refColumnHeaderComponents.current = headerComponents


      //
      // Totals footer row
      //

      // Initial footer columns
      for (let i = 0; i < numInitialColumns; ++i) {
        refFooterRow.current.push(null)
      }

      // forecast column totals
      buildTableForecastFooterColumns(refFooterRow.current, sumObj, numFractionalDigits, refColumnTotalsRefs.current)

      // Forecast sum grand total
      buildTableFooterGrandTotalColumn(refFooterRow.current, sumObj, numFractionalDigits, refGrandTotal)

      buildTableFooterIceStatusColumn(refFooterRow.current)

      // tableCellStyles.current = (new Array(refColumnHeaderComponents.current.length)).fill({ padding: '0px' })
      tableCellStyles.current = new Array(refColumnHeaderComponents.current.length)
      arrayFillObj(tableCellStyles.current, { padding: '0px' })

      refThStyles.current = standardThStyles(theme, refColumnHeaderComponents)
      // Must set widths if more than one sticky column
      refThStyles.current[refThStyles.current.length - 1] = { ...refThStyles.current[refThStyles.current.length - 1] }
      refThStyles.current[refThStyles.current.length - 1].width = tableHeaderStyles[2].width

      tableCellStyles.current[tableCellStyles.current.length - 1] = { ...tableCellStyles.current[tableCellStyles.current.length - 1] }
      tableCellStyles.current[tableCellStyles.current.length - 1].width = tableHeaderStyles[2].width
      tableCellStyles.current[tableCellStyles.current.length - 1].textAlign = 'center'
    }
  }, [])

  useConstructor(() => {
    handleData(props.data)
  })

  useImperativeHandle(ref, () => ({
    setChecks: arr => {
      for (let i = 0; i < arr.length; ++i) {
        refRowCheckRefs.current[arr[i]].current.setValue(true)
      }
    },
  }))

  /*
  useEffect(() => {
    console.log('render complete Step7InputTable', new Date().getTime())
  })

  console.log('start render Step7InputTable', new Date().getTime())
  */

  return (
    <GeneralInputTable
      tableContainerStyles={{ fontSize: `${theme.typography.fontSize}px`, backgroundColor: tableBackgroundColor }}
      columnHeaderComponents={refColumnHeaderComponents.current}
      rows={refTableRows.current}
      footerRow={refFooterRow.current}
      numStickyInitialColumns={1}
      numStickyEndColumns={2}
      thStyles={refThStyles.current}
      tdStyles={tableCellStyles.current}
      footerTdStyles={tableCellStyles.current}
      ref={refTable}
    />
  )
})

Step7InputTable.propTypes = {
  disabled: PropTypes.bool,
  data: PropTypes.array,
  tableBackgroundColor: PropTypes.string,
  onChange: PropTypes.func
}

export default Step7InputTable 