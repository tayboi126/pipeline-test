import React, { useEffect, useRef } from 'react'
import PropTypes from 'prop-types'
import { useUiGet, useMergeState } from 'pwlib/hooks'
import { ExpandingContainer, useTheme } from 'pwlib/styles'
import { ContainedButton } from 'pwlib/components/controls'
import styled from 'styled-components'

import Step7InputTable from './Step7InputTable'
import { loadStep7, saveStep7 } from '../../../../services/steps'
import { PageContainer, PageTopContainer } from '../../../common'
import { unsetModifiedData, getModifiedData } from '../forecastcommon'
import { svTypeTar } from '../../../../common/constants'
import { StepButtons } from '../common'

const ButtonContainer = styled.div`
  position: absolute;
  right: 10px;
`

const TopPart = props => {
  return (
    <PageTopContainer>
      Step 7
      <ButtonContainer>
        <ContainedButton onClick={props.onClick} disabled={props.disabled} title={'For all tar sv types, set the check to exclude the line item from the SV count.' }>Check All SV Tar</ContainedButton>
      </ButtonContainer>
    </PageTopContainer>
  )
}

TopPart.propTypes = {
  disabled: PropTypes.bool,
  onClick: PropTypes.func,
}

const Step7 = props => {
  const theme = useTheme()
  const refStep7InputTable = useRef()
  const [isLoaded, data] = useUiGet(loadStep7)
  const [state, setState] = useMergeState({
    hasChanges: false,
    tarChecked: false
  })

  const checkTarChecked = () => {
    let tarChecked = false
    for (let i = 0; !tarChecked && i < data.length; ++i) {
      tarChecked = tarChecked || (data[i].doNotIncludeSvCount && data[i].svTypeSeq === svTypeTar)
    }
    return tarChecked
  }

  const handleChange = isCheck => {
    let tarChecked = false
    if (isCheck) {
      tarChecked = checkTarChecked()
    }
    setState({ hasChanges: true, tarChecked })
  }

  const handleSave = async () => {
    const finalData = getModifiedData(data)
    await saveStep7(finalData)
    unsetModifiedData(data)
    setState({ hasChanges: false })
  }

  const checkAllTar = () => {
    const arr = []
    for (let i = 0; i < data.length; ++i) {
      if (data[i].svTypeSeq === svTypeTar) {
        arr.push(i)
        data[i].doNotIncludeSvCount = true
      }
    }
    refStep7InputTable.current.setChecks(arr)
    setState({ tarChecked: true })
  }

  useEffect(() => {
    if (isLoaded) {
      const tarChecked = checkTarChecked()
      if (tarChecked) {
        setState({ tarChecked })
      }
    }
  }, [isLoaded])

  return (
    <PageContainer>
      <TopPart disabled={state.tarChecked || props.disabled} onClick={checkAllTar} />
      <ExpandingContainer>
        {isLoaded && <Step7InputTable ref={refStep7InputTable} disabled={props.disabled} data={data} tableBackgroundColor={theme.palette.background.default} onChange={handleChange} />}
      </ExpandingContainer>
      <StepButtons
        step={7}
        disabled={props.disabled}
        saveDisabled={!state.hasChanges}
        onClickSave={handleSave}
      />
    </PageContainer>
  ) 
}

Step7.propTypes = {
  disabled: PropTypes.bool,
}

export default Step7