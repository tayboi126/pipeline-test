import React, { forwardRef } from 'react'
import styled from 'styled-components'
import { BoundTextField, openFormDialog } from 'pwlib/components/formcontrols'
import { useDialogForm } from 'pwlib/hooks'
import PropTypes from 'prop-types'

import { saveComments } from '../../../services/steps'

const linesPerComment = 20
const dialogWidth = '550px'
const fieldKey = 'comments'

const formTemplate = [
  {
    label: 'Comments',
    fieldKey,
    defaultValue: ''
  },
]

const PageContainer = styled.div`
  width: ${dialogWidth};
`

const postService = async (postObject, step, boundData) => {
  await saveComments(step, postObject.comments)
  boundData.comments = postObject.comments
}

const COMMENTS_FIELD = 0

const StepComments = forwardRef((props, ref) => {
  const { formProps, isLoaded } = useDialogForm({ formTemplate, ref, boundControls: true, service: props.service })

  if (!isLoaded) {
    return <></>
  }

  return (
    <PageContainer>
      <BoundTextField {...formProps(COMMENTS_FIELD)} multiline={true} rows={linesPerComment} variant='outlined' />
    </PageContainer>
  )
})

StepComments.propTypes = {
  service: PropTypes.func,
}

const openStepComments = ({ step, boundData }) => {
  const copyBoundData = { [fieldKey]: boundData[fieldKey] }
  openFormDialog({
    title: `Step ${step} Comments`,
    dialogBody: StepComments,
    formTemplate,
    onOk: async () => await postService(copyBoundData, step, boundData),
    saveLabel: 'Save',
    props: {
      service: () => copyBoundData
    }
  })
}

export default openStepComments