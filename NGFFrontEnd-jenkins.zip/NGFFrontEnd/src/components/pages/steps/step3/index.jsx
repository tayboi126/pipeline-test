import React, { forwardRef, useEffect, useRef } from 'react'
import PropTypes from 'prop-types'
import { FlexByRow, YDivider, useTheme } from 'pwlib/styles'
import { useObserver, useConstructor } from 'pwlib/hooks'
import styled from 'styled-components'
import { ContainedButton } from 'pwlib/components/controls'
import { BoundLabel, getFieldValue, setFieldValue, reloadBoundFieldData } from 'pwlib/components/formcontrols'
import { triggerObserver } from 'pwlib/common'
import { uiGet } from 'pwlib/http'

import { BoundDollarEntryField, BoundPercentEntryField, translateNumberToString, dollarNumberType, percentNumberType } from '../../../controls/NumberField'
import GeneralEditForm from '../../../controls/GeneralEditForm'
import { PageTopContainer, FormHalfScreenRight, FormHalfScreenLeft, TableFormDescriptionAndNumberField, FormBodyContainer, FormTable } from '../../../common'
import { loadStep3, saveStep3, loadSpanas } from '../../../../services/steps'
import { StepButtons } from '../common'
import Panel from '../../../controls/Panel'
import { reloadSpanas, monthsNames, retrieveStepComments } from '../../../../common/constants'
import openStepComments from '../Comments'

const formDividerHeight = '30px'
const boundLabelStyle = { display: 'flex', height: '100%', alignItems: 'flex-end', justifyContent: 'flex-end' } 

// ???? cp009 is 8711716.53

const formTemplate = [
  {
    fieldKey: 'deferredRevBalance',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdTotalUtilization',
    defaultValue: 0,
  },
  {
    fieldKey: 'invoicedAfterActuals',
    defaultValue: 0,
  },

  {
    fieldKey: 'itdCp001',
    baseFieldKey: 'itdCp001',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdCp002',
    baseFieldKey: 'itdCp002',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdCp003',
    baseFieldKey: 'itdCp003',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdCp004',
    baseFieldKey: 'itdCp004',
    defaultValue: 0,
  },
  {
    fieldKey: 'cp003PlusCp004',
    defaultValue: '$0.00',
  },
  {
    fieldKey: 'itdCp005',
    baseFieldKey: 'itdCp005',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdCp019',
    baseFieldKey: 'itdCp019',
    defaultValue: 0,
  },

  {
    fieldKey: 'itdCp006',
    baseFieldKey: 'itdCp006',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdCp007',
    baseFieldKey: 'itdCp007',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdCp008',
    baseFieldKey: 'itdCp008',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdCp008A',
    baseFieldKey: 'itdCp008A',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdCp009',
    baseFieldKey: 'itdCp009',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdCp010',
    baseFieldKey: 'itdCp010',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdCp011',
    baseFieldKey: 'itdCp011',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdCp011Ilp',
    baseFieldKey: 'itdCp011Ilp',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdCp012',
    baseFieldKey: 'itdCp012',
    defaultValue: 0,
  },

  {
    fieldKey: 'itdCp013',
    baseFieldKey: 'itdCp013',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdCp018',
    baseFieldKey: 'itdCp018',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdCp014',
    baseFieldKey: 'itdCp014',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdCp020',
    baseFieldKey: 'itdCp020',
    defaultValue: 0,
  },

  {
    fieldKey: 'cp010DivCp006',
    defaultValue: '0.00%',
  },
  {
    fieldKey: 'cp004DivCp005',
    defaultValue: '0.00%',
  },
  {
    fieldKey: 'pmaSparesDiscount',
    baseFieldKey: 'pmaSparesDiscount',
    defaultValue: 0,
    onAfterGet: value => {
      return value * 100
    }
  },
  {
    fieldKey: 'itdCp015',
    baseFieldKey: 'itdCp015',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdCp016',
    baseFieldKey: 'itdCp016',
    defaultValue: 0,

  },

  {
    fieldKey: 'salesAfterDiscount',
    baseFieldKey: 'salesAfterDiscount',
    defaultValue: 0,
  },
  {
    fieldKey: 'salesBeforeDiscount',
    baseFieldKey: 'salesBeforeDiscount',
    defaultValue: 0,
  },
  {
    fieldKey: 'accountCos',
    baseFieldKey: 'accountCos',
    defaultValue: 0,
  },
  {
    fieldKey: 'itdCp017',
    baseFieldKey: 'itdCp017',
    defaultValue: 0,
  },

  {
    fieldKey: 'lOPSGAndA',
    defaultValue: 0,
  },
  {
    fieldKey: 'manualServiceCumCatchupGrossSales',
    defaultValue: 0,
  },
  {
    fieldKey: 'customerCollectionFactor',
    defaultValue: 0,
  },
  {
    fieldKey: 'manualServiceCumCatchupNetSales',
    defaultValue: 0,
  },
  {
    fieldKey: 'postingMonth',
    defaultValue: '',
    onAfterGet: value => {
      return monthsNames[value]
    }
  },
  {
    fieldKey: 'postingYear',
    defaultValue: '',
  },
]

const FormDividerContainer = styled.div`
  font-weight: bold;
  height: ${formDividerHeight};
  padding-left: 3px;
  display: flex;
  align-items: center;
  border-top: 1px solid white;
  border-bottom: 1px solid white;
`

const ActualsDateContainer = styled.div`
  display: flex;
`

const Step3BoundDollarEntryField = forwardRef((props, ref) => {
  return (
    <BoundDollarEntryField ref={ref} style={numberStyle} {...props} />
  )
})

const Step3BoundSpanasDollarEntryField = forwardRef((props, ref) => {
  const theme = useTheme()
  return (
    <BoundDollarEntryField ref={ref} style={{ ...numberStyle, backgroundColor: theme.palette.spanasTextFieldBackground }} {...props} />
  )
})

const Step3BoundPercentEntryField = forwardRef((props, ref) => {
  return (
    <BoundPercentEntryField ref={ref} style={numberStyle} {...props} />
  )
})

const Step3BoundSpanasPercentEntryField = forwardRef((props, ref) => {
  const theme = useTheme()
  return (
    <BoundPercentEntryField ref={ref} style={{ ...numberStyle, backgroundColor: theme.palette.spanasTextFieldBackground }} {...props} />
  )
})

const FormDivider = props => {
  return (
    <FormDividerContainer>
      {props.title}
    </FormDividerContainer>
  )
}

FormDivider.propTypes = {
  title: PropTypes.string,
}

const SectionDivider = () =>
  <YDivider height='10px' />

const DEFERRED_REV_BALANCE_FIELD = 0
const ITD_TOTAL_UTILIZATION_FIELD = 1
const INVOICED_AFTER_ACTUALS_FIELD = 2

const SPANAS_CP001_FIELD = 3
const SPANAS_CP002_FIELD = 4
const SPANAS_CP003_FIELD = 5
const SPANAS_CP004_FIELD = 6
const CP003_PLUS_CP004_FIELD = 7
const SPANAS_CP005_FIELD = 8
const SPANAS_CP019_FIELD = 9

const SPANAS_CP006_FIELD = 10
const SPANAS_CP007_FIELD = 11
const SPANAS_CP008_FIELD = 12
const SPANAS_CP008A_FIELD = 13
const SPANAS_CP009_FIELD = 14
const SPANAS_CP010_FIELD = 15
const SPANAS_CP011_FIELD = 16
const SPANAS_CP011A_FIELD = 17
const SPANAS_CP012_FIELD = 18
const SPANAS_CP013_FIELD = 19
const SPANAS_CP018_FIELD = 20
const SPANAS_CP014_FIELD = 21
const SPANAS_CP020_FIELD = 22

const CP010DIVCP006_FIELD = 23
const CP004DIVCP005_FIELD = 24
const SPARE_PARTS_PA_AND_USED_ANTICIPATED_REDUCTION_FIELD = 25
const SPANAS_CP015_FIELD = 26
const SPANAS_CP016_FIELD = 27
const TOTAL_SERVICE_SALES_AFTER_DISCOUNT = 28
const TOTAL_SERVICE_SALES_BEFORE_DISCOUNT = 29
const SPANAS_SERVICE_COS = 30
const SPANAS_CP017_FIELD = 31

const LOP_SGA_AND_A_FIELD = 32
const MANUAL_SERVIDE_CUM_CATCHUP_GROSS_SALES_FIELD = 33
const CUSTOMER_COLLECTION_FACTOR_FIELD = 34
const MANUAL_SERVIDE_CUM_CATCHUP_NET_SALES_FIELD = 35
const ACTUALS_MONTH = 36
const ACTUALS_YEAR = 37

const spanasIndexes = [
  SPANAS_CP001_FIELD,
  SPANAS_CP002_FIELD,
  SPANAS_CP003_FIELD,
  SPANAS_CP004_FIELD,
  SPANAS_CP005_FIELD,
  SPANAS_CP019_FIELD,
  SPANAS_CP006_FIELD,
  SPANAS_CP007_FIELD,
  SPANAS_CP008_FIELD,
  SPANAS_CP008A_FIELD,
  SPANAS_CP009_FIELD,
  SPANAS_CP010_FIELD,
  SPANAS_CP011_FIELD,
  SPANAS_CP011A_FIELD,
  SPANAS_CP012_FIELD,
  SPANAS_CP013_FIELD,
  SPANAS_CP018_FIELD,
  SPANAS_CP014_FIELD,
  SPANAS_CP020_FIELD,
  SPARE_PARTS_PA_AND_USED_ANTICIPATED_REDUCTION_FIELD,
  SPANAS_CP015_FIELD,
  SPANAS_CP016_FIELD,
  TOTAL_SERVICE_SALES_AFTER_DISCOUNT,
  TOTAL_SERVICE_SALES_BEFORE_DISCOUNT,
  SPANAS_SERVICE_COS,
  SPANAS_CP017_FIELD
]

const ActualsDate = props => {
  return (
    <ActualsDateContainer>
      Actuals Prior to Forecast (Last Month Of Actuals:
      <span>&nbsp;</span>
      <BoundLabel {...props.formProps(ACTUALS_MONTH)} />/
      <BoundLabel {...props.formProps(ACTUALS_YEAR)} />)
    </ActualsDateContainer>
  )
}

ActualsDate.propTypes = {
  formProps: PropTypes.func,
}

const numberStyle = { width: '110px' }
const FormBody = props => {
  const { formProps, data } = props

  const handleSumCp003AndCp004 = () => {
    const value = getFieldValue(formProps(SPANAS_CP003_FIELD)) + getFieldValue(formProps(SPANAS_CP004_FIELD))
    setFieldValue(formProps(CP003_PLUS_CP004_FIELD), translateNumberToString(dollarNumberType, value, 2))
  }

  const handleCp010DivCp006 = () => {
    const valueCp010 = getFieldValue(formProps(SPANAS_CP010_FIELD))
    const valueCp006 = getFieldValue(formProps(SPANAS_CP006_FIELD))
    let value = 0
    if (valueCp006 !== 0) {
      value = valueCp010 / valueCp006 * 100.0
    }
    setFieldValue(formProps(CP010DIVCP006_FIELD), translateNumberToString(percentNumberType, value, 2))
  }

  const handleCp004DivCp005 = () => {
    const valueCp004 = getFieldValue(formProps(SPANAS_CP004_FIELD))
    const valueCp005 = getFieldValue(formProps(SPANAS_CP005_FIELD))
    let value = 0
    if (valueCp005 !== 0) {
      value = valueCp004 / valueCp005 * 100.0
    }
    setFieldValue(formProps(CP004DIVCP005_FIELD), translateNumberToString(percentNumberType, value, 2))
  }

  const handleBlurCp004 = () => {
    handleSumCp003AndCp004()
    handleCp004DivCp005()
  }

  const initSpanas = () => {
    handleSumCp003AndCp004()
    handleCp004DivCp005()
    handleCp010DivCp006()
  }

  useEffect(initSpanas, [])

  // Reload spanas, the function is triggered by a reload spanas button click.
  useObserver(reloadSpanas, reloadedData => {
    reloadBoundFieldData(data, reloadedData, spanasIndexes, formTemplate, formProps)
    initSpanas()
  })

  useObserver(retrieveStepComments, () => {
    return data
  })

  return (
    <FormBodyContainer >
      <Panel title={<ActualsDate formProps={formProps} />}>
        <FlexByRow>
          <FormHalfScreenLeft>
            <FormTable>
              <TableFormDescriptionAndNumberField
                fieldDescription='Deferred Rev Balance (L/T + S/T + A/R) prior to forecast $'
                field={<Step3BoundDollarEntryField {...formProps(DEFERRED_REV_BALANCE_FIELD)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='Invoiced After Actuals for Work in Actuals Period $'
                field={<Step3BoundDollarEntryField {...formProps(INVOICED_AFTER_ACTUALS_FIELD)} />}
              />
            </FormTable>
          </FormHalfScreenLeft>
          <FormHalfScreenRight>
            <FormTable>
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Total Utilization Invoice Revenue $'
                field={<Step3BoundDollarEntryField {...formProps(ITD_TOTAL_UTILIZATION_FIELD)} />}
              />
            </FormTable>
          </FormHalfScreenRight>
        </FlexByRow>
        <SectionDivider />
        <FlexByRow>
          <FormHalfScreenLeft>
            <FormDivider title='Service & On Wing' />
          </FormHalfScreenLeft>
          <FormHalfScreenRight>
            <FormDivider title='Spare Parts' />
          </FormHalfScreenRight>
        </FlexByRow>
        <FlexByRow>
          <FormHalfScreenLeft>
            <FormTable>
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Service + On-Wing COS (CP001) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP001_FIELD)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD On-Wing Accounting COS (CP002) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP002_FIELD)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Net Service Sales (CP003) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP003_FIELD)} onBlur={handleSumCp003AndCp004} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Service Sales Total Discount (CP004) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP004_FIELD)} onBlur={handleBlurCp004} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Gross Service Sales (CP003 + CP004) $ (calculated)'
                field={<div style={boundLabelStyle}><BoundLabel {...formProps(CP003_PLUS_CP004_FIELD)} /></div>}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Accounting Service + On-Wing COS (CP005) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP005_FIELD)} onBlur={handleCp004DivCp005} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Program Expenses (CP019) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP019_FIELD)} />}
              />
            </FormTable>
          </FormHalfScreenLeft>
          <FormHalfScreenRight>
            <FormTable>
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Fully Reduced Spare Parts @CLP (PMA,Used,Esc) (CP006) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP006_FIELD)} onBlur={handleCp010DivCp006} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Spare Parts PMA & Used Anticipated Reduction (CP007) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP007_FIELD)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Gross Spare Parts @CLP (CP008) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP008_FIELD)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Gross Spare Sales LLP (CP008A) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP008A_FIELD)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Spare Parts Total Discount (PMA,Used,Esc,FMP) (CP009) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP009_FIELD)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Spare Parts FMP Portion Contract Discount (CP010) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP010_FIELD)} onBlur={handleCp010DivCp006} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Spare Parts Escalation Discount (CP011) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP011_FIELD)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Spare Parts LLP Escalation Discount (CP011A) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP011A_FIELD)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Spare Parts Mfg COS (CP012) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP012_FIELD)} />}
              />
            </FormTable>
          </FormHalfScreenRight>
        </FlexByRow>
        <SectionDivider />
        <FormDivider title='Partner & CSA' />
        <FlexByRow>
          <FormHalfScreenLeft>
            <FormTable>
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Partner Share of Gross Spare Parts @CLP (CP013) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP013_FIELD)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD CSA Used Matl Profit Sharing Credit (+) (CP018) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP018_FIELD)} />}
              />
            </FormTable>
          </FormHalfScreenLeft>
          <FormHalfScreenRight>
            <FormTable>
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Partner Share of Spare Parts Discount (CP014) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP014_FIELD)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD Partner Share of Service Sales (CP020) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP020_FIELD)} />}
              />
            </FormTable>
          </FormHalfScreenRight>
        </FlexByRow>
        <SectionDivider />
        <FormDivider title='Previous EAC' />
        <FlexByRow>
          <FormHalfScreenLeft>
            <FormTable>
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD FMP Portion Spare Parts Discount (CP010 / CP006) % (calculated)'
                field={<div style={boundLabelStyle}><BoundLabel {...formProps(CP010DIVCP006_FIELD)} /></div>}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='ITD FMP Service Discount (CP004 / CP005) % (calculated)'
                field={<div style={boundLabelStyle}><BoundLabel {...formProps(CP004DIVCP005_FIELD)} /></div>}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='Spare Parts PMA & Used Anticipated Reduction %'
                field={<Step3BoundSpanasPercentEntryField {...formProps(SPARE_PARTS_PA_AND_USED_ANTICIPATED_REDUCTION_FIELD)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='LOP Loss Provision (positive value) (CP015) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP015_FIELD)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='Total Weighted % Compl for Loss Provision Liquidation (CP016)'
                field={<Step3BoundSpanasPercentEntryField {...formProps(SPANAS_CP016_FIELD)} />}
              />
            </FormTable>
          </FormHalfScreenLeft>
          <FormHalfScreenRight>
            <FormTable>
              <TableFormDescriptionAndNumberField
                fieldDescription='Total Service Sales after discount "A" $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(TOTAL_SERVICE_SALES_AFTER_DISCOUNT)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='Total Service Sales before discount "B" $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(TOTAL_SERVICE_SALES_BEFORE_DISCOUNT)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='Service COS "D" $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_SERVICE_COS)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='LOP Service COS "D" + Gross Spare Parts @CLP (CP017) $'
                field={<Step3BoundSpanasDollarEntryField {...formProps(SPANAS_CP017_FIELD)} />}
              />
            </FormTable>
          </FormHalfScreenRight>
        </FlexByRow>
        <SectionDivider />
        <FormDivider title='Forecast Items' />
        <FlexByRow>
          <FormHalfScreenLeft>
            <FormTable>
              <TableFormDescriptionAndNumberField
                fieldDescription='LOP SG&A (Cost Sheet) $'
                field={<Step3BoundDollarEntryField {...formProps(LOP_SGA_AND_A_FIELD)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='Manual Service Cum-Catchup Gross Sales $'
                field={<Step3BoundDollarEntryField {...formProps(MANUAL_SERVIDE_CUM_CATCHUP_GROSS_SALES_FIELD)} />}
              />
            </FormTable>
          </FormHalfScreenLeft>
          <FormHalfScreenRight>
            <FormTable>
              <TableFormDescriptionAndNumberField
                fieldDescription='Customer Collection Factor % (% Invoices Paid by Cust)'
                field={<Step3BoundPercentEntryField {...formProps(CUSTOMER_COLLECTION_FACTOR_FIELD)} />}
              />
              <TableFormDescriptionAndNumberField
                fieldDescription='Manual Service Cum-Catchup Net Sales $'
                field={<Step3BoundDollarEntryField {...formProps(MANUAL_SERVIDE_CUM_CATCHUP_NET_SALES_FIELD)} />}
              />
            </FormTable>
          </FormHalfScreenRight>
        </FlexByRow>
      </Panel>
    </FormBodyContainer>
  )
}

FormBody.propTypes = {
  formProps: PropTypes.func,
  data: PropTypes.object
}

const ReloadSpanasButton = forwardRef((_props, ref) => {
  const handleClick = async () => {
    const data = await uiGet(loadSpanas)
    // This will call a closure function in the formBody to reload spanas in the controls.
    triggerObserver(reloadSpanas, data)
  }

  return (
    <ContainedButton onClick={handleClick}>
      Reload Spanas
    </ContainedButton>
  )
})

const StepCommentsButton = forwardRef((_props, ref) => {
  const handleClick = async () => {
    const boundData = await triggerObserver(retrieveStepComments)
    openStepComments({ step: 3, boundData })
  }

  return (
    <ContainedButton onClick={handleClick}>
      Comments
    </ContainedButton>
  )
})

const InternalButtons = forwardRef((_props, ref) => {
  const beforeButtons = useRef([])

  useConstructor(() => {
    beforeButtons.current.push(StepCommentsButton)
    beforeButtons.current.push(ReloadSpanasButton)
  })

  return (
    <StepButtons ref={ref} beforeButtons={beforeButtons.current} />
  )
})

const Step3 = () => {
  return (
    <GeneralEditForm
      topPart={<PageTopContainer>Step 3</PageTopContainer>}
      formTemplate={formTemplate}
      getService={loadStep3}
      postService={saveStep3}
      saveMessageTitle='Step 3 Form Saved'
      saveMessage='Step 3 Saved Successfully'
      formBody={props => <FormBody {...props} />}
      buttons={InternalButtons}
    />
  )
}

export default Step3