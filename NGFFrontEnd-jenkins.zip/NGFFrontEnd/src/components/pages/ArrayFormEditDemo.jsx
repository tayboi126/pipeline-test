import React, { useRef } from 'react'
import PropTypes from 'prop-types'
import styled from 'styled-components'

import { YDivider, XDivider } from 'pwlib/styles'
import { arrKey, arrTemplateKey } from 'pwlib/common'
import { MainRoutePage } from '../appcontrol/RoutePage'
import { TextField, SaveButton, ListComponent, convertToListEntryFormComponent } from 'pwlib/components/formcontrols'
import { ContainedButton } from 'pwlib/components/controls'
import { useFormHandler } from 'pwlib/hooks'
import { LocalToast } from 'pwlib/containers'
import { subRouteTitleHeight } from '../../common/constants'
import useBasicAppHeightOverhead from '../../hooks/useBasicAppHeightOverhead'

const buttonsHeight = '60px'
const addressesKey = 'addresses'

const mockGetObject = {
  [addressesKey]: [
    {
      name: 'John Doe 1',
      address: '1137 6th Street-1',
    },
    {
      name: 'John Doe 2',
      address: '1137 6th Street-2',
    },
    {
      name: 'John Doe 3',
      address: '1137 6th Street-3',
    }
  ]
}

const listEntryTemplate = [
  {
    label: 'Name',
    fieldKey: 'name',
    isRequired: true,
  },
  {
    label: 'Address',
    fieldKey: 'address',
    isRequired: true,
  },
]

const ButtonsContainer = styled.div`
  padding-right: 20px;
  height: ${buttonsHeight};
  display: flex;
  align-items: center;
`

const PageContainer = styled.div`
  width: 100%;
  padding: 20px 20px 0px 20px;
`

const ComponentsContainer = styled.div`
  overflow: auto;
  height: ${props => props.height};
`

const VerticalDivider = () =>
  <YDivider height='20px' />

  
const NAME_FIELD = 0
const ADDRESS_FIELD = 1

// List entry components are wrapped in convertToListEntryFormComponent.
const ListEntryComponent = convertToListEntryFormComponent(props => {
  // arrRefs, data, formTemplate are passed in as props rather than useFormPageHandler.
  // eslint-disable-next-line react/prop-types
  const { arrRefs, data, formTemplate } = props
  // The rendering is the same as with a normal form without lists.
  return (
    <>
      <TextField
        data={data}
        fieldTemplate={formTemplate[NAME_FIELD]}
        ref={arrRefs[NAME_FIELD]}
      />
      <VerticalDivider />
      <TextField
        data={data}
        fieldTemplate={formTemplate[ADDRESS_FIELD]}
        ref={arrRefs[ADDRESS_FIELD]}
      />
      <YDivider height='40px' />
    </>
  )
})

// Note how a list form is defined in the templates.
/*
  [arrKey] is what key the list data is located in the backend result object.
  [arrTemplateKey] is the template for a list entry in the backend result object.
  listEntryComponent is the react component that will handle rendering a list entry's data.
*/
const formTemplate = [
  { [arrKey]: 'addresses', [arrTemplateKey]: listEntryTemplate, listEntryComponent: ListEntryComponent }
]

const Buttons = props =>
  <ButtonsContainer>
    <ContainedButton onClick={props.arrRefs[0].current?.addEntry}>Insert Entry</ContainedButton>
    <XDivider width='20px' />
    <SaveButton feedBack arrRefs={props.arrRefs} postService={props.postService} />
  </ButtonsContainer>

Buttons.propTypes = {
  arrRefs: PropTypes.array,
  postService: PropTypes.func
}

// Use the function basehttp.get for the get in your service.
const getService = () => {
  // This simulates a basehttp.get.
  return new Promise(resolve => {
    setTimeout(() => {
      resolve(mockGetObject)
    }, 2000)
  })
}

// This has an edit feature. So, a getService must be defined to retrieve the data from the server.
const ArrayFormEditDemo = () => {
  const basicHeight = useBasicAppHeightOverhead()
  const routeWindowHeightOverhead = basicHeight + parseInt(subRouteTitleHeight)
  const componentsHeight = `calc(100vh - ${routeWindowHeightOverhead}px - ${buttonsHeight})`
  const refLocalToast = useRef(null)
  const { arrRefs, isLoaded, formProps } = useFormHandler({ 
    formTemplate, 
    service: getService, 
  })

  // Defined the below in services
  // Use the function uiPost for the post.
  const postService = postObject => {
    const doPost = postObject => {
      // eslint-disable-next-line no-console
      console.log('post', JSON.stringify(postObject, undefined, 2))
      refLocalToast.current?.successToastOn({ message: 'Form Saved Successfully', title: 'Form Saved' })
    }
    return new Promise(resolve => {
      setTimeout(() => resolve(doPost(postObject)), 2000)
    })
  }

  return (
    <MainRoutePage 
      mainTitle='Form Demo' 
      buttons={<Buttons formTemplate={formTemplate} arrRefs={arrRefs} postService={postService} />}
      rightButtons
      style={{ paddingTop: '20px' }}
    >
      <PageContainer>
        <LocalToast ref={refLocalToast} />
        <ComponentsContainer height={componentsHeight}>
          <ListComponent
            {...formProps(0)}
            isLoaded={isLoaded} // This is required in order for the component to know when to load.
          />
        </ComponentsContainer>
      </PageContainer>
    </MainRoutePage>
  )
}

export default ArrayFormEditDemo