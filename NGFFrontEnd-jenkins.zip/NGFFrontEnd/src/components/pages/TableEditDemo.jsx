/* eslint-disable react/prop-types */
import React, { useRef } from 'react'
import PropTypes from 'prop-types'
import styled from 'styled-components'
import { XDivider, ExpandingContainer } from 'pwlib/styles'
import { useFormPageHandler } from 'pwlib/hooks'
import { FastInputTable, IconButton } from 'pwlib/components/controls'
import { LocalToast } from 'pwlib/containers'
import { TextField, Select, DateTime, Switch, SaveButton, InsertRowButton, convertToFormComponent } from 'pwlib/components/formcontrols'
import { Delete } from 'pwlib/icons'

import { MainRoutePage } from '../appcontrol/RoutePage'

export const acGroupText = 'Ac Group'

const numbersWidth = 40

const selectItems = [
  { value: '10', label: 'Select 1' },
  { value: '20', label: 'Select 2' },
  { value: '30', label: 'Select 3' },
  { value: '40', label: 'Select 4' },
  { value: '50', label: 'Select 5' }
]

// Describes the table column headers. Also describes sorting and filtering.
const columns = [
  {
    label: 'Delete',
    width: 20,
    title: `Delete the ${acGroupText}`,
    align: 'center',
    // Is a delete row button. When clicked, that row will be deleted.
    isDelete: true,
    // eslint-disable-next-line no-console
    onDelete: (onOK, rowData) => { console.log('onDelete', onOK, rowData); onOK() }
  },
  {
    // Header column label.
    label: 'Name', 
    // Column min width.
    minWidth: 170,
    // Used to define the kind of sort and filtering
    columnType: 'string',
    hasSort: true,
    hasFilter: true,
    // Used to align the column. Do not use for an input column type.
    // align: 'right'
    // Column header style override.
    // style: {}
    // filterProps: { items: selectItems },
    // Clickable row
    // isClick: true,
    // isDelete: bool
    // onDelete: function, must have isDelete true
  },
  { 
    label: 'Date', 
    minWidth: 120,
    columnType: 'date',
    hasSort: true,
    hasFilter: true,
    filterProps: { type: 'date' }
  },
  {
    label: 'Select',
    minWidth: 120,
    columnType: 'select',
    hasSort: true,
    hasFilter: true,
    filterProps: { items: selectItems },
    isClick: true
  },
  {
    label: 'Data 1',
    minWidth: 120,
    columnType: 'number',
    hasSort: true,
    hasFilter: true
  },
  {
    label: 'Bool',
    minWidth: 110,
    columnType: 'bool',
    hasSort: true,
    hasFilter: true
  },
  {
    label: 'Data 3',
    minWidth: 110,
    columnType: 'select',
    hasSort: true,
    hasFilter: true
  },
  {
    label: 'Data 4',
    minWidth: numbersWidth,
  },
  {
    label: 'Data 5',
    minWidth: numbersWidth,
  },
  {
    label: 'Data 6',
    minWidth: numbersWidth,
  },
  {
    label: 'Data 7',
    minWidth: numbersWidth,
  },
  {
    label: 'Data 8',
    minWidth: numbersWidth,
  },
  {
    label: 'Data 9',
    minWidth: numbersWidth,
  },
]

const Buttons = props =>
  <>
    <InsertRowButton tableRef={props.tableRef} arrKeyInBackendObject={props.arrKeyInBackendObject} arrRefs={props.arrRefs} rowFieldTemplates={props.rowFieldTemplates} rowComponents={props.rowComponents} />
    <XDivider width='10px' />
    <SaveButton feedBack arrKeyInBackendObject={props.arrKeyInBackendObject} arrRefs={props.arrRefs} postService={props.postService} />
  </>

Buttons.propTypes = {
  arrRefs: PropTypes.array,
  postService: PropTypes.func,
  arrKeyInBackendObject: PropTypes.string,
}

const PageContainer = styled(ExpandingContainer)`
  width: 100%;
  padding-top: 20px;
`

// Use the function basehttp.get for the get in your service.
const getService = () => {
  const arr = []
  let dataValue = 1
  for (let i = 0; i < 16; ++i) {
    const obj = {
      name: `Name ${i}`,
      date: '2021-12-01',
      select: '10',
      data1: dataValue++,
      data2: false,
      data3: dataValue++,
      data4: dataValue++,
      data5: dataValue++,
      data6: dataValue++,
      data7: dataValue++,
      data8: dataValue++,
      data9: dataValue++,
    }
    arr.push(obj)
  }
  // This simulates a basehttp.get.
  const mockGetObject = {
    arr
  } 
  return new Promise(resolve => {
    setTimeout(() => {
      resolve(mockGetObject)
    }, 2000)
  })
}

const fast = true
// This describes the table row columns in terms of the form controls.
const rowComponents = [
  // If adding non-form components, wrap them with convertToFormComponent.
  {
    component: convertToFormComponent(props => {
      const { customValue, ...finalProps } = props
      return (
        <IconButton {...finalProps}><Delete /></IconButton>
      )
    }) 
  },
  { component: TextField, props: { fastTableTextField: fast } },
  { component: DateTime, props: { type: 'date' } },
  { component: Select, props: { items: selectItems } },
  { component: TextField, props: { fastTableTextField: fast } },
  { component: Switch },
  { component: TextField, props: { fastTableTextField: fast } },
  { component: TextField, props: { fastTableTextField: fast } },
  { component: TextField, props: { fastTableTextField: fast } },
  { component: TextField, props: { fastTableTextField: fast } },
  { component: TextField, props: { fastTableTextField: fast } },
  { component: TextField, props: { fastTableTextField: fast } },
  { component: TextField, props: { fastTableTextField: fast } },
]

// This describes the table row columns in terms of form templates.
const rowFieldTemplates = [
  {
  },
  {
    fieldKey: 'name',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'date',
    defaultValue: '',
    isRequired: true,
  },
  {
    fieldKey: 'select',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'data1',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'data2',
    defaultValue: false,
  },
  {
    fieldKey: 'data3',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'data4',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'data5',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'data6',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'data7',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'data8',
    defaultValue: '',
    isRequired: true
  },
  {
    fieldKey: 'data9',
    defaultValue: '',
    isRequired: true
  },
]

const arrKeyInBackendObject = 'arr'

const TableEditDemo = () => {
  const refLocalToast = useRef(null)
  const tableRef = useRef(null)
  const [arrRefs, , isLoaded, rows] = useFormPageHandler({ 
    // This is the key location in the get/post object on where the list of entries for the table is located.
    arrKeyInBackendObject, 
    rowFieldTemplates, 
    rowComponents, 
    service: getService
  })

  // Define the below in services
  // Use the function uiPost for the post.
  const postService = postObject => {
    const doPost = postObject => {
      refLocalToast.current?.successToastOn({ message: 'Form Saved Successfully', title: 'Form Saved' })
    }
    return new Promise(resolve => {
      // eslint-disable-next-line no-console
      console.log(JSON.stringify(postObject, undefined, 2))
      resolve(doPost(postObject))
      // setTimeout(() => resolve(doPost(postObject)), 2000)
    })
  }

  const onClickRowEntry = (rowIndex, refs) => {
    /*
    for (let i = 1; i < refs.length; ++i) {
      refs[i].current.setDisabled(true)
    }
    */
    tableRef.current.toggleRow(rowIndex)
  }

  return (
    <MainRoutePage 
      mainTitle='Fast Edit Table Demo' 
      buttons={<Buttons tableRef={tableRef} arrKeyInBackendObject={arrKeyInBackendObject} arrRefs={arrRefs} postService={postService} rowFieldTemplates={rowFieldTemplates} rowComponents={rowComponents} />}
      rightButtons
      style={{ paddingTop: '20px' }}
    >
      <PageContainer>
        <LocalToast ref={refLocalToast} />
        { isLoaded && <FastInputTable showHover onClickRowEntry={onClickRowEntry} ref={tableRef} arrRefs={arrRefs} rows={rows} columns={columns} /> }
      </PageContainer>
    </MainRoutePage>
  )
}

export default TableEditDemo
