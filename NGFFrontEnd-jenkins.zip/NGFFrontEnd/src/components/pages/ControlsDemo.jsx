/* eslint-disable no-console */
import React, { useState, useCallback, useEffect } from 'react'
import { CenterInParent, XDivider, YDivider } from 'pwlib/styles'
import styled from 'styled-components'
import { openInformationDialog, openGeneralDialog } from 'pwlib/containers'
import { ToggleButtons, PrimaryButton, SpecialButton, Chip, ToolTip, MultiSelectWithCheckboxes, MenuButton, ThemeButton, CheckBox, RadioGroup, Select, Slider, Switch, TextFieldOutlined, TextField, Menu, DateTime, ContainedButton, TextButton, OutlinedButton } from 'pwlib/components/controls'
import { MoreVert, VolumeDown, VolumeUp, Info } from 'pwlib/icons'
import { useMergeState, useUiGet } from 'pwlib/hooks'
import { uiGet } from 'pwlib/http'
import { useNavigate } from 'react-router-dom'

import { formEditDemo, tableEditDemo, arrayFormEditDemo } from '../../navigation/routePaths'
import { MainRoutePage } from '../appcontrol/RoutePage'
import SecondaryButton from '../controls/SecondaryButton'

const Main = styled.div`
  padding: 20px;
  position: relative;
  width: 100%;
  height: 100%;
`

const MultiSelectWithCheckboxesContainer = styled.div`
  width: 250px; 
`

const HomeTextContainer = styled(CenterInParent)`
  font-size: 25px;
`

const Partition = styled.div`
  width: 100%;
`

const PartitionDivider = () => 
  <XDivider width='200px' />

const Divider = () => 
  <YDivider height='10px' />

const PartitionsContainer = styled.div`
  display: flex;
  justify-content: space-evenly;
`

const radioItems = [
  { value: 'Radio1', label: 'Radio 1' },
  { value: 'Radio2', label: 'Radio 2' },
  { value: 'Radio3', label: 'Radio 3' }
]

const toggleGroupItems = [
  { value: '1', label: 'Dashboard' },
  { value: '2', label: 'EAC Listing' },
  { value: '3', label: 'Admin' }
]

const selectItems = [
  { value: '10', label: 'Select 1' },
  { value: '20', label: 'Select 2' },
  { value: '30', label: 'Select 3' },
  { value: '40', label: 'Select 4' },
  { value: '50', label: 'Select 5' }
]

const menuItems = [
  { value: '10', label: 'Menu item 1' },
  { value: '20', label: 'Menu item 2' },
  { value: '30', label: 'Menu item 3' },
]

const MemoryLeakComponent = () => {
  const [, setCount] = useState(0)
  useEffect(() => {
    setTimeout(() => { console.log('***** MemoryLeakComponent demonstrates "Can\'t perform a React state update on an unmounted component."'); setCount(10) }, 1000)
    return () => console.log('MemoryLeakComponent dismount')
  }, [])
  return (
    <div />
  )
}

const MemoryLeakComponentFixed = () => {
  const [, setState] = useMergeState({})
  useEffect(() => {
    setTimeout(() => { console.log('***** MemoryLeakComponentFixed demonstrates no "Can\'t perform a React state update on an unmounted component." error.'); setState({ count: 10 }) }, 1000)
    return () => console.log('MemoryLeakComponentFixed dismount')
  }, [])
  return (
    <div />
  )
}

let key = 0
const initialState = { start: 'true', testData: 'stale', data: null }
const ComponentDemo = () => {
  const navigate = useNavigate()
  console.log('enter ComponentDemo')
  const [value1, setValue1] = useState(0)
  const [value2, setValue2] = useState(0)
  const [state, setState, getState] = useMergeState(initialState)

  console.log('ComponentDemo after useMergeState', state)
  const openModal = () => {
    openInformationDialog({ message: 'To subscribe to this website, please enter your email address here. We will send updates occasionally.' })
  }

  const openDialog = () => {
    openGeneralDialog({ dividers: true, closeX: true, message: () => <div>To subscribe to this website, please enter your email address here. We will send updates occasionally.</div> })
  }
  const testHttp = async () => {
    console.log('testHttp')
    await uiGet('https://jsonplaceholder.typicode.com/todos')

    // This shows 1 render for each setValue
    console.log('')
    console.log('****** Shows 1 render for each state change call.')
    console.log('call setValue1')
    setValue1(value1 + 1)
    console.log('call setValue2')
    setValue2(value2 + 1)
    console.log('****** Shows 1 render for each state change call end.')
    console.log('')
  }
  const testButton = () => {
    console.log('')
    console.log('****** Shows value1 after setValue1 is not the new state.')
    console.log(`value1=${value1}`)
    console.log(`call setValue1 and change to value1=${value1 + 1}.`)
    setValue1(value1 + 1)
    console.log(`value1 after setValue1, note that it did not change, value1=${value1}.`)
    console.log('****** Shows value1 after setValue1 is not the new state end.')
    console.log('')
    setValue2(value2 + 1)
  }
  const onChange = useCallback(() => {

  }, [])

  const handleData = data => {
    console.log('')
    console.log('****** Shows the stale state problem, state is not correct with testData="stale" but getState() is with testData="fresh2".')
    console.log('handleData callback stale state, state.testData=', state.testData)
    console.log('handleData callback getState, resolves stale state, getState().testData=', getState().testData)
    console.log('****** Shows the stale state problem end.')
    console.log('')
    setState({ data })
  }

  useEffect(() => {
    console.log('')
    console.log('****** Demonstrate setState callbacks.')
    setState({ testData: 'fresh' }, state => {
      console.log('')
      console.log('***** callback', state)
    })
    console.log('call getState', getState())
    setState({ testData: 'fresh2' }, state => {
      console.log('')
      console.log('***** callback2', state)
    })
    console.log('call getState2', getState())
    console.log('****** Demonstrate setState callbacks end.')
    console.log('')
  }, [])

  useEffect(() => {
    if (state.data) {
      setState({ data: null })
    }
  }, [state.data])

  useUiGet('https://jsonplaceholder.typicode.com/todos', handleData)
  return (
    <MainRoutePage 
      mainTitle='NEXTGEN Finance'
      style={{ paddingTop: '20px' }}
    >
      <Main>
        {console.log('render Home')}
        <HomeTextContainer>
          {state.data ? <MemoryLeakComponent data={state.data} /> : null}
          {state.data ? <MemoryLeakComponentFixed data={state.data} /> : null}
          <PartitionsContainer>
            <Partition>
              <Divider />
              <ContainedButton onClick={openModal}>
                Open Info Modal
              </ContainedButton>
              <Divider />
              <ContainedButton color='secondary' onClick={openDialog}>
                Open General Modal
              </ContainedButton>
              <Divider />
              <ContainedButton onClick={testHttp}>
                Test http
              </ContainedButton>
              <Divider />
              <TextButton onClick={testButton} >
                {`Text Button ${value1} ${value2}`}
              </TextButton>
              <Divider />
              <OutlinedButton onClick={() => {}}>
                Outline Button
              </OutlinedButton>
              <Divider />
              <ThemeButton variant='contained' >
                Default Button
              </ThemeButton>
              <Divider />
              <CheckBox label='Checkbox' />
              <CheckBox checkColor='green' label='Custom Checkbox' />
            </Partition>
            <PartitionDivider />
            <Partition>
              <RadioGroup label={'Radio Buttons'} items={radioItems} />
              <Divider />
              <Select label={'Select Demo'} items={selectItems} />
              <Divider />
              <Slider label={'Volume'} leftIcon={VolumeDown} rightIcon={VolumeUp}/>
              <Divider />
              <Switch label={'Switch Demo'} />
              <Divider />
              <TextField label={'TextField'} key={++key} onChange={onChange} 
              />
              <YDivider height='20px' />
              <TextFieldOutlined 
                label={'TextField'}
              />
              <Divider />
              <Menu
                onSelect={value => { console.log(`menu item value=${value}`) }}
                items={menuItems}
              >
                <ThemeButton
                  variant='contained'
                  color='primary'
                  aria-haspopup='true'
                >
                  Menu Demo
                </ThemeButton>
              </Menu>
            </Partition>
            <PartitionDivider />
            <Partition>
              <DateTime label='Date time demo'/>
              <Divider />
              <MenuButton
                buttonIcon={<MoreVert />}
                onSelect={value => console.log(`menu item value=${value}`)}
                items={menuItems}
              />
              <Divider />
              <MultiSelectWithCheckboxesContainer>
                <MultiSelectWithCheckboxes label='Multi Select With Checkboxes' items={selectItems} />
              </MultiSelectWithCheckboxesContainer>
              <Divider />
              <ToolTip
                message='This is a tooltip. This is a tooltip. This is a tooltip. This is a tooltip. This is a tooltip. This is a tooltip. '
                style={{ height: '21px' }}
              >
                <Info />
              </ToolTip>
              <Divider />
              <Chip label='This is a Chip' size='small' backgroundColor='red' textColor='white' fontSize='12px' />
              <Divider />
              <PrimaryButton onClick={() => navigate(formEditDemo)}>
                Form Edit Demo
              </PrimaryButton>
              <Divider />
              <SecondaryButton onClick={() => navigate(tableEditDemo)}>
                Table Edit Demo
              </SecondaryButton>
              <Divider />
              <SpecialButton onClick={() => navigate(tableEditDemo)}>
                Table Edit Demo
              </SpecialButton>
              <Divider />
              <SecondaryButton onClick={() => navigate(arrayFormEditDemo)}>
                Array Form Edit Demo
              </SecondaryButton>
              <Divider />
              <ToggleButtons style={{ width: '120px' }} items={toggleGroupItems} />
            </Partition>
          </PartitionsContainer>
        </HomeTextContainer>
      </Main>
    </MainRoutePage>
  )
}

export default ComponentDemo