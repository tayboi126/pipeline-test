import React from 'react'
import styled from 'styled-components'
import { BrowserRouter as Router } from 'react-router-dom'
import { setEnv } from 'pwlib/http'
import { useConstructor } from 'pwlib/hooks'

import Routes from '../navigation/Routes'
import { env } from '../env'

const CoreAppContainer = styled.div`
  width: 100%;
`

/**
 * CoreApp sets up react tree with routing.
 *
 * @returns {React.ReactElement} - React component
 */
const CoreApp = () => {
  useConstructor(() => {
    setEnv(env)
  })

  return (
    <CoreAppContainer>
      <Router>
        <Routes />
      </Router>
    </CoreAppContainer>
  )
}

export default CoreApp
