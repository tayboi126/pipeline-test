import React, { useRef, useImperativeHandle, forwardRef, createRef, Fragment } from 'react'
import styled from 'styled-components'
import PropTypes from 'prop-types'
import { HalfScreen } from 'pwlib/styles'

import { useConstructor } from 'pwlib/hooks'
import { SaveButton, CancelButton } from 'pwlib/components/formcontrols'

import { DividerForStepButtons } from '../styles'
import { pageTitleFontSize } from '../common/constants'

const tdPadding = '6px 0px'
const numberDescriptionStyle = { display: 'flex', alignItems: 'flex-end', height: '24px', lineHeight: '12px' }

export const PageContainer = styled.div`
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
`

export const PageButtonsContainer = styled.div`
  height: 60px;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
`

export const PageTopContainer = styled.div`
  padding-left: 20px;
  font-size: ${pageTitleFontSize};
  height: 60px;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  position: relative;
`

export const FormHalfScreenLeft = styled(HalfScreen)`
  padding-right: 20px;
`

export const FormHalfScreenRight = styled(HalfScreen)`
  padding-left: 20px;
`

export const FormBodyContainer = styled.div`
  padding: 6px 20px;
`

const FieldTitle = styled.div`
`

export const TableFormDescriptionAndField = props => {
  return (
    <tr style={{ width: '100%' }}>
      <td style={{ width: '50%', padding: props.padding || tdPadding }}><FieldTitle title={props.title} style={props.style}>{`${props.fieldDescription}:`}</FieldTitle></td>
      <td style={{ width: '50%' }}>{props.field}</td>
    </tr>
  )
}

TableFormDescriptionAndField.propTypes = {
  field: PropTypes.object,
  fieldDescription: PropTypes.string,
  style: PropTypes.object,
  title: PropTypes.string,
  padding: PropTypes.string
}

export const TableFormDescriptionAndNumberField = props => {
  return (
    <tr style={{ width: '100%' }}>
      <td style={{ width: '99%' }}><div style={numberDescriptionStyle}><FieldTitle title={props.title} style={props.style}>{`${props.fieldDescription}:`}</FieldTitle></div></td>
      <td>{props.field}</td>
    </tr>
  )
}

TableFormDescriptionAndNumberField.propTypes = {
  field: PropTypes.object,
  fieldDescription: PropTypes.string,
  title: PropTypes.string,
  style: PropTypes.object,
  // padding: PropTypes.string
}

export const FormButtons = forwardRef((props, ref) => {
  const refBeforeButtons = useRef([])
  const refAfterButtons = useRef([])
  const isDisabled = useRef(true)
  const refSaveButton = useRef()
  const refBeforeButtonsRefs = useRef([])
  const refAfterButtonsRefs = useRef([])

  useConstructor(() => {
    if (props.beforeButtons) {
      for (let i = 0; i < props.beforeButtons.length; ++i) {
        const ref = createRef()
        refBeforeButtonsRefs.current.push(ref)
        const ButtonComponent = props.beforeButtons[i]
        refBeforeButtons.current.push(
          <Fragment key={i}>
            <ButtonComponent ref={ref} />
            <DividerForStepButtons />
          </Fragment>
        )
      }
    }
    if (props.afterButtons) {
      for (let i = 0; i < props.afterButtons.length; ++i) {
        const ref = createRef()
        refAfterButtonsRefs.current.push(ref)
        const ButtonComponent = props.afterButtons[i]
        refAfterButtons.current.push(
          <Fragment key={i}>
            <DividerForStepButtons ref={ref} />
            <ButtonComponent />
          </Fragment>
        )
      }
    }
  })

  // Must be defined in any form buttons.
  // This turns on and off the disable on the save button.
  // If there are no modified fields then the save button is disabled.
  const disableButtons = disabled => {
    if (isDisabled.current === disabled) {
      return
    }
    isDisabled.current = disabled
    refSaveButton.current.setDisabled(disabled)
    props.onDisableSaveButton && props.onDisableSaveButton(disabled)
  }
  
  // Must be defined in any form buttons.
  useImperativeHandle(ref, () => ({
    setDisabled: disabled => {
      disableButtons(disabled)
    },
    setSaveButtonText: buttonText => refSaveButton.current.setButtonText(buttonText)
  }))

  const handleClickSave = async postObject => {
    props.onBeforeSave && props.onBeforeSave(refBeforeButtonsRefs.current, refAfterButtonsRefs.current)
    await props.postService(postObject)
    props.onAfterSave && props.onAfterSave(refBeforeButtonsRefs.current, refAfterButtonsRefs.current)
  }

  return (
    <PageButtonsContainer>
      {refBeforeButtons.current}
      <SaveButton ref={refSaveButton} disabled feedBack saveLabel={props.saveLabel} arrRefs={props.arrRefs} formTemplate={props.formTemplate} postService={handleClickSave} boundControls={props.boundControls} data={props.data} />
      {refAfterButtons.current}
    </PageButtonsContainer>
  )
})

FormButtons.propTypes = {
  arrRefs: PropTypes.array,
  postService: PropTypes.func,
  boundControls: PropTypes.bool,
  data: PropTypes.object,
  formTemplate: PropTypes.array,
  saveLabel: PropTypes.string,
  beforeButtons: PropTypes.array,
  afterButtons: PropTypes.array,
  onBeforeSave: PropTypes.func,
  onAfterSave: PropTypes.func,
  onDisableSaveButton: PropTypes.func,
}

export const FormButtonsWithCancel = forwardRef((props, ref) => {
  const refCancelButton = useRef()
  const refBeforeButtons = useRef(props.beforeButtons || [])
  const { onCancel, ...finalProps } = props

  const handleCancel = () => {
    props.onCancel && props.onCancel()
  }

  const FormCancelButton = forwardRef((_props, ref) => {
    refCancelButton.current = ref.current
    return (
      <CancelButton ref={refCancelButton} onClick={handleCancel} />
    )
  })
  
  useConstructor(() => {
    refBeforeButtons.current.unshift(FormCancelButton)
  })

  const onDisableSaveButton = disabled => {
    refCancelButton.current && refCancelButton.current.setModified(!disabled)
  }

  return (
    <FormButtons ref={ref} {...finalProps} onDisableSaveButton={onDisableSaveButton} beforeButtons={refBeforeButtons.current} />
  )
})

FormButtonsWithCancel.propTypes = {
  ...FormButtons.propTypes,
  onCancel: PropTypes.func, 
}

export const FormTable = props => {
  return (
    <table id='FormTable' style={{ width: '100%' }}>
      <tbody>
        {props.children}
      </tbody>
    </table>
  )
}

FormTable.propTypes = {
  children: PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.node),
    PropTypes.node
  ]),
}
