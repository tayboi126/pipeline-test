import React, { useCallback, useRef, useImperativeHandle, forwardRef, useEffect } from 'react'
import { useForceRender, useConstructor } from 'pwlib/hooks'
import { FastTableTextField } from 'pwlib/components/controls'
import PropTypes from 'prop-types'
import { useTheme } from 'pwlib/styles'
import { round, modifiedKey } from 'pwlib/common'
import { useBoundFormBase, boundFormImperativeHandleFunctions, fieldIsRequired, handleBoundFormPostError, handleRequired, ErrorMessage } from 'pwlib/components/formcontrols/common'

let traceTiming = false
if (process.env.NODE_ENV === 'production') {
  traceTiming = false
}

export const defaultNumIntegralDigits = 12

export const dollarNumberType = 'dollar'
export const percentNumberType = 'percent'
export const decimalNumberType = 'decimal'

const numberToCommaStringNumber = (numberValue, numDigits) =>
  numberValue.toLocaleString('en-US', { minimumFractionDigits: numDigits, maximumFractionDigits: numDigits })

const handleNegativeStringNumber = (strNumber, isNegative) => {
  if (isNegative) {
    return `(${strNumber})`
  }
  return strNumber
}

export const translateNumberToString = (type, numberValue, numFractionalDigits) => {
  if (numberValue === null) {
    return ''
  }
  const isNegative = numberValue < 0
  if (isNegative) {
    numberValue = -numberValue
  }
  let appendChar = ''
  let prependChar = ''
  if (type === dollarNumberType) {
    numFractionalDigits = 2
    prependChar = '$'
  } else if (type === percentNumberType) {
    appendChar = '%'
  }
  return `${prependChar}${handleNegativeStringNumber(numberToCommaStringNumber(round(numberValue, numFractionalDigits), numFractionalDigits), isNegative)}${appendChar}`
}

const translateStringToNumber = (strNumber, numFractionalDigits) => {
  if (strNumber === '') {
    return null
  }
  let isNegative = false
  strNumber = strNumber.replace(/\$/g, '')
  strNumber = strNumber.replace(/%/g, '')
  strNumber = strNumber.replace(/,/g, '')
  if (strNumber.charAt(0) === '(') {
    isNegative = true
    strNumber = strNumber.replace(/\(/g, '')
    strNumber = strNumber.replace(/\)/g, '')
  } else if (strNumber.charAt(0) === '-') {
    isNegative = true
    strNumber = strNumber.replace(/-/g, '')
  } else if (strNumber.charAt(0) === '+') {
    strNumber = strNumber.replace(/\+/g, '')
  }
  let number = parseFloat(strNumber)
  if (strNumber === '') {
    number = 0
  }
  if (isNegative) {
    number = -number
  }
  return round(number, numFractionalDigits)
}

export const NumberEntryField = forwardRef((props, ref) => {
  const { fieldIndex, strValue, baseValue, controlType, numFractionalDigits, numIntegralDigits, noNegative, ...finalProps } = props
  const refTextField = useRef()
  const theme = useTheme()
  const initialValue = useRef('')
  const initialColor = useRef()
  const currentValue = useRef('')
  const refBaseValue = useRef(baseValue)
  const toolTipMessage = useRef('')
  const initialToolTipMessage = useRef('')
  const forceRender = useForceRender()
  const currentColor = useRef()
  
  const handleColor = (num, withRefresh, inConstructor) => {
    let color
    if (refBaseValue.current === undefined) {
      color = undefined
    } else {
      color = num !== refBaseValue.current ? theme.palette.fieldDifferenceColor : undefined
    }
    if (color !== undefined) {
      if (initialToolTipMessage.current === '') {
        if (refBaseValue.current !== undefined) {
          initialToolTipMessage.current = translateNumberToString(controlType, refBaseValue.current, numFractionalDigits)
        }
      }
      if (toolTipMessage.current !== initialToolTipMessage.current) {
        toolTipMessage.current = initialToolTipMessage.current
        if (!inConstructor) {
          forceRender()
        }
      }
    } else {
      if (toolTipMessage.current !== '') {
        toolTipMessage.current = ''
        if (!inConstructor) {
          forceRender()
        }
      }
    }
    currentColor.current = color
    if (!inConstructor) {
      refTextField.current.setColor(color, withRefresh)
    } else {
      initialColor.current = color
    }
  }

  useConstructor(() => {
    if (strValue !== undefined) {
      initialValue.current = strValue
    } else {
      initialValue.current = translateNumberToString(controlType, props.value, props.numFractionalDigits)
    }
    currentValue.current = initialValue.current
    handleColor(props.value, false, true)
  })

  // When going off the field, we must display commas and number symbols like $, %.
  const onBlur = useCallback(() => {
    const num = translateStringToNumber(currentValue.current, numFractionalDigits)
    handleColor(num, true)
    currentValue.current = translateNumberToString(controlType, num, numFractionalDigits)
    if (currentValue.current !== refTextField.current.getValue()) {
      refTextField.current.setValue(currentValue.current, true)
    }
    props.onBlur && props.onBlur(num)
  })

  // When on the field, it looks like a number without decorations.
  const onFocus = useCallback(element => {
    const num = translateStringToNumber(currentValue.current, numFractionalDigits)
    currentValue.current = num === null ? '' : num.toFixed(numFractionalDigits)
    if (currentValue.current !== refTextField.current.getValue()) {
      refTextField.current.setValue(currentValue.current, true)
    }
    props.onFocus && props.onFocus(element)
  })

  useImperativeHandle(ref, () => ({
    focus: () => refTextField.current.focus(),
    getValue: () => {
      if (currentValue.current === '') {
        return null
      }
      return translateStringToNumber(currentValue.current, numFractionalDigits)
    },
    setValue: (newValue, bv, strV) => {
      if (bv !== undefined) {
        if (bv !== null && typeof bv !== 'number') {
          throw new Error('NumberEntryField.setValue: baseValue must be a number.')
        }
        refBaseValue.current = bv
      }
      if (newValue !== undefined) {
        if (newValue !== null && typeof newValue !== 'number') {
          throw new Error('NumberEntryField.setValue: baseValue must be a number.')
        }
      }
      handleColor(newValue)
      if (strV !== undefined) {
        currentValue.current = strV
      } else {
        currentValue.current = translateNumberToString(controlType, newValue, numFractionalDigits)
      }
      refTextField.current.setValue(currentValue.current)
    },
    setDisabled: disabled => refTextField.current.setDisabled(disabled),
    handleColor: (value, color, title) => {
      if (baseValue === undefined) {
        let doRefresh = false
        if (baseValue === undefined && toolTipMessage.current !== title) {
          toolTipMessage.current = title
          doRefresh = true
        }
        if (currentColor.current !== color) {
          currentColor.current = color
          refTextField.current.setColor(color, true)
        }
        if (doRefresh) {
          forceRender()
        }
      } else {
        handleColor(value)
      }
    },
    getColor: () => currentColor.current,
    render: () => refTextField.current.render()
  }), [])

  const handleChange = useCallback(value => {
    if (process.env.NODE_ENV !== 'production') {
      if (traceTiming) {
        // eslint-disable-next-line no-console
        console.log('NumberEntryField handleChange enter ', (new Date()).getTime())
      }
    }
    if (value !== '') {
      let strRegx
      if (value === '(') {
        if (noNegative) {
          refTextField.current.setValue(currentValue.current, true, refTextField.current.getCaretPosition() - 1)
          return
        }
        currentValue.current = '()'
        refTextField.current.setValue(currentValue.current, true, 1)
        props.onChange && props.onChange(currentValue.current, undefined, fieldIndex)
        return
      } else if (value.charAt(0) === '(' && currentValue.current.charAt(0) !== '(') {
        if (noNegative) {
          refTextField.current.setValue(currentValue.current, true, refTextField.current.getCaretPosition() - 1)
          return
        }
        if (value.charAt(value.length - 1) === ')') {
          currentValue.current = value
        } else {
          currentValue.current = `${value})`
        }
        refTextField.current.setValue(currentValue.current, true, 1)
        props.onChange && props.onChange(currentValue.current, undefined, fieldIndex)
        return
      } else if (value.charAt(0) !== '(' && currentValue.current.charAt(0) === '(') {
        currentValue.current = value.replace(')', '')
        refTextField.current.setValue(currentValue.current, true, 1)
        props.onChange && props.onChange(currentValue.current, undefined, fieldIndex)
        return
      } else if (value.charAt(0) === '-' && noNegative) {
        refTextField.current.setValue(currentValue.current, true, refTextField.current.getCaretPosition() - 1)
        return
      }
      
      if (numFractionalDigits === 0) {
        if (controlType === percentNumberType) {
          if (value.charAt(0) === '(') {
            strRegx = '^\\((100|\\d{0,2})\\)$'
          } else {
            strRegx = '^-$|^-?(100|\\d{0,2})$'
          }
        } else if (value.charAt(0) === '(') {
          strRegx = `^\\(\\d{0,${numIntegralDigits}}\\)$`
        } else {
          strRegx = `^-?\\d{0,${numIntegralDigits}}$`
        }
      } else if (controlType === percentNumberType) {
        if (value.charAt(0) === '(') {
          strRegx = `^\\((100|100(\\.(0{0,2}))|\\d{0,2}|\\d{0,2}(\\.(\\d{0,${numFractionalDigits}})))\\)$`
        } else {
          strRegx = `^-$|^-?(100|100(\\.(0{0,2}))|\\d{0,2}|\\d{0,2}(\\.(\\d{0,${numFractionalDigits}})))$`
        }
      } else {
        if (value.charAt(0) === '(') {
          strRegx = `^\\((\\d{1,${numIntegralDigits}}|\\d{0,${numIntegralDigits}}(\\.(\\d{0,${numFractionalDigits}})))\\)$`
        } else {
          strRegx = `^-$|^-?(\\d{1,${numIntegralDigits}}|\\d{0,${numIntegralDigits}}(\\.(\\d{0,${numFractionalDigits}})))$`
        }
      }
      const regex = new RegExp(strRegx)
      if (!regex.test(value)) {
        refTextField.current.setValue(currentValue.current, true, refTextField.current.getCaretPosition() - 1)
        return
      }
    }
    currentValue.current = value
    props.onChange && props.onChange(currentValue.current, undefined, fieldIndex)
    if (process.env.NODE_ENV !== 'production') {
      if (traceTiming) {
        // eslint-disable-next-line no-console
        console.log('NumberEntryField handleChange exit  ', (new Date()).getTime())
      }
    }
  }, [])

  useEffect(() => {
    if (process.env.NODE_ENV !== 'production') {
      if (traceTiming) {
        // eslint-disable-next-line no-console
        console.log('NumberEntryField render complete  ', (new Date()).getTime())
      }
    }
  })

  if (process.env.NODE_ENV !== 'production') {
    if (traceTiming) {
      // eslint-disable-next-line no-console
      console.log('NumberEntryField render          ', (new Date()).getTime())
    }
  }

  return (
    <FastTableTextField 
      {...finalProps} 
      title={toolTipMessage.current} 
      onBlur={onBlur} 
      onFocus={onFocus} 
      ref={refTextField}
      value={initialValue.current} 
      color={initialColor.current} 
      onChange={handleChange} 
    />
  )
})

NumberEntryField.propTypes = {
  onBlur: PropTypes.func,
  onFocus: PropTypes.func,
  onChange: PropTypes.func,
  value: PropTypes.number,
  baseValue: PropTypes.number,
  numFractionalDigits: PropTypes.number,
  numIntegralDigits: PropTypes.number,
  controlType: PropTypes.oneOf([dollarNumberType, percentNumberType, decimalNumberType]),
  strValue: PropTypes.string,
  style: PropTypes.object,
  noNegative: PropTypes.bool,
  fieldIndex: PropTypes.number,
}

NumberEntryField.defaultProps = {
  numFractionalDigits: 0,
  numIntegralDigits: defaultNumIntegralDigits,
  value: null
}

export const DollarEntryField = forwardRef((props, ref) => {
  return (
    <NumberEntryField
      {...props}
      ref={ref}
      controlType={dollarNumberType}
    />
  )
})
DollarEntryField.defaultProps = {
  numFractionalDigits: 2
}

export const PercentEntryField = forwardRef((props, ref) => {
  return (
    <NumberEntryField
      {...props}
      ref={ref}
      controlType={percentNumberType}
    />
  )
})

PercentEntryField.defaultProps = {
  numFractionalDigits: 2
}

export const DecimalEntryField = forwardRef((props, ref) => {
  return (
    <NumberEntryField
      {...props}
      ref={ref}
      controlType={decimalNumberType}
    />
  )
})

export const IntegerEntryField = forwardRef((props, ref) => {
  return (
    <NumberEntryField
      {...props}
      ref={ref}
      numFractionalDigits={0}
      controlType={decimalNumberType}
    />
  )
})

export const BoundNumberEntryField = forwardRef((props, ref) => {
  const theme = useTheme()
  const { fieldTemplate, srcObject, onChange, ...finalProps } = props
  const srcObjectKey = fieldTemplate.fieldKey
  const { refFormElement, setErrorMsg, errorMsg, errorMsgFixedHeight } = useBoundFormBase(props)
  const refColor = useRef()
  const refOriginalValue = useRef(!srcObjectKey || !srcObject[srcObjectKey] ? 0 : srcObject[srcObjectKey])
  const refTitle = useRef('')
  const refBaseValue = useRef(!fieldTemplate.baseFieldKey ? undefined : srcObject[fieldTemplate.baseFieldKey])

  useImperativeHandle(ref, () => ({
    ...boundFormImperativeHandleFunctions(fieldTemplate, refFormElement, setErrorMsg),
    validate: (postObject, refs) => {
      const value = refFormElement.current.getValue()
      let error = ''

      if (fieldIsRequired(fieldTemplate) && (value === undefined || value === null)) {
        error = handleRequired(props)
      } else if (fieldTemplate.maxValue !== undefined && value > fieldTemplate.maxValue) {
        error = `The maximum value is ${fieldTemplate.maxValue}.`
      } else if (fieldTemplate.minValue !== undefined && value < fieldTemplate.minValue) {
        error = `The minimum value is ${fieldTemplate.minValue}.`
      } else if (fieldTemplate.validator) {
        error = fieldTemplate.validator(value)
      } 
      return handleBoundFormPostError(error, setErrorMsg)
    },
    resetBaseValue: () => {
      refOriginalValue.current = !srcObject[srcObjectKey] ? 0 : srcObject[srcObjectKey]
      refTitle.current = undefined
      const currentColor = refColor.current
      refColor.current = undefined
      if (refBaseValue.current !== undefined) {
        refFormElement.current.handleColor(refOriginalValue.current, refColor.current, refTitle.current)
      } else if (currentColor !== undefined) {
        refFormElement.current.handleColor(refOriginalValue.current, refColor.current, refTitle.current)
      }
    },
    isModified: () => {
      return refOriginalValue.current !== props.srcObject[srcObjectKey]
    },
    isNumberField: true
  }), [])

  const handleChange = (...args) => {
    onChange && onChange(...args)
  }

  const handleBlur = numValue => {
    const currentColor = refColor.current
    const currentTitle = refTitle.current
    srcObject[fieldTemplate.fieldKey] = numValue
    if (numValue !== refOriginalValue.current) {
      refTitle.current = !refOriginalValue.current ? undefined : refOriginalValue.current.toString()
      refColor.current = theme.palette.fieldDifferenceColor
      srcObject[modifiedKey] = true
    } else {
      refTitle.current = undefined
      refColor.current = undefined
      srcObject[modifiedKey] = false
    }
    if (refFormElement.current.getColor() !== theme.palette.fieldDifferenceColor || refBaseValue.current === undefined) {
      if ((refFormElement.current.getColor() === undefined && refColor.current === theme.palette.fieldDifferenceColor) || currentColor !== refColor.current || refTitle.current !== currentTitle) {
        refFormElement.current.handleColor(numValue, refColor.current, refTitle.current)
      }
    }
    props.onBlur && props.onBlur(numValue, fieldTemplate.fieldKey, props.fieldIndex)
  }

  return (
    <>
      <NumberEntryField
        {...finalProps}
        value={srcObject[fieldTemplate.fieldKey]}
        baseValue={refBaseValue.current}
        ref={refFormElement}
        onBlur={handleBlur}
        onChange={handleChange}
      />
      <ErrorMessage errorMsg={errorMsg} errorMsgFixedHeight={errorMsgFixedHeight} />
    </>
  )
})

BoundNumberEntryField.propTypes = {
  srcObject: PropTypes.object,
  fieldTemplate: PropTypes.object,
  onBlur: PropTypes.func,
  onChange: PropTypes.func,
  numFractionalDigits: PropTypes.number,
  numIntegralDigits: PropTypes.number,
  controlType: PropTypes.oneOf([dollarNumberType, percentNumberType, decimalNumberType]),
  strValue: PropTypes.string,
  style: PropTypes.object,
  fieldIndex: PropTypes.number
}

export const BoundDollarEntryField = forwardRef((props, ref) => {
  return (
    <BoundNumberEntryField
      {...props}
      ref={ref}
      controlType={dollarNumberType}
    />
  )
})
BoundDollarEntryField.defaultProps = {
  numFractionalDigits: 2
}

export const BoundPercentEntryField = forwardRef((props, ref) => {
  return (
    <BoundNumberEntryField
      {...props}
      ref={ref}
      controlType={percentNumberType}
    />
  )
})

BoundPercentEntryField.defaultProps = {
  numFractionalDigits: 2
}

export const BoundDecimalEntryField = forwardRef((props, ref) => {
  return (
    <BoundNumberEntryField
      {...props}
      ref={ref}
      controlType={decimalNumberType}
    />
  )
})

export const BoundIntegerEntryField = forwardRef((props, ref) => {
  return (
    <BoundNumberEntryField
      {...props}
      ref={ref}
      numFractionalDigits={0}
      controlType={decimalNumberType}
    />
  )
})