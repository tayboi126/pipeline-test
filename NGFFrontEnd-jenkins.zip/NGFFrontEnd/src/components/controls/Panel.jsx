import React from 'react'
import { YDivider } from 'pwlib/styles'
import PropTypes from 'prop-types'
import styled from 'styled-components'

const PanelContainer = styled.div`
  background-color: ${props => props.theme.palette.panelBackground};
  width: 100%;
  padding: 10px 10px 10px 10px;
  border-radius: 5px;
  position: relative;
`

const PanelTitle = styled.div`
  font-size: 14px;
  position: absolute;
  top: -5px;
  margin-left: 6px;
  background-color: ${props => props.theme.palette.background.default};
  padding: 0px 10px;
  line-height: 12px;
`

const Panel = props => {
  return (
    <PanelContainer>
      {props.title && <PanelTitle>
        {props.title}
      </PanelTitle>
      }
      {props.children}
    </PanelContainer>
  )
}

Panel.propTypes = {
  title: PropTypes.node,
  children: PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.node),
    PropTypes.node
  ]).isRequired,
}

export default Panel

export const PanelDivider = () =>
  <YDivider height='20px' />