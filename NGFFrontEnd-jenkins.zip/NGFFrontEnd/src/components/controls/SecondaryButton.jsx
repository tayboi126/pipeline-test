import React from 'react'
import { ContainedButton, SecondaryButton as LibrarySecondaryButton } from 'pwlib/components/controls'
import { useTheme } from 'pwlib/styles'

import { grayDarkTheme, grayLightTheme } from '../../themes'

const SecondaryButton = props => {
  const theme = useTheme()

  if (theme.palette.internalType === grayDarkTheme || theme.palette.internalType === grayLightTheme) {
    return <ContainedButton {...props} color='secondary' />
  }

  return <LibrarySecondaryButton {...props} />
}

export default SecondaryButton