import React, { useRef, forwardRef } from 'react'
import { useConstructor } from 'pwlib/hooks'
import PropTypes from 'prop-types'
import cloneDeep from 'clone-deep'
import styled from 'styled-components'
import { ScrollableBlock } from 'pwlib/styles'
import { arrayFillObj } from '../../common/functions'

const Table = styled.table`
  border-Collapse: separate;
  border-spacing: 0px;
`

const THead = styled.thead`
  position: sticky;
  top: 0;
  z-index: 20;
`

/*
  If using sticky you must specify a column width in the tableHeaders styles for those sticky columns. 
  Also the table sticky header columns must specify a background color as with the td.
*/
const GeneralInputTable = forwardRef((props, ref) => {
  const tableContainerStyles = useRef(props.tableContainerStyles)
  const tableHeaders = useRef([])
  const tableRows = useRef([])

  useConstructor(() => {
    const numDataColumns = props.rows[0].length
    let thStyles
    if (!props.columnHeaderComponents) {
      if (!props.thStyles) {
        thStyles = new Array(props.columnHeaders.length)
        arrayFillObj(thStyles, {})
      } else {
        thStyles = cloneDeep(props.thStyles)
      }
    } else if (props.thStyles) {
      thStyles = cloneDeep(props.thStyles)
    }

    let tdStyles
    if (!props.tdStyles) {
      tdStyles = new Array(numDataColumns)
      arrayFillObj(tdStyles, {})
    } else {
      tdStyles = cloneDeep(props.tdStyles)
    }

    let cellStyles
    if (!props.cellStyles) {
      cellStyles = new Array(numDataColumns)
      arrayFillObj(cellStyles, {})
    } else if (!Array.isArray(props.cellStyles)) {
      cellStyles = new Array(numDataColumns)
      arrayFillObj(cellStyles, props.cellStyles)
    } else {
      cellStyles = props.cellStyles
    }

    let footerTdStyles
    if (!props.footerTdStyles) {
      footerTdStyles = new Array(numDataColumns)
      arrayFillObj(footerTdStyles, {})
    } else if (!Array.isArray(props.footerTdStyles)) {
      footerTdStyles = new Array(numDataColumns)
      arrayFillObj(footerTdStyles, props.footerTdStyles)
    } else {
      footerTdStyles = props.footerTdStyles
    }

    let numStickyInitialColumns = 0
    if (props.numStickyInitialColumns !== undefined) {
      numStickyInitialColumns = props.numStickyInitialColumns
    }
    let numStickyEndColumns = 0
    if (props.numStickyEndColumns !== undefined) {
      numStickyEndColumns = props.numStickyEndColumns
    }
  
    let currentInitialPosition = 0
    let currentEndPosition = 0
    if (thStyles) {
      for (let i = thStyles.length - props.numStickyEndColumns + 1; i < thStyles.length; ++i) {
        if (i > thStyles.length - props.numStickyEndColumns) {
          currentEndPosition += parseInt(thStyles[i].width)
        }
      }

      for (let index = 0; index < props.thStyles.length; ++index) {
        const th = thStyles[index]
        if (index < numStickyInitialColumns) {
          th.minWidth = th.width
          th.maxWidth = th.width
          th.position = 'sticky'
          th.left = `${currentInitialPosition}px`
          currentInitialPosition += parseInt(th.width)
        } else if ((index >= props.thStyles.length - numStickyEndColumns) && (index < props.thStyles.length)) {
          th.minWidth = th.width
          th.maxWidth = th.width
          th.position = 'sticky'
          th.right = `${currentEndPosition}px`
          if (index < props.thStyles.length - 1) {
            currentEndPosition -= parseInt(thStyles[index + 1].width)
          }
        }
      }
    }

    currentInitialPosition = 0
    currentEndPosition = 0
    for (let i = tdStyles.length - props.numStickyEndColumns + 1; i < tdStyles.length; ++i) {
      if (i > tdStyles.length - props.numStickyEndColumns) {
        currentEndPosition += parseInt(tdStyles[i].width)
      }
    }

    for (let index = 0; index < numDataColumns; ++index) {
      tdStyles[index] = { ...tdStyles[index] }
      const td = tdStyles[index]
      if (index < numStickyInitialColumns) {
        td.minWidth = td.width
        td.maxWidth = td.width
        td.position = 'sticky'
        td.zIndex = 3
        td.left = `${currentInitialPosition}px`
        currentInitialPosition += parseInt(td.width)
      } else if ((index >= props.tdStyles.length - numStickyEndColumns) && (index < props.tdStyles.length)) {
        td.minWidth = td.width
        td.maxWidth = td.width
        td.position = 'sticky'
        td.right = `${currentEndPosition}px`
        if (index < props.tdStyles.length - 1) {
          currentEndPosition -= parseInt(tdStyles[index + 1].width)
        }
      }
    }

    if (props.columnHeaderComponents) {
      if (!thStyles) {
        tableHeaders.current = props.columnHeaderComponents
      } else {
        tableHeaders.current = props.columnHeaderComponents.map((e, index) =>
          <th key={index} style={thStyles[index]}>
            {e}
          </th>
        )
      }
    } else {
      tableHeaders.current = props.columnHeaders.map((e, index) =>
        <th key={index} style={thStyles[index]}>
          <div style={cellStyles[index]}>{e}</div>
        </th>
      )
    }

    tableRows.current = props.rows.map((arrColumns, index) => {
      const row = []
      for (let j = 0; j < arrColumns.length; ++j) {
        row.push(
          <td key={j} style={{ backgroundColor: tableContainerStyles.current?.backgroundColor, ...tdStyles[j] }}><div style={cellStyles[j]}>{arrColumns[j]}</div></td>
        )
      }
      return <tr className='generalTableRow' key={index}>{row}</tr>
    })

    if (props.footerRow) {
      const row = []
      for (let j = 0; j < props.footerRow.length; ++j) {
        const tdStyle = { backgroundColor: tableContainerStyles.current?.backgroundColor, ...tdStyles[j], ...footerTdStyles[j] }
        row.push(
          <td key={j} style={tdStyle}><div style={cellStyles[j]}>{props.footerRow[j]}</div></td>
        )
      }
      tableRows.current.push(<tr id='generalTableFooterRow' key={tableRows.current.length} style={{ position: 'sticky', bottom: 0, backgroundColor: tableContainerStyles.current?.backgroundColor }}>{row}</tr>)
    }
  })

  return (
    <ScrollableBlock id='GeneralInputTable' style={tableContainerStyles.current} ref={ref}>
      <Table>
        <THead>
          <tr>
            {tableHeaders.current}
          </tr>
        </THead>
        <tbody>
          {tableRows.current}
        </tbody>
      </Table>
    </ScrollableBlock>
  )
})

GeneralInputTable.propTypes = {
  tableContainerStyles: PropTypes.object,
  columnHeaders: PropTypes.array,
  columnHeaderComponents: PropTypes.array,
  tdStyles: PropTypes.array,
  thStyles: PropTypes.array,
  cellStyles: PropTypes.oneOfType([
    PropTypes.array,
    PropTypes.object
  ]),
  numStickyInitialColumns: PropTypes.number,
  numStickyEndColumns: PropTypes.number,
  rows: PropTypes.arrayOf(PropTypes.array),
  footerRow: PropTypes.array,
  footerTdStyles: PropTypes.oneOfType([
    PropTypes.array,
    PropTypes.object
  ]),
}

export default GeneralInputTable