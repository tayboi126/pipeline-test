import React, { forwardRef, useRef } from 'react'
import PropTypes from 'prop-types'
import styled from 'styled-components'
import { ExpandingContainer, useTheme } from 'pwlib/styles'
import { FastInputTable } from 'pwlib/components/controls'
import { useFormHandler } from 'pwlib/hooks'

import { PageContainer } from '../common'

const GeneralListDisplayPageContainer = styled.div`
  width: 100%;
  height: 100%;
`

const GeneralListDisplayPage = forwardRef((props, ref) => {
  const theme = useTheme()
  const refStyle = useRef({ backgroundColor: theme.palette.panelBackground })
  const { arrRefs, isLoaded, rows } = useFormHandler({ 
    service: props.getService,
    rowFieldTemplates: props.rowFieldTemplates, 
    rowComponents: props.rowComponents, 
    boundControls: props.boundControls
  })

  if (!isLoaded) {
    return <></>
  }

  return (
    <GeneralListDisplayPageContainer>
      <PageContainer>
        {props.topPart}
        <ExpandingContainer>
          <FastInputTable tableStyle={refStyle.current} tableHeaderCellStyle={refStyle.current} ref={ref} arrRefs={arrRefs} rows={rows} columns={props.columns} defaultSortIndex={props.defaultSortIndex} isStriped={props.isStriped} />
        </ExpandingContainer>
      </PageContainer>
    </GeneralListDisplayPageContainer>
  )
})

GeneralListDisplayPage.propTypes = {
  rowFieldTemplates: PropTypes.array,
  rowComponents: PropTypes.array,
  columns: PropTypes.array,
  getService: PropTypes.func,
  boundControls: PropTypes.bool,
  topPart: PropTypes.node,
  defaultSortIndex: PropTypes.number,
  isStriped: PropTypes.bool,
}

GeneralListDisplayPage.defaultProps = {
  boundControls: true
}

export default GeneralListDisplayPage
