import React, { useRef, useEffect, useImperativeHandle, forwardRef } from 'react'
import PropTypes from 'prop-types'
import { FeedbackButton } from 'pwlib/components/formcontrols'
import { useMergeState } from 'pwlib/hooks'

import { saveStepCompleted, getStepCompleted } from '../../services/steps'

const StepCompletedButton = forwardRef((props, ref) => {
  const refFeedbackButton = useRef()
  const [state, setState] = useMergeState({
    isCompleted: false
  })

  const handleClick = async () => {
    await saveStepCompleted(props.step, !state.isCompleted)
    refFeedbackButton.current.feedbackOff()
    setState({ isCompleted: !state.isCompleted })
  }

  useEffect(() => {
    const doLoad = async () => {
      const isCompleted = await getStepCompleted(props.step)
      setState({ isCompleted })
    }
    doLoad()
  }, [])

  useImperativeHandle(ref, () => ({
    markAsNotComplete: () => setState({ isCompleted: false })
  }), [])

  return (
    <FeedbackButton disabled={props.disabled} ref={refFeedbackButton} onClick={handleClick}>
      {state.isCompleted ? 'Mark As Not Completed' : 'Mark As Completed' }
    </FeedbackButton>
  )
})

StepCompletedButton.propTypes = {
  step: PropTypes.number,
  disabled: PropTypes.bool,
}

export default StepCompletedButton
