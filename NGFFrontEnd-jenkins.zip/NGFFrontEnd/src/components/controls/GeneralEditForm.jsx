import React, { useEffect, useRef } from 'react'
import { ScrollableBlock, ExpandingContainer } from 'pwlib/styles'
import PropTypes from 'prop-types'

import { PageContainer } from '../common'
import { useFormHandler } from 'pwlib/hooks'
import { LocalToast } from 'pwlib/containers'

// This has an edit feature. So, a getService must be defined to retrieve the data from the server.
const GeneralEditForm = props => {
  const refLocalToast = useRef(null)
  const refButtons = useRef()
  const refModifiedFields = useRef()
  const refArrRefs = useRef([])
  const modified = useRef(false)

  const formIsModified = () => {
    const modifiedFields = refModifiedFields.current
    for (let i = 0; i < modifiedFields.length; ++i) {
      if (modifiedFields[i]) {
        return true
      }
    }
    return false
  }

  // Efficiently decides whether the form is modified given some field is modified on the form and then will generally turn on the save button
  // if modified and turn it off it not.
  const handleFieldModified = (_value, _fieldKey, fieldIndex, fieldIsModified) => {
    refModifiedFields.current[fieldIndex] = fieldIsModified
    if ((fieldIsModified && modified.current) || (!fieldIsModified && !modified.current)) {
      return
    }
    if (fieldIsModified && !modified.current) {
      modified.current = true
      refButtons.current.setDisabled(false)
      return
    }
    modified.current = formIsModified()
    refButtons.current.setDisabled(!modified.current)
  }

  // This sets up the logic for the app to conclude whether fields were changed on a cancel.
  const onChange = (value, fieldKey, fieldIndex) => {
    if (!refButtons.current || !refButtons.current.setDisabled) {
      throw new Error('You must define an useImperativeHandle inside your form buttons component with a setDisabled function.')
    }
    // ???? Why is it the case that a number field onchange auto concludes that the field is modified meaning different from its start value
    // whenever a change is made by the user. Maybe the user changed it to its original value read from the backend.
    let fieldIsModified
    if (refArrRefs.current[fieldIndex].current.isNumberField) {
      fieldIsModified = true
    } else {
      fieldIsModified = refArrRefs.current[fieldIndex].current.isModified()
    }
    handleFieldModified(value, fieldKey, fieldIndex, fieldIsModified)
  }

  const onBlur = (value, fieldKey, fieldIndex) => {
    if (!refArrRefs.current[fieldIndex].current.isNumberField) {
      return
    }
    handleFieldModified(value, fieldKey, fieldIndex, refArrRefs.current[fieldIndex].current.isModified())
  }

  const { arrRefs, formProps, data, isLoaded, formReset, formResetOnPostComplete } = useFormHandler({ 
    formTemplate: props.formTemplate, 
    service: props.getService,
    onChange,
    onBlur,
    boundControls: true,
    isFormReset: props.isFormReset,
    noFieldDifference: props.noFieldDifference
  })

  useEffect(() => {
    if (isLoaded) {
      refArrRefs.current = arrRefs
      refModifiedFields.current = new Array(arrRefs.length).fill(false)
    }
  }, [isLoaded])
  
  const onCancel = () => {
    return true
  }

  const postService = async postObject => {
    const result = await props.postService(postObject)
    if (!result) {
      return
    }
    modified.current = false
    refModifiedFields.current = new Array(arrRefs.length).fill(false)
    refButtons.current && refButtons.current.setDisabled && refButtons.current.setDisabled(true)
    refLocalToast.current?.successToastOn({ message: props.saveMessage, title: props.saveMessageTitle })
  }

  if (!isLoaded) {
    return <></>
  }

  return (
    <PageContainer id='GeneralEditForm'>
      <LocalToast ref={refLocalToast} />
      {props.topPart && props.topPart}
      <ExpandingContainer>
        <ScrollableBlock>
          <props.formBody formProps={formProps} data={data} />
        </ScrollableBlock>
      </ExpandingContainer>
      {props.buttons && <props.buttons ref={refButtons} arrRefs={arrRefs} formTemplate={props.formTemplate} onCancel={onCancel} postService={postService} boundControls data={data} formReset={formReset} formResetOnPostComplete={formResetOnPostComplete}/>}
    </PageContainer>
  )
}

GeneralEditForm.propTypes = {
  postService: PropTypes.func,
  topPart: PropTypes.node,
  isFormReset: PropTypes.bool,
  formTemplate: PropTypes.array,
  getService: PropTypes.func, 
  saveMessageTitle: PropTypes.string,
  saveMessage: PropTypes.string,
  buttons: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.object
  ]),
  noFieldDifference: PropTypes.bool,
}

GeneralEditForm.defaultProps = {
  noFieldDifference: false,
}

export default GeneralEditForm