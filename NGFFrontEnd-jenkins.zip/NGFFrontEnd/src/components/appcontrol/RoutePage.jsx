import React from 'react'
import styled from 'styled-components'
import PropTypes from 'prop-types'
import { useSelector } from 'react-redux'
import { useTheme } from 'pwlib/styles'
import { formStatusSelector, formStatusError } from 'pwlib/redux'
import { Label } from 'pwlib/components/controls'

import { subRouteTitleHeight, mimimumPageWidth } from '../../common/constants'
import useBasicAppHeightOverhead from '../../hooks/useBasicAppHeightOverhead'

const buttonsWrapperHeight = '60px'

export const RoutePagePanel = styled.div`
  background-color: ${props => props.theme?.palette?.panelBackground};
` 

export const RoutePagePanelGrow = styled(RoutePagePanel)`
  flex-grow: 1;
` 

export const ButtonsWrapper = styled.div`
  width: 100%;
  height: ${buttonsWrapperHeight};
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`
const ButtonsContainer = props =>
  <ButtonsWrapper style={{ justifyContent: props.rightButtons ? 'flex-end' : 'center' }}>
    {props.children}
  </ButtonsWrapper>

ButtonsContainer.propTypes = {
  children: PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.node),
    PropTypes.node
  ]).isRequired,
  rightButtons: PropTypes.bool,
}

export const SubRoutePageContainer = styled.div`
  height: 100%;
  display: flex;
  flex-direction: column;
  background-color: ${props => props.theme?.palette?.routePageBackground};
  min-width: ${mimimumPageWidth};
`

const SubRoutePageWrapper = styled.div`
  position: relative;
  width: 100%;
  min-height: 100%;
  flex-grow: 1;
  display: flex;
  flex-direction: column;
`

const SubRouteTitle = styled.div`
  line-height: 16px;
  font-size: 18px;
  height: ${subRouteTitleHeight};
  min-height: ${subRouteTitleHeight};
  display: flex;
  align-items: center;
  padding: 0px 20px;
`

const ChildrenContainer = styled.div`
  flex-grow: 1;
  background-color: ${props => props.theme.palette.routePageBackground};
`

const ValidationMessageContainer = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 12px;
  font-size: 12px;
  color: ${props => props.theme.palette.error.light};
  margin-bottom: -6px;
`

export const SubRoutePage = props => {
  const theme = useTheme()
  const formStatus = useSelector(formStatusSelector)
  const basicHeight = useBasicAppHeightOverhead()
  let routeWindowHeightOverhead = basicHeight + parseInt(subRouteTitleHeight)
  if (props.buttons) {
    routeWindowHeightOverhead += parseInt(buttonsWrapperHeight)
  }

  return (
    <SubRoutePageWrapper id='SubRoutePageWrapper' theme={theme}>
      <SubRouteTitle id='SubRouteTitle' data-testid='SubRouteTitle' theme={theme}>
        {props.title}
      </SubRouteTitle>
      <ChildrenContainer id='ChildrenContainer' theme={theme} style={{ height: `calc(100vh - ${routeWindowHeightOverhead}px)` }} >
        {props.children}
      </ChildrenContainer>
      {props.buttons && formStatus === formStatusError &&
        <ValidationMessageContainer style={{ justifyContent: props.rightButtons ? 'flex-end' : 'center' }} theme={theme}>
          <Label>
            Form validation error.
          </Label>
        </ValidationMessageContainer>
      }
      { props.buttons && 
        <ButtonsContainer rightButtons={props.rightButtons}>
          {props.buttons}
        </ButtonsContainer>
      }
    </SubRoutePageWrapper>
  )
}

SubRoutePage.propTypes = {
  children: PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.node),
    PropTypes.node
  ]).isRequired,
  title: PropTypes.string,
  buttons: PropTypes.node,
  // Align the buttons to the right. The default is to center them.
  rightButtons: PropTypes.bool,
}

export const MainRoutePage = props => {
  const theme = useTheme()
  const { buttons, rightButtons, mainTitle, style } = props
  return (
    <SubRoutePageContainer theme={theme} style={style}>
      <SubRoutePage buttons={buttons} rightButtons={rightButtons} title={mainTitle}>
        {props.children}
      </SubRoutePage>
    </SubRoutePageContainer>
  )
}

MainRoutePage.propTypes = {
  children: PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.node),
    PropTypes.node
  ]).isRequired,
  mainTitle: PropTypes.string,
  buttons: PropTypes.node,
  // Align the buttons to the right. The default is to center them.
  rightButtons: PropTypes.bool,
  style: PropTypes.object,
}

export const BasicRoutePage = props => {
  const theme = useTheme()
  return (
    <SubRoutePageContainer id='BasicRoutePage' theme={theme}>
      <SubRouteTitle theme={theme}>
        {props.mainTitle}
      </SubRouteTitle>
      {props.children}
    </SubRoutePageContainer>
  )
}

BasicRoutePage.propTypes = {
  children: PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.node),
    PropTypes.node
  ]).isRequired,
  mainTitle: PropTypes.string,
}
