import { configureLibrary, globalThemeOverrideObject, defaultTheme, themeChoices, reduxStore } from 'pwlib/configure'
import { getGlobalThemeOverrideObject, getDefaultTheme, getThemeChoices } from './themes'
import store from './redux/reduxstore'

export const configLibraryForApp = () => {
  configureLibrary({
    [globalThemeOverrideObject]: getGlobalThemeOverrideObject,
    [defaultTheme]: getDefaultTheme,
    [themeChoices]: getThemeChoices,
    [reduxStore]: store
  })
}