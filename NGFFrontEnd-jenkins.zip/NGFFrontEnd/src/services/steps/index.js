import { wait } from 'pwlib/common'
import { uiService, get } from 'pwlib/http'
import { iceStatusConversion, iceStatusInverseConversion, manualStatus } from '../../common/conversions'
import { getEacId, getSensitivity } from '../../redux/global'
import { getSpanasBookFactors, getSpanasCpFactors } from '../spanas'

// ????
export const saveStepCompleted = async (step, isCompleted) => {

}

// ????
export const getStepCompleted = async step => {
  return false
}

export const getStep7ListUrl = '/ngf-step7/get'
export const getStep3ListUrl = '/ngf-step3/get'

export const loadStep7 = async () => {
  const data = await get(`${getStep7ListUrl}?eacId=${getEacId()}&sensitivity=${getSensitivity()}`)

  // Convert Data
  for (let i = 0; i < data.length; ++i) {
    data[i].originalIceStatus = data[i].iceStatus 
    data[i].iceStatus = iceStatusConversion(data[i].iceStatus)
    // data[i].doNotIncludeSvCount = false
    // Ice manual should not have ice values in the forecast, they must be undefined.
    if (data[i].originalIceStatus === manualStatus) {
      const forecast = data[i].forecast
      for (let j = 0; j < forecast.length; ++j) {
        delete forecast[j].iceValue
      }
    }
  }

  return data
}

export const saveStep7 = async data => {
  // Convert Data
  for (let i = 0; i < data.length; ++i) {
    delete data[i].originalIceStatus
    data[i].iceStatus = iceStatusInverseConversion(data[i].iceStatus)
  }
  await uiService(async () => {
    await wait(1000)
    // eslint-disable-next-line no-console
    console.log(JSON.stringify(data, undefined, 2))
  })
}

export const loadSpanas = async () => {
  const results = await Promise.all([
    getSpanasBookFactors(),
    getSpanasCpFactors(),
  ])
  return { ...results[0], ...results[1] }
}

export const loadStep3 = async () => {
  const data = await get(`${getStep3ListUrl}?eacId=${getEacId()}&sensitivity=${getSensitivity()}`)
  console.log('loadStep3', JSON.stringify(data, undefined, 2))

  const results = await Promise.all([
    loadSpanas(),
    null
  ])
  console.log(JSON.stringify(results[0], undefined, 2))
  return results[0]
}

// ????
export const saveStep3 = async data => {
  await wait(1000)
  // eslint-disable-next-line no-console
  console.log(JSON.stringify(data, undefined, 2))
}

// ????
export const saveComments = async (step, comments) => {
  await wait(1000)
  // eslint-disable-next-line no-console
  console.log(JSON.stringify(comments, undefined, 2))
}