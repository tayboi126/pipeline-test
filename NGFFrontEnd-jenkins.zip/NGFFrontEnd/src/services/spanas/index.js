import { get } from 'pwlib/http'

import { getCegId, getSpanasYear, getSpanasMonth } from '../../redux/global'

export const getSpanasBookFactorsUrl = '/spanas/bookFactors'
export const getSpanasCpFactorsUrl = '/spanas/cpFactors'

const spanasParams = () => `?cegId=${getCegId()}&spanasYear=${getSpanasYear()}&spanasMonth=${getSpanasMonth()}`

export const getSpanasBookFactors = async () => {
  const result = await get(`${getSpanasBookFactorsUrl}${spanasParams()}`)
  return result
}

export const getSpanasCpFactors = async () => {
  const result = await get(`${getSpanasCpFactorsUrl}${spanasParams()}`)
  return result
}

const testing = 
{
  deferredRevenuePriorToForecastAmt: 5300236.46, 
  itdAccountingServiceOnwingCosAmt: 14294621.24, // cp005
  itdCsaUsedProfitShareCreditAmt: 0, // CP018
  itdGrossSpareClpAmt: 9416794.19, // CP008
  itdGrossSpareLlpAmt: 123950, // CP008A
  itdGrossServiceSalesAmt: 14294621.24, // (CP003 + CP004)
  itdNetServiceSalesAmt: 14294621.24, // CP003
  itdOnwingCosAmt: 10434785.61, // CP002
  itdProgramExpAmt: 0, // CP019
  itdPshrGrossSpareClpAdiscAmt: 0,
  itdPshrGrossSpareClpAmt: 0, // CP013
  itdPshrGrossServiceADiscAmt: 0,
  itdPshrSpareDiscAmt: 0, // CP014
  itdSpareEscDiscAmt: 701372, // CP011
  itdSpareFmpContractDiscAmt: 8010344.53, // CP010
  itdSpareFullReducedPmaUsedEscClpAmt: 8715422.19, // CP006
  itdSpareLlpEscDiscAmt: 8834.72, // CP011A
  itdSpareMfgCosAmt: 1487132.33,
  itdSparePmaUsedAntcpReductAmt: 0, // CP007
  itdSpareReducedPmaUsedClpAmt: 9416794.19,
  itdSpareTotalDiscAmt: 8711716.53, // CP009
  itdServiceCosAmt: 4045900.45, // CP012
  itdServiceOnwingCosAmt: 14480686.06, // CP001
  itdServiceSalewwsTotalDiscAmt: 0, // CP004
  itdTotalInvoiceRevenueAmt: 25646166.16,
  lmaGrossSpareClpAmt: 2940277.95,
  lmaSpareFmpContractDiscAmt: -2802122.03,
  lopCostSheetSgaAmt: 11931317.88,
  manualServiceCcuGrossSalesAmt: 0, // Manual Service Cum-Catchup Gross Sales
  manualServiceCcuNetSalesAmt: 0, // Manual Service Cum-Catchup Net Sales 
  previousContractDiscMethod: 'N',
  previousFmpContractDiscPct: 0.9191, // (CP010 / CP006)
  previousLopLossProvisionAmt: 141563620.39, // CP015
  previousLopServiceCosCAmt: 625690594.64,
  previousLopServiceCosDAmt: 625690594.64, // Service COS "D"
  previousLopServiceCosDGrossSpareClpAmt: 2619983013.71, // CP017
  previousLopTotalServiceSalesAdiscAmt: 625690594.64, // Total Service Sales after discount "A" 
  previousLopTotalServiceSalesBdiscAmt: 625690594.64, // Total Service Sales before discount "B"
  previousSparePmaUsedAntcpReductPct: 0, // Spare Parts PMA & Used Anticipated Reduction
  previousTotalWeightPctComplForLpLiqPct: 0.0091, // CP016
  modified: null
}


/*
CP018
CP020

private BigDecimal itdAccountingServiceOnwingCosAmt; cp005
private BigDecimal itdCsaUsedProfitShareCreditAmt;
private BigDecimal itdGrossSpareClpAmt; CP008
private BigDecimal itdGrossSpareLlpAmt; CP008A
private BigDecimal itdGrossServiceSalesAmt;
private BigDecimal itdNetServiceSalesAmt; CP003
private BigDecimal itdOnwingCosAmt; CP002
private BigDecimal itdProgramExpAmt; CP019
private BigDecimal itdPshrGrossSpareClpAdiscAmt;
private BigDecimal itdPshrGrossSpareClpAmt; CP013
private BigDecimal itdPshrGrossServiceADiscAmt;
private BigDecimal itdPshrSpareDiscAmt; CP014
private BigDecimal itdSpareEscDiscAmt; CP011
private BigDecimal itdSpareFmpContractDiscAmt; CP010
private BigDecimal itdSpareFullReducedPmaUsedEscClpAmt; CP006
private BigDecimal itdSpareLlpEscDiscAmt; CP011A
private BigDecimal itdSpareMfgCosAmt;
private BigDecimal itdSparePmaUsedAntcpReductAmt; CP007
private BigDecimal itdSpareReducedPmaUsedClpAmt;
private BigDecimal itdSpareTotalDiscAmt; CP009
private BigDecimal itdServiceCosAmt; CP012
private BigDecimal itdServiceOnwingCosAmt; CP001
private BigDecimal itdServiceSalewwsTotalDiscAmt; CP004
private BigDecimal itdTotalInvoiceRevenueAmt;
private BigDecimal lmaGrossSpareClpAmt;
private BigDecimal lmaSpareFmpContractDiscAmt;
private BigDecimal lopCostSheetSgaAmt;
private BigDecimal manualServiceCcuGrossSalesAmt;
private BigDecimal manualServiceCcuNetSalesAmt;
private String previousContractDiscMethod;
private BigDecimal previousFmpContractDiscPct; 
private BigDecimal previousLopLossProvisionAmt; CP015
private BigDecimal previousLopServiceCosCAmt;
private BigDecimal previousLopServiceCosDAmt; Service COS "D"
private BigDecimal previousLopServiceCosDGrossSpareClpAmt; CP017
private BigDecimal previousLopTotalServiceSalesAdiscAmt; Total Service Sales after discount "A" 
private BigDecimal previousLopTotalServiceSalesBdiscAmt; Total Service Sales before discount "B" 
private BigDecimal previousSparePmaUsedAntcpReductPct; Spare Parts PMA & Used Anticipated Reduction
private BigDecimal previousTotalWeightPctComplForLpLiqPct; CP016
*/