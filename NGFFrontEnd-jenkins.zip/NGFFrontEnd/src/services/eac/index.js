
// The backend returns null if no eac exists.
export const getEac = async (customer, engineFamilyDesc) => {
  return [
    // wip
    // { status: 2 }
    // F&B
    // { status: 0 }
  ]
}
  