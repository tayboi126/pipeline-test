import { get } from 'pwlib/http'
import { sqlDateTimeToLocalDateString } from 'pwlib/common'

import { twoDigitMonth, utcDateToMonthYear, boolToYesNo, isGtf } from '../../common/functions'
import { monthsNames } from '../../common/constants'

export const getAmcisCegListUrl = '/amcis/cegs'
export const getAmcisCegUrl = '/amcis/ceg'
export const getCegsListUrl = '/ngf-cegs/cegs'
export const getCegUrl = '/ngf-cegs/ceg'

const convertCeg = result => {
  result.inceptionMonth = monthsNames[result.inceptionMonth]
  result.endMonth = monthsNames[result.endMonth]
  result.closedOutMonth = monthsNames[result.closedOutMonth]
  result.speidCegStartDate = utcDateToMonthYear(result.speidCegStartDate)
  result.speidCegEndDate = utcDateToMonthYear(result.speidCegEndDate)
}

const mapAmcisToCeg = amcisData => {
  amcisData.isPartOfEngineCampaign = amcisData.doesPartnerShareInDiscount
  amcisData.isMmlForecastThisLevel = amcisData.isUsedInSpiritForecast
  amcisData.isMmlActgActualsThisLevel = amcisData.isUsedInSpiritActuals
  amcisData.speidCegStartDate = amcisData.dateEffective
  amcisData.speidCegEndDate = amcisData.dateEnd
  amcisData.updateTm = sqlDateTimeToLocalDateString(amcisData.updateTm)
  amcisData.isAmcis = true
}

export const getCeg = async (customer, engineGroupDesc) => {
  const result = await get(`${getCegUrl}?engineGroupDesc=${engineGroupDesc}&customer=${customer}`)
  console.log('getCeg', JSON.stringify(result, undefined, 2))
  convertCeg(result)
  // ????
  console.log('getCeg remove')
  

  result.cegVerified = true
  result.cegVerifiedDate = '01/01/2023'

  return result
}

export const getAmcisCeg = async (customer, engineGroupDesc) => {
  const result = await get(`${getAmcisCegUrl}?engineGroupDesc=${engineGroupDesc}&customer=${customer}`)
  console.log('getAmcisCeg', JSON.stringify(result, undefined, 2))
  mapAmcisToCeg(result)
  convertCeg(result)
  return result
}

// ????
export const saveCeg = async postObject => {
  console.log('saveCeg', JSON.stringify(postObject, undefined, 2))
}

// ????
export const deleteCeg = async engineGrpDesc => {
  console.log('deleteCeg', engineGrpDesc)
}

export const getCegList = async () => {
  const results = await Promise.all([
    get(getCegsListUrl),
    get(getAmcisCegListUrl),
  ])
  const map = {}
  // Put the ngf data into a map for efficiency.
  console.log('getCegList remove cegVerified')
  for (let i = 0; i < results[0].length; ++i) {
    const obj = results[0][i]
    // ???? remove
    obj.cegVerified = true
    obj.cegVerifiedDate = '01/01/2023'
    if (obj.contractId !== null) {
      map[obj.contractId] = obj
    }
  }

  // Map amcis fields to ngf fields.
  for (let i = 0; i < results[1].length; ++i) {
    const amcisData = results[1][i]
    // The amcis entry is not in ngf. Add the amcis entry.
    if (!map[amcisData.contractId]) {
      // amcis has different field names for some fields vs ngf. Map those fields.
      mapAmcisToCeg(amcisData)
      results[0].push(amcisData)
    } else {
      utcDateToMonthYear(amcisData.updateTm)
      // Put the amcis last update time in the NGF last update time column.
      map[amcisData.contractId].updateTm = sqlDateTimeToLocalDateString(amcisData.updateTm)
    }
  }

  // Restrict to gtf engines only.
  const result = results[0].filter(e => isGtf(e.engineFamilyDesc))
  result.sort((v1, v2) => {
    let value = v1.customerName.localeCompare(v2.customerName)
    if (value !== 0) {
      return value
    }
    value = v1.contractTypeShortDesc.localeCompare(v2.contractTypeShortDesc)
    if (value !== 0) {
      return value
    }
    return v1.engineGrpDesc.localeCompare(v2.engineGrpDesc)
  })

  // Map fields that are different from the http get vs the ceg list UI.
  for (let i = 0; i < result.length; ++i) {
    const row = result[i]
    row.inceptionDate = `${twoDigitMonth(row.inceptionMonth)}/${row.inceptionYear}`
    row.endDate = `${twoDigitMonth(row.endMonth)}/${row.endYear}`
    row.closedOutDate = `${twoDigitMonth(row.closedOutMonth)}/${row.closedOutYear}`
    row.doesPartnerShareInDiscount = boolToYesNo(row.doesPartnerShareInDiscount)
    row.doesPartnerShareInServiceSales = boolToYesNo(row.doesPartnerShareInServiceSales)
    row.isEacDiscCalcLevel = boolToYesNo(row.isEacDiscCalcLevel)
    row.isUsedInSpidrs = boolToYesNo(row.isUsedInSpidrs)
    row.cegVerified = boolToYesNo(row.cegVerified)
    row.isUsedInSpiritActuals = boolToYesNo(row.isUsedInSpiritActuals)
    row.isUsedInSpiritForecast = boolToYesNo(row.isUsedInSpiritForecast)

    row.costSheet = 'View'
  }

  return result
}