import React from 'react'
import { Routes, Route } from 'react-router-dom'
import styled from 'styled-components'
import useBasicAppHeightOverhead from '../hooks/useBasicAppHeightOverhead'

// import Dashboard from '../components/pages/dashboard'
import ControlsDemo from '../components/pages/ControlsDemo.jsx'
import FormEditDemo from '../components/pages/FormEditDemo.jsx'
import BoundFormEditDemo from '../components/pages/BoundFormEditDemo.jsx'
import ArrayFormEditDemo from '../components/pages/ArrayFormEditDemo.jsx'
import BoundTableEditDemo from '../components/pages/BoundTableEditDemo.jsx'
import TableEditDemo from '../components/pages/TableEditDemo.jsx'
import Step7 from '../components/pages/steps/step7'
import Step3 from '../components/pages/steps/step3'
import Contracts from '../components/pages/contracts'
import Ceg from '../components/pages/contracts/ceg'
import * as routePaths from './routePaths'

const RoutesContainer = styled.div`
`

export default () => {
  const basicHeight = useBasicAppHeightOverhead()
  return (
    <RoutesContainer id='routes' style={{ height: `calc(100vh - ${basicHeight}px)` }}>
      <Routes>
        <Route exact path={routePaths.root} element={<Step3 />} />
        <Route path={routePaths.controlsDemo} element={<ControlsDemo />} />
        <Route path={routePaths.formEditDemo} element={<FormEditDemo />} />
        <Route path={routePaths.boundFormEditDemo} element={<BoundFormEditDemo />} />
        <Route path={routePaths.arrayFormEditDemo} element={<ArrayFormEditDemo />} />
        <Route path={routePaths.boundTableEditDemo} element={<BoundTableEditDemo />} />
        <Route path={routePaths.tableEditDemo} element={<TableEditDemo />} />
        <Route path={routePaths.step7} element={<Step7 />} />
        <Route path={routePaths.step3} element={<Step3 />} />
        <Route path={routePaths.contracts} element={<Contracts />} />
        <Route path={routePaths.ceg} element={<Ceg />} />
      </Routes>
    </RoutesContainer>
  )
}