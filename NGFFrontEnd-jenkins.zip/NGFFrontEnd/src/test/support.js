/* eslint-disable react/prop-types */
import React from 'react'
import { initCache } from 'pwlib/common'
import { configLibraryForApp } from '../configLibraryForApp'
import { Provider } from 'react-redux'
import { ThemeWrapper } from 'pwlib/themes'
import { getConfigureOption, reduxStore } from 'pwlib/configure'
import { BrowserRouter as Router } from 'react-router-dom'
import { setEnv } from 'pwlib/http'

setEnv({})
configLibraryForApp()
initCache()

let useLocationObject = {}

export const mockGetUseLocationObject = () =>
  useLocationObject

export const setUseLocationObject = obj => {
  useLocationObject = obj
}

export const BasicTestWrapper = props => {
  return (
    <Provider store={getConfigureOption(reduxStore)}>
      <ThemeWrapper>
        <Router>
          {props.children}
        </Router>
      </ThemeWrapper>
    </Provider>
  )
}