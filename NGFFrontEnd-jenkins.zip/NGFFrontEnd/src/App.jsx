import React, { useEffect } from 'react'
import { Provider } from 'react-redux'
import store from './redux/reduxstore'
import { ThemeWrapper } from 'pwlib/themes'
import CoreApp from './components/CoreApp'
import { GlobalBusyCursor, InformationDialog, GeneralDialog, ScreenBlocker, Toast } from 'pwlib/containers'
import { initCache } from 'pwlib/common'
import { useTheme } from 'pwlib/styles'
import { configLibraryForApp } from './configLibraryForApp'
import { setGlobalTheme } from './redux/global'
import './index.css'
import '@fontsource/inter'

configLibraryForApp()
initCache()

const AppInternal = () => {
  const theme = useTheme()

  // This component should only render when the theme is changed or at program init.
  // So the below useEffect runs on every render so that the theme is correctly set globally in redux.
  // This allows business code to access the theme since business code that is not in a component cannot access useTheme. 
  useEffect(() => {
    setGlobalTheme(theme)
  })

  return (
    <>
      <GlobalBusyCursor />
      <Toast />
      <InformationDialog />
      <GeneralDialog />
      <CoreApp />
      <ScreenBlocker />
    </>
  )
}

/**
 * App sets up the CoreApp, redux store, global redux connected components and theming for the application.
 *
 * @returns {React.ReactElement} - React component
 */
const App = () =>
  <Provider store={store}>
    <ThemeWrapper>
      <AppInternal />
    </ThemeWrapper>
  </Provider>

export default App


