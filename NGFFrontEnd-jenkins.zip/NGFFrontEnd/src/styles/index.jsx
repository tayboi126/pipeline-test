import React from 'react'
import { XDivider } from 'pwlib/styles'

export const DividerForStepButtons = () =>
  <XDivider width='10px' />