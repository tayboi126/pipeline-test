/* eslint-disable no-console */
// jest-dom adds custom jest matchers for asserting on DOM nodes.
// allows you to do things like:
// expect(element).toHaveTextContent(/react/i)
// learn more: https://github.com/testing-library/jest-dom
import Enzyme from 'enzyme'
import Adapter from '@wojtekmaj/enzyme-adapter-react-17'
import { mockGetUseLocationObject } from './test/support'

Enzyme.configure({ adapter: new Adapter() })

const actualConsoleLog = console.log
const actualConsoleWarn = console.warn
const actualConsoleError = console.error

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useLocation: () => {
    return mockGetUseLocationObject()
  },
}))

console.log = (message, ...rest) => {
  if (typeof message === 'string' && message.startsWith('WARNING: No message string for %{')) {
    return
  }
  actualConsoleLog(message, ...rest)
}
console.warn = (message, ...rest) => {
  if (typeof message === 'string' && message.startsWith('No message string for %{')) {
    return
  }
  actualConsoleWarn(message, ...rest)
}
console.error = (message, ...rest) => {
  if (typeof message === 'string' && message.startsWith('Warning: ReactDOM.render is no longer supported in React 18.')) {
    return
  }
  actualConsoleError(message, ...rest)
}

