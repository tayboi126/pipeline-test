import deepMerge from 'deepmerge'
import { lightTheme, darkTheme } from 'pwlib/themes'

export const grayLightTheme = 'gray-light'
export const grayDarkTheme = 'gray-dark'
export const greenLightTheme = 'green-light'
export const greenDarkTheme = 'green-dark'
export const blueLightTheme = 'blue-light'
export const blueDarkTheme = 'blue-dark'

const rotorWhite = '#FFFFFF'
const rotorNeutral0 = '#F7F7F7'
const rotorNeutral100 = '#F0F0F0'
// const rotorNeutral200 = '#E3E5E8'
// const rotorNeutral300 = '#CFD1D7'
// const rotorNeutral400 = '#A5A9B4'
// const rotorNeutral500 = '#848A98'
const rotorNeutral600 = '#5B6376'
const rotorNeutral700 = '#3E485E'
const rotorNeutral800 = '#1F2A44'
const rotorNeutral900 = '#141B2C'
const rotorBlack = '#000000'

const darkBackground = rotorBlack
const lightBackground = rotorNeutral0

const darkTextPrimary = rotorWhite

const grayAccent = {
  palette: {
    primary: {
      main: rotorNeutral700,
      dark: rotorNeutral600,
      light: rotorNeutral800
    },
    secondary: {
      main: '#cfd1d7',
      dark: '#b3b6c0',
      light: '#dddee3'
    },
    tabSelected: rotorNeutral700,
    darkButtons: {
      main: '#eff1f4',
      hover: '#d8dde4'
    },
    lightButtons: {
      main: '#343c4f',
      hover: '#202530',
    }
  }
}

const baseOverride = {
  palette: {
    toast: {
      backgroundSuccess: '#EDF7ED',
      backgroundWarning: '#FFF4E5',
      backgroundError: '#FDEDED',
      backgroundInfo: '#E5F6FD',
      color: 'black',
    },
    text: {
      disabled: 'rgba(0, 0, 0, 0.58)',
      primary: 'rgba(0, 0, 0, 1.0)',
      secondary: 'rgba(0, 0, 0, 0.6)',
    }
  },
  typography: {
    toast: {
      fontSizeTitle: '14px',
      fontSizeMessage: '14px'
    },
    fontFamily: 'Inter',
    fontSize: 10.5
  },
  shape: {
    borderRadius: '4px'
  },
  components: {
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          /*
          '& $notchedOutline': {
            borderColor: 'green'
          },
          '&:hover $notchedOutline': {
            borderColor: 'red'
          },
          '&$focused $notchedOutline': {
            borderColor: 'purple'
          },
          */
        },
        input: {
          padding: '15px 14px'
        }
      }
    }
  }
}

const themeCommon = {
  palette: {
    // Required to be set
    panelBackground: rotorWhite,
    fieldDifferenceColor: 'orange',
    spanasTextFieldBackground: 'blue',
    panelDivider: rotorNeutral100,
    routePageBackground: rotorNeutral100,
    badgeBackgroundColor: 'red',
    tableRowHoverColor: 'rgb(0, 0, 0, 0.04)',
    tableRowSelectedColor: 'rgb(0, 0, 0, 0.09)',
    tableRowStripedColor: rotorNeutral100,
    tableRowBorderColor: rotorNeutral100,
    textFieldUnderlineColor: 'rgb(145, 145, 145)',
    textFieldHoverUnderlineColor: 'rgb(31, 31, 31)',
    specialButtonBackgroundColor: '#F2CD00',
    specialButtonHoverBackgroundColor: '#ffda0d',
    specialButtonTextColor: '#090D15',
    searchableListHighlight: '#E0E0E0',
    searchableListHover: '#EDEDED',
    scrollBarTrack: '#D0D0D0',
    showMoreLess: '#03A9F4',
    tableFilterOnColor: 'orange',
    linkColor: '#0000FF',
    switchOnColor: '#00e500',

    // Put new colors here
    formSectionTitleBackground: '#D0D0D0'

  }
}

// Override the MUI light theme object
const lightThemeOverride = {
  palette: {
    mode: lightTheme,
    type: lightTheme,
    background: {
      paper: lightBackground,
      default: lightBackground
    },
    action: {
      disabled: '#bbbbbb'
    },
  },
}

// Override the MUI dark theme object
const darkThemeOverride = {
  palette: {
    mode: darkTheme,
    type: darkTheme,
    background: {
      paper: darkBackground,
      default: darkBackground
    },
    text: {
      primary: darkTextPrimary,
      disabled: '#999999',
      secondary: darkTextPrimary,
    },
    action: {
      disabled: '#999999'
    },
    panelBackground: rotorNeutral900,
    routePageBackground: darkBackground,
    tableRowStripedColor: rotorNeutral800,
    spanasTextFieldBackground: rotorNeutral700,
    tableRowHoverColor: 'rgb(255, 255, 255, 0.07)',
    tableRowSelectedColor: 'rgb(255, 255, 255, 0.12)',
    tableRowBorderColor: 'rgb(255, 255, 255, 0.12)',
    textFieldUnderlineColor: 'rgb(188, 188, 188)',
    textFieldHoverUnderlineColor: 'white',
    panelDivider: rotorNeutral600,
    linkColor: '#00A9E0',
    formSectionTitleBackground: rotorNeutral700
  },
}

export const themeChoices = [
  {
    value: grayLightTheme,
    label: 'Light Theme',
    themeObject: lightThemeOverride,
    themeColors: grayAccent
  },
  {
    value: grayDarkTheme,
    label: 'Dark Theme',
    themeObject: darkThemeOverride,
    themeColors: grayAccent
  },
]

// This is used to set the app theme with MUI.
export const getGlobalThemeOverrideObject = strTheme => {
  const entry = themeChoices.find(e => e.value === strTheme)
  if (!entry) {
    throw new Error('Invalid theme.')
  }
  const themeInternal = { palette: { internalType: entry.value } }
  return deepMerge.all([baseOverride, themeCommon, entry.themeObject, entry.themeColors, themeInternal])
}

export const getDefaultTheme = () => grayDarkTheme

export const getThemeChoices = () => themeChoices
