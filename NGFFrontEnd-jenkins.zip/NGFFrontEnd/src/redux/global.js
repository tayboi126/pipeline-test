import { createReduxData, handleHMR } from 'pwlib/virtusa-redux'
import { openInformationDialog } from 'pwlib/containers'

const reducerKey = 'reduxGlobal'

const initialState = {
  globalTheme: { palette: {} },
  isDirty: false,
  // Remove later ????
  eacId: 5019,
  sensitivity: 'A',
  cegId: 250,
  spanasYear: 2021,
  spanasMonth: 4,
}

let { setState, getState, /* reducerState */ } = handleHMR(module, initialState)
/**
 * Callback for useConnect for the component. Sets of the redux machinery for the component.
 * 
 * @param {object} store - Redux store
 * @returns {void} Nothing
 */
export async function initReduxGlobal(store) {
  ({ setState, getState /* , reducerState */ } = createReduxData(store, reducerKey, initialState))
}

export const clearReduxGlobal = () => {
  setState(initialState)
}

export const setGlobalTheme = globalTheme =>
  setState({ globalTheme })

export const getGlobalTheme = () => 
  getState().globalTheme

export const setDirty = (isDirty, isDirtyMessage) => {
  setState({ isDirty, isDirtyMessage })
}
  
export const getDirty = () =>
  getState().isDirty
  
export const handleDirty = isDirtyMessage => {
  if (!getState().isDirty) {
    return false
  }
  openInformationDialog({ message: isDirtyMessage || getState().isDirtyMessage })
  return true
}

window.addEventListener('beforeunload', e => {
  if (!getState().isDirty) {
    return
  }
  const confirmationMessage = 'm';
  (e || window.event).returnValue = confirmationMessage
  return confirmationMessage
})

export const getEacId = () =>
  getState().eacId

export const setEacId = eacId =>
  setState({ eacId })

export const getSensitivity = () =>
  getState().sensitivity

export const setSensitivity = sensitivity =>
  setState({ sensitivity })

export const getCegId = () =>
  getState().cegId

export const setCegId = cegId =>
  setState({ cegId })

export const getSpanasYear = () =>
  getState().spanasYear

export const setSpanasYear = spanasYear =>
  setState({ spanasYear })

export const getSpanasMonth = () =>
  getState().spanasMonth

export const setSpanasMonth = spanasMonth =>
  setState({ spanasMonth })