import reducersObject from './Reducers'
import { configureStore } from 'pwlib/virtusa-redux'
import { initReduxGlobal } from './global'
import { initLibraryRedux } from 'pwlib/redux'

let store

// Keep the same redux store during a hot reload
if (module.hot) {
  if (typeof module.hot.data !== 'undefined' && typeof module.hot.data.store !== 'undefined') {
    store = module.hot.data.store
  }
  // Save the store into module.hot.data.store before unloading this module
  module.hot.dispose(() => {
    module.hot.data = { store }
  })
}

if (typeof store === 'undefined') {
  store = configureStore(reducersObject)
  initReduxGlobal(store)
  initLibraryRedux(store)
}

export default store

