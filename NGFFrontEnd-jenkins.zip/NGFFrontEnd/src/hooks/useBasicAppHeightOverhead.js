
export const basicAppHeightOverhead = () => {
  return 0
}

const useBasicAppHeightOverhead = () => {
  return basicAppHeightOverhead(0)
}

export default useBasicAppHeightOverhead