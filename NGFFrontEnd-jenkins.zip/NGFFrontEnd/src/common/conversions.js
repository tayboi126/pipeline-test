export const iceStatus = 1
export const manualStatus = 2
export const iceAdjStatus = 3

export const eacFAndBStatus = 0
export const eacFAndNotBStatus = 1
export const eacWipStatus = 2

const conversions = {
  iceStatus: {
    [iceStatus]: 'ICE',
    [manualStatus]: 'Manual',
    [iceAdjStatus]: 'ICE/Adj',
  },
  iceInverseStatus: {
    ICE: iceStatus,
    Manual: manualStatus,
    'ICE/Adj': iceAdjStatus,
  }
}

export const getConversions = () => {
  return conversions
}

export const iceStatusConversion = val => {
  const result = getConversions().iceStatus[val]
  if (result === undefined) {
    return 'ICE'
  }
  return result
}

export const iceStatusInverseConversion = str => 
  getConversions().iceInverseStatus[str]

