export const subRouteTitleHeight = '48px'
export const mimimumPageWidth = '1200px'
export const pageTitleFontSize = '22px' 

export const monthsNames = [
  '',
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
]

export const svTypeTar = 4

// useOnserver constants
export const reloadSpanas = 1
export const retrieveStepComments = 2