import { openInformationDialog } from 'pwlib/containers'
import { get } from 'pwlib/http'

// Check every 30 seconds
const timeOutCheck = 30 * 1000
const sessionTimeoutTitle = 'Your session has expired'
const sessionTimeoutMessage = 'Click the button below to create a new session.'
let messageOnScreen = false

const sessionCallBack = () => {
  window.location.reload()
  return false
}

const sessionTimeoutQuery = async () => {
  // Don't keep displaying the message if the session timeout happened.
  if (messageOnScreen) {
    return
  }

  // Call the backend.
  let isConnected = false
  try {
    const result = await get('/testSessionTimeout', false, false)
    isConnected = result
  } catch (ex) { }

  // If session timeout, display a message.
  if (!isConnected) {
    messageOnScreen = true
    openInformationDialog({ title: sessionTimeoutTitle, message: sessionTimeoutMessage, onOk: sessionCallBack })
  }
}

const startSessionTimeoutQuery = () =>
  setInterval(sessionTimeoutQuery, timeOutCheck)

export default startSessionTimeoutQuery
