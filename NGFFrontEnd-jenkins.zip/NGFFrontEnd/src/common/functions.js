import { successToast, errorToast } from 'pwlib/containers'
import { getEffectiveUrl } from 'pwlib/http'
import { downloadFile } from 'pwlib/common'

const gftString = 'PW1'

export const handleReportDownload = location => {
  if (location) {
    const url = getEffectiveUrl(location)
    const name = url.substr(url.lastIndexOf('/') + 1)
    downloadFile(url, name)
    successToast({ message: `Your report ${name} has been downloaded`, title: 'Report' })
    return name
  } else {
    errorToast({ message: 'The report generation failed.', title: 'Report Error' })
  }
}

export const arrayFillObj = (arr, obj) => {
  for (let i = 0; i < arr.length; ++i) {
    arr[i] = { ...obj }
  }
}

export const twoDigitMonth = mth =>
  mth >= 10 ? mth.toString() : `0${mth}`

export const utcDateToMonthYear = utcDate => {
  if (utcDate === null) {
    return ''
  }
  const dt = new Date(utcDate)
  return `${twoDigitMonth(dt.getMonth() + 1)}/${dt.getFullYear()}`
} 

export const boolToYesNo = value =>
  value ? 'Yes' : 'No'

export const isGtf = engineFamily => {
  if (!engineFamily) {
    return false
  }
  return engineFamily.toUpperCase().startsWith(gftString)
}
