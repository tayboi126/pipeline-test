const fs = require('fs')
const { execSync } = require('child_process')
const path = require('path')
const spawn = require('child_process').spawn
const spawnSync = require('child_process').spawnSync

const doArchive = true
const backendContainer = 'back-end'

const appPropertiesFile = 'application.properties'
const strAppVersion = 'app.version='
const jarfile = 'gate-one-tool.jar'
const updateDir = 'update'
const jarUpdatePath = path.join(updateDir, jarfile)
const azBaseUtl = 'https://stp7981q011.file.core.usgovcloudapi.net'
const sasKey = 'sv=2021-06-08&ss=bfqt&srt=sco&sp=rwdlacuptfx&se=2042-12-31T18:59:59Z&st=2022-07-01T17:47:07Z&spr=https&sig=ckP8Trhx3CUAno78NvW0I%2BTPCAMC09mKlQ5BHtgE9cU%3D'
const existsErrorMessage = 'specified resource does not exist.'
const backEndUpdateExistsFile = 'gate-one-tool.jar'
const lockfile = 'lockfile'
const archiveDirectory = 'archive'

const trace = true

const sleepTime = 300

let serverProcess

const log = strMessage => {
  if (trace) {
    console.log(`${(new Date()).toString()}: ${strMessage}`)
  }
}

const fileExists = (container, filename) => {
  const url = `${azBaseUtl}/${container}/${filename}?${sasKey}`
  const serverProcess = spawnSync('azcopy', ['list', url])
  const result = serverProcess.stdout.toString()
  return result.indexOf(existsErrorMessage) === -1
}

const backEndUpdateExists = () => {
  if (fileExists(backendContainer, lockfile)) {
    return false
  }
  return fileExists(backendContainer, backEndUpdateExistsFile)
}

const sleep = sec => {
  return new Promise((resolve) => {
    setTimeout(resolve, sec * 1000)
  })
}

const changeAppVersion = () => {
  let data = fs.readFileSync(appPropertiesFile)
  data = data.toString()
  let index = data.indexOf(strAppVersion)
  const startIndex = index
  index += strAppVersion.length
  let newVersion = strAppVersion
  while (isDigit(data.charAt(index))) {
    newVersion += data.charAt(index)
    ++index
  }
  newVersion += data.charAt(index)
  ++index
  while (isDigit(data.charAt(index))) {
    newVersion += data.charAt(index)
    ++index
  }
  newVersion += data.charAt(index)
  ++index
  let versionNumber = ''
  while (isDigit(data.charAt(index))) {
    versionNumber += data.charAt(index)
    ++index
  }
  const oldVersion = data.substring(startIndex, index)
  newVersion += (parseInt(versionNumber) + 1).toString()
  data = data.replace(oldVersion, newVersion)
  fs.writeFileSync(appPropertiesFile, data)
}

// Runs after the server has been terminated.
const serverKillCallback = async () => {
  if (trace) {
    log('Server terminated, loading update...')
  }
  try {
    // Archive
    if (doArchive) {
      const dt = new Date()
      const archivePath = path.join(archiveDirectory, `${jarfile}-(${dt.getFullYear()}-${dt.getMonth() + 1}-${dt.getDate()})(${dt.getHours()}-${dt.getMinutes()})`)
      if (trace) {
        console.log(`Copy archive ${jarUpdatePath} -> ${archivePath}`)
      }
      fs.copyFileSync(jarUpdatePath, archivePath)
    }

    // Copy the update to the runnable jar file
    if (trace) {
      console.log(`Copy update ${jarUpdatePath} -> ${jarfile}`)
    }
    fs.copyFileSync(jarUpdatePath, jarfile)
    // Delete the update.
    fs.unlinkSync(jarUpdatePath)
    changeAppVersion()
  } catch (ex) {
    if (trace) {
      console.log('ex', ex)
    }
  }
  startServer()
}

const killServer = () => {
  if (trace) {
    log('killServer')
  }
  serverProcess.kill()
}

const startServer = () => {
  if (trace) {
    log(`Start Server sleepTime=${sleepTime}.`)
  }
  try {
    serverProcess = spawn('java', ['-jar', `-Dspring.config.location=${appPropertiesFile}`, jarfile], {
      detached: true,
    })
  } catch (ex) {
    if (trace) {
      console.log(ex)
    }
  }
  if (trace) {
    log(`serverProcess pid=${serverProcess.pid}`)
  }
  serverProcess.on('close', code => {
    if (trace) {
      log(`child process exited code=${code}`)
    }
    serverKillCallback()
  })
}

const copyFilesFromAz = (container, destDir) => {
  const url = `${azBaseUtl}/${container}/*?${sasKey}`
  const execString = `azcopy cp "${url}" "${destDir}" --recursive`
  execSync(execString)
}

const removeFileFromAz = (container, filename) => {
  const url = `${azBaseUtl}/${container}/*?${sasKey}`
  const execString = `azcopy rm "${url}" --recursive`
  execSync(execString)
}

const newVersionAvailable = () => {
  if (!backEndUpdateExists()) {
    return false
  }

  if (trace) {
    log('Update available in az.')
  }

  if (trace) {
    log('Generate lock file.')
  }
  
  // Create the lockfile
  execSync(`echo "1">${path.join(updateDir, lockfile)}`)

  if (trace) {
    log('Copy files from az start.')
  }
  copyFilesFromAz(backendContainer, 'update')

  if (trace) {
    log('Copy files from az done.')
  }

  if (trace) {
    log('Delete update files from az.')
  }
  removeFileFromAz(backendContainer, backEndUpdateExistsFile)

  // Remove the lockfile.
  if (trace) {
    log('Delete the lockfile.')
  }
  execSync(`del ${path.join(updateDir, lockfile)}`)

  if (!fs.existsSync(jarUpdatePath)) {
    return false
  }
  return true
}

const isDigit = ch => {
  return ch >= '0' && ch <= '9'
}

const handleAppDateTimeChange = () => {
  if (newVersionAvailable()) {
    // This will kill the current server and then restart it.
    killServer()
  }
}

// This will monitor a change to the app jar file.
const runProgram = async () => {
  while (true) {
    await sleep(sleepTime)
    handleAppDateTimeChange()
  }
}

// Initial start of server.
startServer()

// Run the git monitoring program.
runProgram()
