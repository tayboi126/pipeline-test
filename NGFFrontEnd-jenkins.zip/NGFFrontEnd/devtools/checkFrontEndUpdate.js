const spawnSync = require('child_process').spawnSync
const execSync = require('child_process').execSync
const path = require('path')

const doArchive = true
const frontendContainer = 'front-end'

const azBaseUtl = 'https://stp7981q011.file.core.usgovcloudapi.net'
const sasKey = 'sv=2021-06-08&ss=bfqt&srt=sco&sp=rwdlacuptfx&se=2042-12-31T18:59:59Z&st=2022-07-01T17:47:07Z&spr=https&sig=ckP8Trhx3CUAno78NvW0I%2BTPCAMC09mKlQ5BHtgE9cU%3D'
const existsErrorMessage = 'does not exist.'
const frontEndUpdateExistsFile = 'index.html' 
const buildDir = 'build'
const archiveDirectory = 'archive'

const trace = true

const sleepTime = 300

const sleep = sec => {
  return new Promise((resolve) => {
    setTimeout(resolve, sec * 1000)
  })
}

const log = strMessage => {
  if (trace) {
    console.log(`${(new Date()).toString()}: ${strMessage}`)
  }
}

const fileExists = (container, filename) => {
  const url = `${azBaseUtl}/${container}/${buildDir}/${filename}?${sasKey}`
  const serverProcess = spawnSync('azcopy', ['list', url])
  const result = serverProcess.stdout.toString()
  return result.indexOf(existsErrorMessage) === -1
}
  
const copyFilesFromAz = (container, destDir) => {
  const url = `${azBaseUtl}/${container}/build/*?${sasKey}`
  const execString = `azcopy cp "${url}" "${destDir}" --recursive`
  try {
    execSync(execString)
  } catch (ex) {
    console.log('copyFilesFromAz exception ', ex)
    console.log('copyFilesFromAz exception ', ex.stdout.toString())
    throw new Error('copyFilesFromAz exception')
  }
}

const removeFilesFromAz = container => {
  const url = `${azBaseUtl}/${container}/*?${sasKey}`
  const execString = `azcopy rm "${url}" --recursive`
  execSync(execString)
}

const frontEndUpdateExists = () => {
  return fileExists(frontendContainer, frontEndUpdateExistsFile)
}

const handleAppDateTimeChange = () => {
  if (!frontEndUpdateExists()) {
    return
  }

  if (trace) {
    log('Performing update.')
  }

  if (trace) {
    log('Delete index.html.')
  }
  execSync('del /q "index.html"')

  if (trace) {
    log('Delete static.')
  }
  execSync('del /q /s "static"')

  if (trace) {
    log('Copy files from az.')
  }

  // Archive
  const dt = new Date()
  const destDir = `${buildDir}-(${dt.getFullYear()}-${dt.getMonth() + 1}-${dt.getDate()})(${dt.getHours()}-${dt.getMinutes()})`
  const filePath = path.join(archiveDirectory, destDir)
  try {
    if (doArchive) {
      if (trace) {
        console.log(`Copy from az to archive ${filePath}`)
      }
      copyFilesFromAz(frontendContainer, filePath)
    }

    // Update
    // Copy the update to the front end directory
    copyFilesFromAz(frontendContainer, '.')

    if (trace) {
      log('Remove files from az.')
    }
    removeFilesFromAz(frontendContainer)
  } catch (ex) {
    if (trace) {
      log('Exception', ex)
    }
  }
}

// This will monitor a change to the app jar file.
const runProgram = async () => {
  while (true) {
    await sleep(sleepTime)
    handleAppDateTimeChange()
  }
}
  
// Run the git monitoring program.
runProgram()