const exec = require('child_process').exec
const util = require('node:util')

const sleepTime = 60
const serverRunString = 'mvnw spring-boot:run -Dspring.config.location=application.properties'

const gitNoWorkMessage = 'Already up to date.'
let serverProcess

const sleep = sec => {
  return new Promise((resolve) => {
    setTimeout(resolve, sec * 1000)
  })
}

const execute = (command, outputCallback, killCallback) => {
  const proc = exec(command, (error, stdout, stderr) => { 
    if (error) {
      // eslint-disable-next-line no-console
      console.log(`error: ${error}`)
      killCallback && killCallback()
      return
    }
    outputCallback && outputCallback(stdout) 
  })
  return proc
}

// Runs after the server has been terminated.
const serverKillCallback = async () => {
  console.log('Server terminated.')
  // Do build of the jar file.
  const pExec = util.promisify(exec)
  await pExec('build.bat')
  startServer()
}

const startServer = () => {
  console.log('Start Server.')
  serverProcess = execute(serverRunString, undefined, serverKillCallback)
}

// This executes with the output of the git command.
const gitCallback = data => {
  if (!data.includes(gitNoWorkMessage)) {
    console.log('Have git changes, kill server')
    serverProcess.kill()
  } else {
    console.log('Git no changes.')
  }
}

const runGit = () => {
  console.log('Run Git.')
  const proc = execute('git pull', gitCallback)
  return proc
}

const runProgram = async () => {
  while (true) {
    runGit()
    await sleep(sleepTime)
  }
}

// Initial start of server.
startServer()

// Run the git monitoring program.
runProgram()
