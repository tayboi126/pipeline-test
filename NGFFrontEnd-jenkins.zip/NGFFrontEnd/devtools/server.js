/* eslint no-console: 0 */
const express = require('express')
const app = express()

const port = process.env.PORT || 8080
const host = process.env.HOST || 'g1mqa.pw.utc.com'

app.use(function(req, res, next) {
  console.log(JSON.stringify(req.headers))
  next()
})

try {
  app.listen(port, host, function () {
    console.log(`server.js listening at http://${host}:${port}.`)
  })
} catch (ex) {
  console.log(`Server error ${ex}.`)
}
