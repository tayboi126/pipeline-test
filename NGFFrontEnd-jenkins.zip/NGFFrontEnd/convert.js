const fs = require('fs')
const data = fs.readFileSync('Step7_Forecast.txt', 'utf8')

const step7NumFractionalDigits = 5

const round = (value, numDecimals = 0) =>
  // eslint-disable-next-line prefer-template
  Number(Math.round(value + 'e' + numDecimals) + 'e-' + numDecimals)

const getField = (data, i) => {
  let field = ''
  while (data[i] !== '\t' && data[i] !== '\n' && data[i] !== '\r' && i < data.length) {
    field += data[i++]
  }
  if (i < data.length) {
    if (data[i] === '\t') {
      ++i
    } else {
      while (data[i] === '\n' || data[i] === '\r') {
        ++i
      }
    }
  }
  return {
    field,
    i
  }
} 

let i = 0
const finalObj = {}
while (i < data.length) {
  let obj = getField(data, i)
  const category = obj.field
  i = obj.i
  if (category !== '') {
    if (!finalObj[category]) {
      finalObj[category] = []
    }
    obj = getField(data, i)
    const year = obj.field
    i = obj.i
    obj = getField(data, i)
    const mth = obj.field
    i = obj.i
    obj = getField(data, i)
    let value = obj.field
    i = obj.i
    if (value === 'NULL') {
      value = null
    } else {
      value = round(parseFloat(value), step7NumFractionalDigits)
    }
    finalObj[category].push({
      year: parseInt(year),
      mth,
      value,
      iceValue: value,
    })
  }
}

const result = Object.keys(finalObj).map(key => ({
  category: key,
  doNotIncludeSvCount: false,
  iceStatus: 1,
  forecast: finalObj[key]
})).sort((e1, e2) => e1.category.localeCompare(e2.category))

fs.writeFileSync('test.json', JSON.stringify(result, undefined, 2))
