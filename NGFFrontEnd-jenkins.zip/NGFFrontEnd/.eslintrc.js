module.exports = {
  parser: '@babel/eslint-parser',
  plugins: [
    'react',
    'babel',
    'prefer-spread',
    'jsdoc'
  ],
  parserOptions: {
    ecmaFeatures: {
      jsx: true
    },
    sourceType: 'module',
    requireConfigFile: false
  },
  extends: [
    'standard',
    'standard-react',
    'plugin:import/warnings',
    'plugin:import/errors',
    'plugin:react-hooks/recommended',
    'plugin:jsdoc/recommended'
  ],
  env: {
    amd: true,
    browser: true,
    es6: true,
    worker: true,
    mocha: true,
    jest: true
  },
  settings: {
    'import/resolver': {
      alias: {
        // TODO: pwlib, Remove the map entry below shen using node_modules/pwlib
        map: [
          ['pwlib', './src/pwlib/src']
        ],
        extensions: ['.js', '.jsx', '.json']
      },
    }
  },
  rules: {
    indent: ['warn', 2],
    'prefer-object-spread': 1,
    'prefer-spread/prefer-object-spread': [2, 'includeNearEquivalents'],
    'prefer-template': 1,
    'no-console': 1,
    'no-unused-vars': 1, 
    'react/prop-types': 1,
    'react-hooks/exhaustive-deps': 0,
    'react/jsx-fragments': 0,
    'react/jsx-closing-bracket-location': 0,
    'react/jsx-handler-names': 0,
    'react/jsx-boolean-value': 0,
    'react/jsx-no-undef': 2,
    'react/jsx-uses-react': 1,
    'react/jsx-indent': ['warn', 2],
    'react/jsx-indent-props': ['warn', 2],
    'react/jsx-uses-vars': 'error',
    'react-hooks/rules-of-hooks': 'error',
    'no-multiple-empty-lines': 0,
    'no-trailing-spaces': 0,
    'space-before-function-paren': 0,
    'eol-last': 0,
    'comma-dangle': 0,
    'no-return-assign': 0,
    'jsdoc/check-tag-names': 0
  }
} 
