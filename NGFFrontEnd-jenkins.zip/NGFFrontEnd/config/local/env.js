export const env = {
  isLocalCredentials: true,
  localLogin: true,
  baseUrl: 'http://localhost:8080',
  clockId: 'm313350',
  password: 'temp!234',
  proxies: {
    '/amcis': 'http://localhost:9003',
    '/ngf-step7': 'http://localhost:9001',
    '/ngf-cegs': 'http://localhost:9002',
    '/spanas': 'http://localhost:9004',
    '/ngf-step3': 'http://localhost:9005',
  }
}

