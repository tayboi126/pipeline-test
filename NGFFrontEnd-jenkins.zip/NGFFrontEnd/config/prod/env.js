export const env = {
  baseUrl: '/api'
}